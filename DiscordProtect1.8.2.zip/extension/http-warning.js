// SPDX-FileCopyrightText: 2026 Discord Protect project
// SPDX-License-Identifier: CC-BY-NC-SA-4.0
// https://creativecommons.org/licenses/by-nc-sa/4.0/
const rawTarget = new URLSearchParams(location.search).get("target") ?? "";
const targetElement = document.querySelector("#target-url");
const statusElement = document.querySelector("#status");
const continueButton = document.querySelector("#continue-button");
const backButton = document.querySelector("#back-button");
let targetUrl;

try {
  targetUrl = new URL(rawTarget);
  if (targetUrl.protocol !== "http:") throw new Error("Not an HTTP URL");
  targetElement.textContent = targetUrl.href;
} catch {
  targetElement.textContent = "Adresse HTTP invalide";
  continueButton.disabled = true;
}

continueButton.addEventListener("click", async () => {
  continueButton.disabled = true;
  backButton.disabled = true;
  statusElement.textContent = "Ouverture du site en HTTP…";
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const result = await chrome.runtime.sendMessage({
      type: "confirm-redirect",
      target: targetUrl.href,
      tabId: tab?.id
    });
    if (!result?.ok) throw new Error("Navigation could not continue");
  } catch {
    statusElement.textContent = "Impossible d’ouvrir cette adresse.";
    continueButton.disabled = false;
    backButton.disabled = false;
  }
});

backButton.addEventListener("click", async () => {
  backButton.disabled = true;
  statusElement.textContent = "Retour à la page précédente…";
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const result = await chrome.runtime.sendMessage({ type: "go-back", tabId: tab?.id });
    if (!result?.ok) statusElement.textContent = "Aucune page précédente. Vous pouvez fermer cet onglet.";
  } catch {
    statusElement.textContent = "Aucune page précédente. Vous pouvez fermer cet onglet.";
    backButton.disabled = false;
  }
});
