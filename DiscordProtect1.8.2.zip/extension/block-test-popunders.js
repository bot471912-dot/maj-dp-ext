// SPDX-FileCopyrightText: 2026 Discord Protect project
// SPDX-License-Identifier: CC-BY-NC-SA-4.0
// https://creativecommons.org/licenses/by-nc-sa/4.0/
const nativeOpen = window.open.bind(window);
let pageOpen = nativeOpen;
let protectionEnabled = document.documentElement.dataset.dpProtectionEnabled !== "false";
const blockedOpen = () => null;
Object.defineProperty(window, "open", {
  configurable: false,
  get: () => protectionEnabled ? blockedOpen : pageOpen,
  set: (value) => { pageOpen = typeof value === "function" ? value : nativeOpen; }
});

new MutationObserver(() => {
  protectionEnabled = document.documentElement.dataset.dpProtectionEnabled !== "false";
}).observe(document.documentElement, { attributes: true, attributeFilter: ["data-dp-protection-enabled"] });

document.addEventListener("click", (event) => {
  if (!protectionEnabled) return;
  const link = event.composedPath().find((node) => node instanceof HTMLAnchorElement);
  if (!link) return;

  let destination;
  try {
    destination = new URL(link.href, location.href);
  } catch {
    return;
  }
  const isTestAdLink = destination.origin === location.origin
    && /\/extreme-test\/ad\.com(?:\/|$)/i.test(destination.pathname);
  const isAdNetworkLink = /(^|\.)(?:12ezo5v60\.com|fvcwqkkqmuv\.com|ybs2ffs7v\.com|adsco\.re|pncloudfl\.com|antiadblocksystems\.com)$/i.test(destination.hostname);
  if (!isTestAdLink && !isAdNetworkLink) return;

  event.preventDefault();
  event.stopImmediatePropagation();
}, true);
