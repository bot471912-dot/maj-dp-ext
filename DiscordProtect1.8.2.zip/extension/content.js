// SPDX-FileCopyrightText: 2026 Discord Protect project
// SPDX-License-Identifier: CC-BY-NC-SA-4.0
// https://creativecommons.org/licenses/by-nc-sa/4.0/
const adSelectors = [
  "[data-ad]",
  "[data-advertisement]",
  "[data-ad-unit]",
  "[data-adunit]",
  "[data-ad-client]",
  "[data-ad-slot]",
  "[data-google-query-id]",
  "[aria-label='Advertisement' i]",
  "[class~='advertisement']",
  "[id*='advertisement' i]",
  ".advert",
  ".ad-container",
  ".ad-wrapper",
  ".ad-slot",
  ".ad-placement",
  ".ad-banner",
  ".ad_banner",
  "[class*='banner-ad' i]",
  "[class*='ad-banner' i]",
  "[id*='banner-ad' i]",
  "[id*='ad-banner' i]",
  "[id^='div-gpt-ad']",
  "[id^='google_ads_iframe']",
  ".banner-ad",
  ".native-ad",
  ".sponsored-content",
  "[class*='in-page-push' i]",
  "[id*='in-page-push' i]",
  "[class*='push-ad' i]",
  "[id*='push-ad' i]",
  "[class*='popunder' i]",
  "[class*='pop-under' i]",
  "[class*='interstitial-ad' i]",
  "[id*='interstitial-ad' i]",
  "[class*='video-ad' i]",
  "[id*='video-ad' i]",
  "[class*='adblock-detected' i]",
  "[id*='adblock-detected' i]",
  "[class*='adblock-warning' i]",
  "[id*='adblock-warning' i]",
  "[class*='adblock-overlay' i]",
  "[id*='adblock-overlay' i]",
  "[class*='adblock-modal' i]",
  "[id*='adblock-modal' i]",
  "[id^='google_ads_']",
  ".adsbygoogle",
  "iframe[src*='doubleclick.net']",
  "iframe[src*='googlesyndication.com']",
  "iframe[src*='adnxs.com']",
  "iframe[src*='mgid.com']",
  "iframe[src*='pubmatic.com']",
  "iframe[src*='openx.net']",
  "iframe[src*='rubiconproject.com']"
];
const testCosmeticSelectors = [
  ".textads",
  ".banner-ads",
  ".banner_ads",
  ".ad-unit",
  ".ad-zone",
  ".ad-space",
  ".adsbox",
  ".afs_ads",
  "#ad_ctd"
];
const youtubeAdSelectors = [
  "ytd-ad-slot-renderer",
  "ytd-display-ad-renderer",
  "ytd-promoted-sparkles-web-renderer",
  "ytd-promoted-sparkles-text-search-renderer",
  "ytd-in-feed-ad-layout-renderer",
  "ytd-banner-promo-renderer",
  "ytd-compact-promoted-video-renderer",
  "ytd-action-companion-ad-renderer",
  "ytd-promoted-video-renderer",
  "yt-mealbar-promo-renderer",
  "#masthead-ad",
  "#player-ads",
  ".video-ads",
  ".ytp-ad-module",
  ".ytp-ad-overlay-container",
  ".ytp-ad-player-overlay",
  ".ytp-ad-text-overlay",
  ".ytp-ad-image-overlay",
  ".ytp-ad-overlay-slot",
  ".ytp-ad-message-container"
];
const youtubeSkipSelectors = [
  ".ytp-skip-ad-button",
  ".ytp-ad-skip-button",
  ".ytp-ad-skip-button-modern",
  "button.ytp-skip-ad-button"
];
const spotifyAdSelectors = [
  "[data-testid='ad-banner']",
  "[data-testid='audio-ads']",
  "[data-testid='video-ad']",
  "[data-testid='ad-slot']",
  "[data-testid*='sponsored' i]",
  "[data-testid*='advertisement' i]",
  "[class*='adBanner' i]",
  "[class*='audioAd' i]"
];

const cookiePopupSelectors = [
  "#onetrust-banner-sdk",
  "#onetrust-consent-sdk",
  "#CybotCookiebotDialog",
  ".didomi-popup-container",
  "#cookie-law-info-bar",
  ".cookie-consent-banner",
  ".cky-consent-container",
  ".cc-window",
  "#klaro",
  ".qc-cmp2-container",
  ".popup__backdrop",
  "[data-testid*='cookie-consent']",
  "[class*='cookie-consent']",
  "[id*='cookie-consent']",
  "[class*='cookie-banner']",
  "[id*='cookie-banner']",
  "[class*='consent-banner']",
  "[id*='consent-banner']",
  "[class*='cookie-popup']",
  "[id*='cookie-popup']",
  "[class*='cookie-consent-popup']",
  "[id*='cookie-consent-popup']",
  "[class*='cookie-modal']",
  "[id*='cookie-modal']"
];
const cookieText = /cookies?|cookie|consent|consentement|confidentialit[eé]|privacy|traceurs|trackers/i;
const protectedDialogText = /cookies?|consent|privacy|confidentialit[eé]|login|log in|sign.?in|account|password|checkout|payment|subscribe|newsletter|age verification/i;
const adPopupText = /\b(ad|ads|advert|advertisement|sponsored|promoted|pop.?under|interstitial)\b/i;
const adblockWarningText = /ad.?block(?:er|ing)?|disable.{0,30}(?:ad.?block|blocker)|turn off.{0,30}(?:ad.?block|blocker)|whitelist.{0,30}(?:site|website)|advertisements?.{0,30}blocked/i;
const trackingParameters = new Set([
  "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content", "utm_id", "utm_name", "utm_reader",
  "utm_referrer", "utm_social", "utm_social-type", "gclid", "dclid", "gclsrc", "gbraid", "wbraid", "fbclid",
  "fb_action_ids", "fb_action_types", "fb_source", "fb_ref", "msclkid", "twclid", "ttclid", "li_fat_id",
  "igshid", "srsltid", "yclid", "ymclid", "_ga", "_gl", "mc_cid", "mc_eid", "mkt_tok", "vero_conv",
  "vero_id", "oly_anon_id", "oly_enc_id", "_hsenc", "_hsmi", "hsctatracking", "__hstc", "__hssc", "__hsfp",
  "matomo_campaign", "matomo_kwd", "pk_campaign", "pk_kwd", "pk_source", "pk_medium", "pk_content", "pk_cid"
]);

let protectionEnabled = true;
let cookiePopupEnabled = true;
let antiTrackingEnabled = true;
let pickingElement = false;
let highlightedElement = null;
let highlightedOutline = null;
let pendingCount = 0;
let flushTimer;
const handledElements = new WeakSet();
let discordToolsEnabled = true;
let antiRickrollEnabled = true;
let discordPanelHost;
let discordPanelRoot;
let discordPanelIsOpen = false;
let discordCompactProfiles = false;
let discordAccentColor = "#5865f2";
let contextAvatarImage = null;
let avatarOriginals = new WeakMap();
let avatarDecorationOriginals = new WeakMap();
let rickrollWarningRequested = false;
let rickrollPageApproved = false;
let youtubeShortsBlocked = false;
let youtubeShortScrollCount = 0;
let youtubeLastScrollAt = 0;
let youtubeTouchStartY = 0;
let youtubePromptHost = null;
let youtubeRedirectingToWatch = false;

const discordThemeStyle = document.createElement("style");
discordThemeStyle.id = "discord-protect-custom-style";
discordThemeStyle.textContent = `
  :root.dp-discord-custom-theme { --brand-experiment: ${discordAccentColor} !important; --brand-500: ${discordAccentColor} !important; }
  :root.dp-discord-compact [class*="userProfileModal"] [class*="inner"],
  :root.dp-discord-compact [class*="userPopout"] [class*="inner"] { gap: 8px !important; }
  :root.dp-discord-compact [class*="userProfileModal"] [class*="profileBody"],
  :root.dp-discord-compact [class*="userPopout"] [class*="profileBody"] { padding-top: 8px !important; padding-bottom: 8px !important; }
  :root.dp-discord-compact [class*="userProfileModal"] [class*="section"],
  :root.dp-discord-compact [class*="userPopout"] [class*="section"] { margin-top: 6px !important; }
`;

function renderDiscordAccent(color) {
  const allowedColors = ["#5865f2", "#d94a43", "#3ba55c"];
  discordAccentColor = allowedColors.includes(color) ? color : allowedColors[0];
  discordThemeStyle.textContent = `
    :root.dp-discord-custom-theme { --brand-experiment: ${discordAccentColor} !important; --brand-500: ${discordAccentColor} !important; }
    :root.dp-discord-compact [class*="userProfileModal"] [class*="inner"],
    :root.dp-discord-compact [class*="userPopout"] [class*="inner"] { gap: 8px !important; }
    :root.dp-discord-compact [class*="userProfileModal"] [class*="profileBody"],
    :root.dp-discord-compact [class*="userPopout"] [class*="profileBody"] { padding-top: 8px !important; padding-bottom: 8px !important; }
    :root.dp-discord-compact [class*="userProfileModal"] [class*="section"],
    :root.dp-discord-compact [class*="userPopout"] [class*="section"] { margin-top: 6px !important; }
  `;
  if (!discordThemeStyle.isConnected) document.documentElement.append(discordThemeStyle);
  discordPanelRoot?.host?.style.setProperty("--accent", discordAccentColor);
  document.documentElement.classList.add("dp-discord-custom-theme");
}

function setDiscordCompact(enabled) {
  discordCompactProfiles = Boolean(enabled);
  document.documentElement.classList.toggle("dp-discord-compact", discordCompactProfiles);
}

function visibleDiscordProfileRoot() {
  const specificSelectors = [
    "[class*='userProfileModal']",
    "[class*='userPopout']",
    "[class*='profilePanel']",
    "[class*='profileModal']"
  ];
  for (const selector of specificSelectors) {
    const match = [...document.querySelectorAll(selector)].find(isVisible);
    if (match) return match;
  }
  return [...document.querySelectorAll("[role='dialog']")]
    .find((element) => isVisible(element) && /profile|profil|member|membre/i.test(element.innerText ?? "")) ?? null;
}

function collectVisibleProfileInfo() {
  const root = visibleDiscordProfileRoot();
  const routeId = location.pathname.match(/\/users\/(\d{16,22})/)?.[1];
  const searchRoot = root ?? (routeId ? document.querySelector("main") ?? document.body : null);
  if (!searchRoot) return { visible: false, name: "", userId: "", details: [] };

  let name = "";
  for (const selector of ["[class*='userTagUsername']", "[class*='displayName']", "[class*='username']", "h1", "h2"]) {
    const candidate = [...searchRoot.querySelectorAll(selector)].find((element) => isVisible(element) && element.innerText.trim());
    if (!candidate) continue;
    name = candidate.innerText.trim().split("\n")[0].slice(0, 100);
    break;
  }

  const linkedId = [...searchRoot.querySelectorAll("a[href]")]
    .map((link) => link.href.match(/\/users\/(\d{16,22})/)?.[1])
    .find(Boolean);
  const userId = routeId ?? linkedId ?? "";
  const details = [];
  for (const selector of ["[class*='pronouns']", "[class*='memberSince']", "[class*='profileBadges']", "[class*='connectedAccount']", "[class*='userBio']", "[class*='bio']", "[class*='role']"]) {
    for (const element of searchRoot.querySelectorAll(selector)) {
      const text = (element.innerText || element.getAttribute("aria-label") || "").trim().replace(/\s+/g, " ");
      if (isVisible(element) && text.length > 1 && text.length < 180 && !details.includes(text)) details.push(text);
      if (details.length >= 8) break;
    }
    if (details.length >= 8) break;
  }
  return { visible: true, name, userId, details };
}

function updateDiscordProfileInfo() {
  if (!discordPanelRoot) return;
  const profile = collectVisibleProfileInfo();
  const name = discordPanelRoot.querySelector("#dp-profile-name");
  const id = discordPanelRoot.querySelector("#dp-profile-id");
  const details = discordPanelRoot.querySelector("#dp-profile-details");
  const copyButton = discordPanelRoot.querySelector("#dp-copy-id");
  if (!profile.visible) {
    name.textContent = "Aucun profil détecté";
    id.textContent = "Ouvre une fiche de profil Discord.";
    details.replaceChildren();
    copyButton.disabled = true;
    return;
  }
  name.textContent = profile.name || "Profil Discord";
  id.textContent = profile.userId ? `ID : ${profile.userId}` : "ID non visible sur cette fiche";
  copyButton.disabled = !profile.userId;
  details.replaceChildren();
  for (const detail of profile.details.length ? profile.details : ["Aucune bio, aucun rôle ou détail supplémentaire visible."]) {
    const item = document.createElement("li");
    item.textContent = detail;
    details.append(item);
  }
}

function setDiscordPanelStatus(message) {
  discordPanelRoot?.querySelector("#dp-status")?.replaceChildren(document.createTextNode(message));
}

function findAvatarImage(target) {
  if (!(target instanceof Element)) return null;
  if (target instanceof HTMLImageElement && /avatar/i.test(`${target.alt} ${target.className}`)) return target;
  const avatarContainer = target.closest("[class*='avatar' i], [aria-label*='avatar' i]");
  if (!avatarContainer) return null;
  return avatarContainer instanceof HTMLImageElement ? avatarContainer : avatarContainer.querySelector("img");
}

function rememberAvatarImage(image) {
  if (!avatarOriginals.has(image)) {
    avatarOriginals.set(image, {
      src: image.getAttribute("src"),
      srcset: image.getAttribute("srcset"),
      referrerPolicy: image.getAttribute("referrerpolicy")
    });
  }
}

function applyLocalAvatarUrl() {
  const input = discordPanelRoot?.querySelector("#dp-avatar-url");
  if (!contextAvatarImage?.isConnected) {
    setDiscordPanelStatus("Fais clic droit sur un avatar Discord avant de le modifier.");
    return;
  }

  let imageUrl;
  try {
    imageUrl = new URL(input.value.trim());
  } catch {
    setDiscordPanelStatus("Entre une URL d’image valide.");
    return;
  }
  if (imageUrl.protocol !== "https:") {
    setDiscordPanelStatus("Utilise une URL HTTPS pour l’image.");
    return;
  }
  if (imageUrl.username || imageUrl.password) {
    setDiscordPanelStatus("Les URL avec identifiants intégrés ne sont pas acceptées.");
    return;
  }

  const testImage = new Image();
  testImage.referrerPolicy = "no-referrer";
  testImage.onload = () => {
    if (!contextAvatarImage?.isConnected) {
      setDiscordPanelStatus("L’avatar ciblé n’est plus affiché. Rouvre son menu contextuel.");
      return;
    }
    rememberAvatarImage(contextAvatarImage);
    contextAvatarImage.referrerPolicy = "no-referrer";
    contextAvatarImage.removeAttribute("srcset");
    contextAvatarImage.src = imageUrl.href;
    setDiscordPanelStatus("Image appliquée localement à cette fiche.");
  };
  testImage.onerror = () => setDiscordPanelStatus("Impossible de charger cette image.");
  testImage.src = imageUrl.href;
  setDiscordPanelStatus("Vérification de l’image…");
}

function applyAvatarDecoration(decoration) {
  if (!contextAvatarImage?.isConnected) {
    setDiscordPanelStatus("Fais clic droit sur un avatar Discord avant d’ajouter une décoration.");
    return;
  }
  const target = contextAvatarImage;
  if (!avatarDecorationOriginals.has(target)) {
    avatarDecorationOriginals.set(target, {
      outline: target.style.getPropertyValue("outline"),
      outlinePriority: target.style.getPropertyPriority("outline"),
      outlineOffset: target.style.getPropertyValue("outline-offset"),
      outlineOffsetPriority: target.style.getPropertyPriority("outline-offset"),
      boxShadow: target.style.getPropertyValue("box-shadow"),
      boxShadowPriority: target.style.getPropertyPriority("box-shadow")
    });
  }
  const styles = {
    gold: "2px solid #f2c45d",
    red: "2px solid #ed5660",
    green: "2px solid #55d895"
  };
  const ringColor = decoration === "red" ? "#ed5660" : decoration === "green" ? "#55d895" : "#f2c45d";
  target.style.setProperty("outline", styles[decoration] ?? styles.gold, "important");
  target.style.setProperty("outline-offset", "3px", "important");
  target.style.setProperty("box-shadow", `0 0 12px ${ringColor}99`, "important");
  setDiscordPanelStatus("Décoration visible uniquement chez toi.");
}

function resetLocalAvatarChanges() {
  if (!contextAvatarImage?.isConnected) {
    setDiscordPanelStatus("Fais clic droit sur l’avatar concerné pour le restaurer.");
    return;
  }
  const original = avatarOriginals.get(contextAvatarImage);
  if (original) {
    if (original.src === null) contextAvatarImage.removeAttribute("src");
    else contextAvatarImage.setAttribute("src", original.src);
    if (original.srcset === null) contextAvatarImage.removeAttribute("srcset");
    else contextAvatarImage.setAttribute("srcset", original.srcset);
    if (original.referrerPolicy === null) contextAvatarImage.removeAttribute("referrerpolicy");
    else contextAvatarImage.setAttribute("referrerpolicy", original.referrerPolicy);
    avatarOriginals.delete(contextAvatarImage);
  }
  const target = contextAvatarImage;
  const decoration = avatarDecorationOriginals.get(target);
  if (decoration) {
    target.style.setProperty("outline", decoration.outline, decoration.outlinePriority);
    target.style.setProperty("outline-offset", decoration.outlineOffset, decoration.outlineOffsetPriority);
    target.style.setProperty("box-shadow", decoration.boxShadow, decoration.boxShadowPriority);
    avatarDecorationOriginals.delete(target);
  }
  setDiscordPanelStatus("Personnalisation locale retirée.");
}

function captureContextAvatar(event) {
  if (location.hostname !== "discord.com") return;
  const candidate = event.composedPath().find((node) => node instanceof Element && findAvatarImage(node));
  if (candidate) contextAvatarImage = findAvatarImage(candidate);
}

function createDiscordPanel() {
  if (discordPanelHost || !document.body) return;
  discordPanelHost = document.createElement("div");
  discordPanelHost.id = "discord-protect-addon-root";
  discordPanelHost.style.cssText = "position:fixed;z-index:2147483646;right:18px;bottom:18px";
  discordPanelRoot = discordPanelHost.attachShadow({ mode: "closed" });
  const style = document.createElement("style");
  style.textContent = `
    :host{font-family:Arial,sans-serif;color:#f3f4f6;--accent:${discordAccentColor}} *{box-sizing:border-box}
    .launcher{width:48px;height:48px;border:1px solid #ffffff44;border-radius:50%;background:var(--accent);color:#fff;font-weight:800;font-size:13px;box-shadow:0 5px 22px #0008;cursor:pointer}
    .panel{width:min(340px,calc(100vw - 36px));max-height:min(75vh,620px);overflow:auto;margin-bottom:10px;padding:16px;border:1px solid #41434a;border-radius:12px;background:#17181d;box-shadow:0 14px 50px #000a}
    .panel[hidden]{display:none}.header{display:flex;justify-content:space-between;align-items:center;margin-bottom:14px}
    h2{margin:0;font-size:15px}.close{border:0;background:none;color:#bbb;font-size:20px;cursor:pointer}
    .section{padding:12px 0;border-top:1px solid #34363d}.section-title{margin:0 0 10px;color:#c9cbd1;font-size:11px;font-weight:700;text-transform:uppercase}
    .name{font-size:14px;font-weight:700;overflow-wrap:anywhere}.id{margin-top:4px;color:#aaa;font-size:11px;overflow-wrap:anywhere}
    ul{display:grid;gap:6px;margin:10px 0 0;padding-left:17px;color:#d2d3d7;font-size:11px;line-height:1.45}
    .copy{margin-top:9px;padding:6px 9px;border:1px solid #494b53;border-radius:5px;background:#24262d;color:#eee;font-size:10px;cursor:pointer}
    .copy:disabled{opacity:.45;cursor:default}.options{display:flex;align-items:center;justify-content:space-between;gap:8px;color:#ddd;font-size:11px}
    .avatar-label{display:block;margin-top:10px;color:#c9cbd1;font-size:10px}.avatar-url{width:100%;margin-top:6px;padding:9px;border:1px solid #494b53;border-radius:5px;background:#202127;color:#fff;font:inherit;font-size:11px}.avatar-url::placeholder{color:#858891}
    .compact{width:16px;height:16px;accent-color:var(--accent)}.swatches{display:flex;gap:9px;margin-top:10px}
    .swatch{width:23px;height:23px;border:2px solid #ffffff55;border-radius:50%;cursor:pointer}.swatch[aria-pressed="true"]{outline:2px solid white;outline-offset:2px}
    .note{margin:8px 0 0;color:#9699a2;font-size:10px;line-height:1.5}.status{min-height:14px;margin-top:8px;color:#9cb7ff;font-size:10px}
    button:focus-visible,input:focus-visible{outline:2px solid #fff;outline-offset:2px}@media(max-width:480px){.panel{max-height:68vh}}
  `;
  const panel = document.createElement("section");
  panel.className = "panel";
  panel.hidden = true;
  panel.innerHTML = `<header class="header"><h2>Discord Protect</h2><button class="close" id="dp-close" aria-label="Fermer">×</button></header>
    <section class="section"><p class="section-title">Infos visibles du profil</p><div class="name" id="dp-profile-name">Chargement du profil…</div><div class="id" id="dp-profile-id"></div><ul id="dp-profile-details"></ul><button class="copy" id="dp-copy-id" type="button" disabled>Copier l’ID</button><p class="note">Informations déjà visibles sur la page seulement. Rien n’est transmis à Discord Protect.</p></section>
    <section class="section"><p class="section-title">Modules de personnalisation</p><label class="options"><span>Profil compact</span><input class="compact" id="dp-compact" type="checkbox"></label><div class="options" style="margin-top:12px"><span>Accent Discord</span></div><div class="swatches"><button class="swatch" data-color="#5865f2" aria-label="Accent indigo"></button><button class="swatch" data-color="#d94a43" aria-label="Accent rouge"></button><button class="swatch" data-color="#3ba55c" aria-label="Accent vert"></button></div><p class="note">Options locales et réversibles.</p></section>
    <section class="section"><p class="section-title">Avatar local</p><p class="note" id="dp-avatar-target">Clic droit sur un avatar pour le sélectionner.</p><label class="avatar-label" for="dp-avatar-url">Image HTTPS</label><input class="avatar-url" id="dp-avatar-url" type="url" placeholder="https://exemple.com/avatar.png"><button class="copy" id="dp-apply-avatar" type="button">Appliquer à cet avatar</button><div class="swatches avatar-decorations"><button class="swatch" data-decoration="gold" aria-label="Anneau doré"></button><button class="swatch" data-decoration="red" aria-label="Anneau rouge"></button><button class="swatch" data-decoration="green" aria-label="Anneau vert"></button><button class="copy" id="dp-reset-avatar" type="button">Rétablir</button></div><p class="note">L’image est chargée directement depuis son URL et peut informer son hébergeur de ta visite. Les changements ne sont visibles que sur cet appareil et cette page.</p></section>
    <div class="status" id="dp-status" role="status" aria-live="polite"></div>`;
  const launcher = document.createElement("button");
  launcher.className = "launcher";
  launcher.type = "button";
  launcher.textContent = "DP";
  launcher.title = "Ouvrir les modules Discord Protect";
  discordPanelRoot.append(style, panel, launcher);
  document.body.append(discordPanelHost);

  launcher.addEventListener("click", () => {
    discordPanelIsOpen = !discordPanelIsOpen;
    panel.hidden = !discordPanelIsOpen;
    if (discordPanelIsOpen) updateDiscordProfileInfo();
  });
  discordPanelRoot.querySelector("#dp-close").addEventListener("click", () => {
    discordPanelIsOpen = false;
    panel.hidden = true;
  });
  discordPanelRoot.querySelector("#dp-compact").addEventListener("change", (event) => {
    setDiscordCompact(event.currentTarget.checked);
    chrome.storage.local.set({ discordCompactProfiles }).catch(() => undefined);
  });
  discordPanelRoot.querySelectorAll(".swatch").forEach((swatch) => {
    swatch.style.background = swatch.dataset.color;
    swatch.addEventListener("click", () => {
      renderDiscordAccent(swatch.dataset.color);
      discordPanelRoot.querySelectorAll(".swatch").forEach((button) => button.setAttribute("aria-pressed", String(button === swatch)));
      chrome.storage.local.set({ discordAccentColor }).catch(() => undefined);
    });
  });
  discordPanelRoot.querySelector("#dp-copy-id").addEventListener("click", async () => {
    const profile = collectVisibleProfileInfo();
    if (!profile.userId) return;
    try {
      await navigator.clipboard.writeText(profile.userId);
      discordPanelRoot.querySelector("#dp-status").textContent = "ID copié.";
    } catch {
      discordPanelRoot.querySelector("#dp-status").textContent = "Copie refusée par le navigateur.";
    }
  });
  discordPanelRoot.querySelector("#dp-apply-avatar").addEventListener("click", applyLocalAvatarUrl);
  discordPanelRoot.querySelector("#dp-reset-avatar").addEventListener("click", resetLocalAvatarChanges);
  discordPanelRoot.querySelectorAll("[data-decoration]").forEach((button) => {
    button.style.background = button.dataset.decoration === "gold" ? "#f2c45d" : button.dataset.decoration === "red" ? "#ed5660" : "#55d895";
    button.addEventListener("click", () => applyAvatarDecoration(button.dataset.decoration));
  });

  chrome.storage.local.get(["discordCompactProfiles", "discordAccentColor"]).then((state) => {
    if (!discordToolsEnabled || !discordPanelHost?.isConnected) return;
    setDiscordCompact(state.discordCompactProfiles === true);
    renderDiscordAccent(state.discordAccentColor ?? "#5865f2");
    discordPanelRoot.querySelector("#dp-compact").checked = discordCompactProfiles;
    discordPanelRoot.querySelectorAll(".swatch").forEach((button) => button.setAttribute("aria-pressed", String(button.dataset.color === discordAccentColor)));
  });
}

function removeDiscordPanel() {
  discordPanelHost?.remove();
  discordPanelHost = null;
  discordPanelRoot = null;
  document.documentElement.classList.remove("dp-discord-custom-theme", "dp-discord-compact");
  discordThemeStyle.remove();
}

function updateDiscordTools() {
  if (protectionEnabled && location.hostname === "discord.com" && discordToolsEnabled) {
    createDiscordPanel();
    if (discordPanelIsOpen) updateDiscordProfileInfo();
  } else {
    removeDiscordPanel();
  }
}

function flushCount() {
  if (!pendingCount) return;
  const count = pendingCount;
  pendingCount = 0;
  chrome.runtime.sendMessage({ type: "threat-blocked", count }).catch(() => undefined);
}

function recordBlocked() {
  pendingCount += 1;
  if (flushTimer) return;
  flushTimer = setTimeout(() => {
    flushTimer = undefined;
    flushCount();
  }, 400);
}

function isVisible(element) {
  return element.getClientRects().length > 0 && getComputedStyle(element).visibility !== "hidden";
}

function isBackdrop(element) {
  const name = `${element.id} ${typeof element.className === "string" ? element.className : ""}`;
  if (!/backdrop|overlay/i.test(name)) return false;
  const style = getComputedStyle(element);
  return style.position === "fixed" || style.position === "absolute" || element.matches(".popup__backdrop");
}

function removeLargeAdPopups() {
  const candidates = document.querySelectorAll(
    "body *:is([role='dialog'],[class*='popup' i],[id*='popup' i],[class*='modal' i],[id*='modal' i],[class*='overlay' i],[id*='overlay' i],[class*='adblock' i],[id*='adblock' i])"
  );
  const viewportArea = Math.max(1, window.innerWidth * window.innerHeight);
  const removed = new Set();

  for (const element of candidates) {
    if (!element.isConnected || handledElements.has(element) || !isVisible(element)) continue;
    const style = getComputedStyle(element);
    if (style.position !== "fixed" && style.position !== "absolute") continue;

    const bounds = element.getBoundingClientRect();
    const area = Math.max(0, bounds.width) * Math.max(0, bounds.height);
    if (bounds.width < 240 || bounds.height < 160 || area < viewportArea * 0.2) continue;

    const label = `${element.id} ${typeof element.className === "string" ? element.className : ""} ${element.getAttribute("aria-label") ?? ""} ${element.innerText ?? ""}`.slice(0, 2500);
    const isAdblockWarning = adblockWarningText.test(label);
    if (protectedDialogText.test(label) && !adPopupText.test(label) && !isAdblockWarning) continue;

    const hasExternalDestination = [...element.querySelectorAll("a[href], iframe[src]")]
      .some((link) => {
        try {
          const destination = link instanceof HTMLAnchorElement ? link.href : link.src;
          return new URL(destination, location.href).origin !== location.origin;
        } catch {
          return false;
        }
      });
    const hasClickableContent = hasExternalDestination
      || element.querySelector("a[href], button, [role='button'], [onclick], [tabindex], input[type='button'], input[type='submit']");
    if (!hasClickableContent && !isAdblockWarning) continue;
    if (!hasExternalDestination && !adPopupText.test(label) && !isAdblockWarning) continue;

    handledElements.add(element);
    element.remove();
    removed.add(element);
    recordBlocked();
  }

  if (removed.size) restorePageScroll();
}

function removeCanYouBlockItAdSlots() {
  if (!/(^|\.)canyoublockit\.com$/i.test(location.hostname) || !location.pathname.startsWith("/extreme-test")) return;

  for (const frame of document.querySelectorAll("iframe[id^='__clb-'], iframe[src*='ybs2ffs7v.com']")) {
    const slot = frame.closest(".code-block");
    handledElements.add(frame);
    if (slot) handledElements.add(slot);
    (slot ?? frame).remove();
    recordBlocked();
  }
}

function removeRelatedBackdrops(element) {
  const backdrops = new Set();
  let branch = element;

  for (let depth = 0; depth < 5 && branch && branch !== document.body; depth += 1) {
    if (branch !== element && isBackdrop(branch)) backdrops.add(branch);
    const parent = branch.parentElement;
    if (!parent) break;
    for (const sibling of parent.children) {
      if (sibling !== branch && isBackdrop(sibling) && isVisible(sibling)) backdrops.add(sibling);
    }
    branch = parent;
  }

  for (const backdrop of backdrops) {
    handledElements.add(backdrop);
    backdrop.remove();
    recordBlocked();
  }
}

function restorePageScroll() {
  const root = document.documentElement;
  const body = document.body;
  const lockedClasses = ["modal-open", "no-scroll", "noscroll", "overflow-hidden", "scroll-locked", "scroll-lock", "prevent-scroll", "disable-scroll", "scroll-disabled", "locked", "is-locked"];
  let scrollY = window.scrollY;
  const bodyBefore = getComputedStyle(body);
  const lockedTop = Number.parseFloat(bodyBefore.top);
  const fixedBodyLock = bodyBefore.position === "fixed" && Number.isFinite(lockedTop) && lockedTop < 0;
  const hadScrollLock = [root, body].some((element) =>
    lockedClasses.some((className) => element.classList.contains(className))
  ) || [getComputedStyle(root), bodyBefore].some((style) =>
    style.overflow === "hidden" || style.overflow === "clip" || style.overflowY === "hidden" || style.overflowY === "clip"
  ) || fixedBodyLock;
  if (!hadScrollLock) return;
  if (fixedBodyLock) scrollY = -lockedTop;

  const unlock = () => {
    for (const element of [root, body]) {
      element.classList.remove(...lockedClasses);
      const style = getComputedStyle(element);
      if (style.overflow === "hidden" || style.overflow === "clip") element.style.setProperty("overflow", "auto", "important");
      if (style.overflowY === "hidden" || style.overflowY === "clip") element.style.setProperty("overflow-y", "auto", "important");
    }

    const currentBodyStyle = getComputedStyle(body);
    const currentTop = Number.parseFloat(currentBodyStyle.top);
    if (currentBodyStyle.position === "fixed" && Number.isFinite(currentTop) && currentTop < 0) {
      body.style.removeProperty("position");
      body.style.removeProperty("top");
      body.style.removeProperty("left");
      body.style.removeProperty("right");
      body.style.removeProperty("width");
    }
    window.scrollTo(0, scrollY);
  };

  unlock();
  requestAnimationFrame(unlock);
  setTimeout(unlock, 120);
}

function clearElementHighlight() {
  if (highlightedElement && highlightedOutline) {
    highlightedElement.style.setProperty("outline", highlightedOutline.value, highlightedOutline.priority);
    highlightedElement.style.setProperty("outline-offset", highlightedOutline.offset, highlightedOutline.offsetPriority);
  }
  highlightedElement = null;
  highlightedOutline = null;
  document.documentElement.style.removeProperty("cursor");
}

function cancelElementPicker() {
  if (!pickingElement) return;
  pickingElement = false;
  clearElementHighlight();
  document.removeEventListener("pointermove", highlightElementUnderPointer, true);
  document.removeEventListener("click", removeElementUnderPointer, true);
  document.removeEventListener("keydown", cancelPickerOnEscape, true);
}

function highlightElementUnderPointer(event) {
  const element = document.elementFromPoint(event.clientX, event.clientY);
  if (!element || element === document.documentElement || element === document.body || element === highlightedElement) return;

  clearElementHighlight();
  highlightedElement = element;
  highlightedOutline = {
    value: element.style.getPropertyValue("outline"),
    priority: element.style.getPropertyPriority("outline"),
    offset: element.style.getPropertyValue("outline-offset"),
    offsetPriority: element.style.getPropertyPriority("outline-offset")
  };
  element.style.setProperty("outline", "2px solid #f2d28b", "important");
  element.style.setProperty("outline-offset", "2px", "important");
  document.documentElement.style.setProperty("cursor", "crosshair", "important");
}

function removeElementUnderPointer(event) {
  const element = document.elementFromPoint(event.clientX, event.clientY);
  if (!element || element === document.documentElement || element === document.body) return;

  event.preventDefault();
  event.stopPropagation();
  event.stopImmediatePropagation();
  cancelElementPicker();
  element.remove();
  recordBlocked();
  restorePageScroll();
}

function cancelPickerOnEscape(event) {
  if (event.key === "Escape") cancelElementPicker();
}

function startElementPicker() {
  if (pickingElement) return;
  pickingElement = true;
  document.documentElement.style.setProperty("cursor", "crosshair", "important");
  document.addEventListener("pointermove", highlightElementUnderPointer, true);
  document.addEventListener("click", removeElementUnderPointer, true);
  document.addEventListener("keydown", cancelPickerOnEscape, true);
}

function cleanTrackingParameters() {
  if (!protectionEnabled || !antiTrackingEnabled) return;

  document.querySelectorAll("a[href]").forEach((link) => {
    let target;
    try {
      target = new URL(link.href, location.href);
    } catch {
      return;
    }
    if (target.protocol !== "http:" && target.protocol !== "https:") return;

    let changed = false;
    for (const key of [...target.searchParams.keys()]) {
      const normalizedKey = key.toLowerCase();
      if (!trackingParameters.has(normalizedKey) && !normalizedKey.startsWith("utm_")) continue;
      target.searchParams.delete(key);
      changed = true;
    }
    if (!changed) return;

    link.href = target.href;
    link.referrerPolicy = "no-referrer";
    recordBlocked();
  });
}

function confirmLinkNavigation(event) {
  if (!protectionEnabled || !event.isTrusted || event.button !== 0) return;

  const anchor = event.composedPath().find((node) => node instanceof HTMLAnchorElement);
  if (!anchor) return;

  let target;
  try {
    target = new URL(anchor.href, location.href);
  } catch {
    return;
  }

  if (target.protocol === "javascript:") {
    event.preventDefault();
    event.stopImmediatePropagation();
    window.alert("Discord Protect a bloqué ce lien, car il exécute du code JavaScript au clic.");
    return;
  }

  if (target.protocol === "data:" || target.protocol === "blob:") {
    event.preventDefault();
    event.stopImmediatePropagation();
    window.alert("Discord Protect a bloqué cette adresse intégrée, qui peut contenir du code actif.");
    return;
  }

  if (anchor.hasAttribute("download")) {
    if (!window.confirm(`Télécharger ce fichier ?\n\n${anchor.download || target.pathname.split("/").pop() || target.href}\n\nN’ouvrez pas un fichier inattendu.`)) {
      event.preventDefault();
      event.stopImmediatePropagation();
    }
    return;
  }

  const hostIsIp = /^\d{1,3}(?:\.\d{1,3}){3}$/.test(target.hostname) || target.hostname.startsWith("[");
  const hasPunycodeLabel = target.hostname.split(".").some((label) => label.startsWith("xn--"));
  const hasEmbeddedCredentials = Boolean(target.username || target.password);
  const executablePath = /\.(?:exe|msi|bat|cmd|scr|ps1|vbs|js)(?:$|\/)/i.test(target.pathname);
  const suspiciousReason = hasEmbeddedCredentials
    ? "L’adresse contient des identifiants intégrés."
    : hostIsIp
      ? "Le site utilise directement une adresse IP."
      : hasPunycodeLabel
        ? "Le nom de domaine contient un label international encodé. Vérifiez qu’il ne ressemble pas à une imitation."
        : executablePath
          ? "Le lien semble viser un fichier exécutable."
          : "";
  if (suspiciousReason && !window.confirm(`${suspiciousReason}\n\n${target.href}\n\nContinuer ?`)) {
    event.preventDefault();
    event.stopImmediatePropagation();
    return;
  }

  if (target.protocol === "http:" && !window.confirm(`Cette page utilise HTTP non chiffré :\n\n${target.href}\n\nContinuer malgré le risque d’interception ou de modification ?`)) {
    event.preventDefault();
    event.stopImmediatePropagation();
    return;
  }

  if (target.protocol === "http:") {
    event.preventDefault();
    event.stopImmediatePropagation();
    chrome.runtime.sendMessage({
      type: "confirmed-http-navigation",
      url: target.href,
      newTab: Boolean(anchor.target && anchor.target.toLowerCase() !== "_self")
    }).then((result) => {
      if (!result?.ok) window.alert("Discord Protect n’a pas pu ouvrir cette adresse HTTP.");
    }).catch(() => window.alert("Discord Protect n’a pas pu ouvrir cette adresse HTTP."));
    return;
  }

  if (target.protocol === "https:") {
    chrome.runtime.sendMessage({ type: "navigation-intent", url: target.href }).catch(() => undefined);
  }
}

function handleYoutubeAds() {
  if (!/(^|\.)youtube\.com$/.test(location.hostname) && location.hostname !== "youtube-nocookie.com") return;
  if (!protectionEnabled) return;

  for (const selector of youtubeSkipSelectors) {
    document.querySelectorAll(selector).forEach((button) => {
      if (button.getClientRects().length && !button.disabled) button.click();
    });
  }

  for (const selector of youtubeAdSelectors) {
    document.querySelectorAll(selector).forEach((element) => {
      if (handledElements.has(element)) return;
      handledElements.add(element);
      element.remove();
      recordBlocked();
    });
  }

  const player = document.querySelector("#movie_player.ad-showing");
  const video = player?.querySelector("video.html5-main-video");
  if (video && Number.isFinite(video.duration) && video.duration > 0 && video.currentTime < video.duration) {
    video.currentTime = video.duration;
  }
}

function handleSpotifyAds() {
  if (!/(^|\.)spotify\.com$/.test(location.hostname) || !protectionEnabled) return;

  for (const selector of spotifyAdSelectors) {
    document.querySelectorAll(selector).forEach((element) => {
      if (handledElements.has(element)) return;
      handledElements.add(element);
      element.remove();
      recordBlocked();
    });
  }
}

function isYoutubeShortsPage() {
  return protectionEnabled && /(^|\.)youtube\.com$/.test(location.hostname) && /^\/shorts\/[^/]+/.test(location.pathname);
}

function regularYoutubeUrl(urlValue) {
  try {
    const url = new URL(urlValue, location.href);
    if (!/(^|\.)youtube\.com$/.test(url.hostname)) return null;
    const videoId = url.pathname.match(/^\/shorts\/([^/?#]+)/)?.[1];
    if (!videoId) return null;
    return `https://www.youtube.com/watch?v=${encodeURIComponent(videoId)}`;
  } catch {
    return null;
  }
}

const rickrollVideoIds = new Set(["dqw4w9wgxcq"]);
const rickrollTextPattern = /rick\s*roll|rick\s*astley|never\s+gonna\s+give\s+you\s+up/i;

function hasRickrollText(value) {
  let decoded = String(value ?? "");
  try { decoded = decodeURIComponent(decoded.replace(/\+/g, " ")); } catch { /* Keep original text if malformed. */ }
  const normalized = decoded.replace(/[-_+]+/g, " ");
  return rickrollTextPattern.test(normalized);
}

function openRickrollWarning(target, newTab = false) {
  return chrome.runtime.sendMessage({
    type: "rickroll-warning-navigation",
    target,
    newTab
  });
}

function showRickrollWarning() {
  if (!antiRickrollEnabled || rickrollPageApproved || rickrollWarningRequested) return;
  rickrollWarningRequested = true;
  void openRickrollWarning(location.href)
    .then((result) => { if (!result?.ok) rickrollWarningRequested = false; })
    .catch(() => { rickrollWarningRequested = false; });
}

function isRickrollUrl(value) {
  try {
    const url = new URL(value, location.href);
    const videoId = url.searchParams.get("v")?.toLowerCase();
    const path = decodeURIComponent(url.pathname).toLowerCase();
    const videoHost = url.hostname === "youtu.be"
      || url.hostname === "youtube-nocookie.com"
      || url.hostname === "www.youtube-nocookie.com"
      || url.hostname === "youtube.com"
      || url.hostname.endsWith(".youtube.com");
    return rickrollVideoIds.has(videoId)
      || hasRickrollText(url.href)
      || (videoHost
        && rickrollVideoIds.has(path.split("/").filter(Boolean).at(-1)));
  } catch {
    return hasRickrollText(value);
  }
}

function isRickrollElement(element) {
  const metadata = [
    element.getAttribute("title"),
    element.getAttribute("aria-label"),
    element.getAttribute("alt"),
    element.getAttribute("data-title"),
    element.getAttribute("src"),
    element.getAttribute("href"),
    element.getAttribute("poster")
  ].filter(Boolean).join(" ");
  if (isRickrollUrl(metadata) || hasRickrollText(metadata)) return true;
  const link = element.closest("a[href]");
  if (link && isRickrollUrl(link.href)) return true;
  return false;
}

function blockRickrollElement(element) {
  if (!element?.isConnected || element.dataset.discordProtectRickroll === "true") return;
  const mediaElement = element.closest("video, iframe, img, a") ?? element;
  const link = element.closest("a[href]");
  let target = link?.href ?? "";
  if (!target) {
    for (const candidate of [element, mediaElement]) {
      for (const attribute of ["src", "href", "poster"]) {
        const value = candidate.getAttribute(attribute);
        if (value && isRickrollUrl(value)) {
          target = new URL(value, location.href).href;
          break;
        }
      }
      if (target) break;
    }
  }
  const replacement = document.createElement(target ? "button" : "div");
  replacement.dataset.discordProtectRickroll = "true";
  replacement.setAttribute("role", "note");
  replacement.textContent = target
    ? "Rickroll bloqué. Ouvrir la page d’avertissement"
    : "Média bloqué par Discord Protect (anti-Rickroll).";
  if (target) {
    replacement.type = "button";
    replacement.setAttribute("aria-label", "Ouvrir la page d’avertissement Rickroll");
    replacement.addEventListener("click", () => {
      void openRickrollWarning(target, Boolean(link?.target && link.target.toLowerCase() !== "_self"))
        .then((result) => { if (!result?.ok) replacement.disabled = false; })
        .catch(() => { replacement.disabled = false; });
      replacement.disabled = true;
    });
  }
  replacement.style.cssText = `display:flex;align-items:center;justify-content:center;min-height:72px;padding:16px;border:1px solid #d94a43;border-radius:8px;background:#17181d;color:#f5f3f1;font:600 13px/1.5 sans-serif;text-align:center${target ? ";cursor:pointer" : ""}`;
  mediaElement.replaceWith(replacement);
  recordBlocked();
}

function scanForRickrolls() {
  if (!protectionEnabled || !antiRickrollEnabled || rickrollPageApproved) return;
  const pageText = document.documentElement?.textContent ?? "";
  const normalizedPageText = pageText.toLowerCase();
  if (hasRickrollText(pageText) || [...rickrollVideoIds].some((videoId) => normalizedPageText.includes(videoId))) {
    showRickrollWarning();
  }
  for (const element of document.querySelectorAll("a[href], iframe[src], video, source[src], img[src], [title], [aria-label]")) {
    if (!isRickrollElement(element)) continue;
    showRickrollWarning();
    blockRickrollElement(element);
  }
}

function interceptRickrollLink(event) {
  if (!protectionEnabled || !antiRickrollEnabled || !event.isTrusted || event.button !== 0) return;
  const link = event.composedPath().find((node) => node instanceof HTMLAnchorElement);
  if (!link || !isRickrollUrl(link.href)) return;
  event.preventDefault();
  event.stopImmediatePropagation();
  void openRickrollWarning(link.href, Boolean(link.target && link.target.toLowerCase() !== "_self") || event.ctrlKey || event.metaKey || event.shiftKey)
    .then((result) => { if (!result?.ok) blockRickrollElement(link); })
    .catch(() => blockRickrollElement(link));
}

function convertYoutubeShortLinks() {
  if (!protectionEnabled || !youtubeShortsBlocked || !/(^|\.)youtube\.com$/.test(location.hostname)) return;
  for (const link of document.querySelectorAll("a[href*='/shorts/']")) {
    const regularUrl = regularYoutubeUrl(link.href);
    if (regularUrl && link.href !== regularUrl) link.href = regularUrl;
  }
  if (isYoutubeShortsPage() && !youtubeRedirectingToWatch) {
    const regularUrl = regularYoutubeUrl(location.href);
    if (!regularUrl) return;
    youtubeRedirectingToWatch = true;
    location.replace(regularUrl);
  }
}

function showYoutubeShortsWarning() {
  if (youtubePromptHost || youtubeShortsBlocked) return;
  youtubeShortScrollCount = 0;

  const host = document.createElement("div");
  host.id = "discord-protect-shorts-warning";
  host.style.cssText = "position:fixed;inset:0;z-index:2147483647";
  const root = host.attachShadow({ mode: "closed" });
  const style = document.createElement("style");
  style.textContent = `
    *{box-sizing:border-box} :host{font-family:Arial,sans-serif;color:#f5f3f1}
    .veil{position:fixed;inset:0;display:grid;place-items:center;padding:20px;background:#05060bcc;backdrop-filter:blur(7px)}
    .card{width:min(100%,480px);padding:26px;border:1px solid #ffffff24;border-radius:14px;background:#17181d;box-shadow:0 22px 80px #000b}
    .tag{margin:0 0 8px;color:#e4bc68;font-size:10px;font-weight:700;letter-spacing:1.4px}
    h2{margin:0 0 12px;font-size:23px;line-height:1.2} p{color:#c4c5ca;font-size:13px;line-height:1.65}
    .actions{display:flex;flex-wrap:wrap;gap:9px;margin-top:20px}
    button{min-height:40px;padding:0 14px;border:1px solid transparent;border-radius:5px;font:600 12px Arial,sans-serif;cursor:pointer}
    .block{background:linear-gradient(110deg,#ed3544,#e5ad43);color:#190c08}.ignore{border-color:#ffffff30;background:#26272d;color:#f5f3f1}
    button:focus-visible{outline:2px solid white;outline-offset:3px}@media(max-width:420px){button{flex:1 1 100%}}
  `;
  const veil = document.createElement("div");
  veil.className = "veil";
  const card = document.createElement("section");
  card.className = "card";
  card.setAttribute("role", "dialog");
  card.setAttribute("aria-modal", "true");
  card.setAttribute("aria-labelledby", "shorts-title");
  card.innerHTML = `<p class="tag">PETITE PAUSE</p><h2 id="shorts-title">Tu as enchaîné 10 Shorts</h2><p>Le défilement infini et la lecture immédiate encouragent à passer automatiquement au clip suivant. Les recommandations se réajustent à chaque visionnage et peuvent prolonger la session sans qu’on s’en rende compte.</p><p>Tu peux ouvrir ces liens comme des vidéos classiques, sans le flux vertical de Shorts.</p><div class="actions"><button class="block" id="block-shorts" type="button">Bloquer les Shorts</button><button class="ignore" id="ignore-shorts" type="button">Ignorer</button></div>`;
  veil.append(card);
  root.append(style, veil);
  document.body.append(host);
  youtubePromptHost = host;

  root.querySelector("#ignore-shorts").addEventListener("click", () => {
    host.remove();
    youtubePromptHost = null;
  });
  root.querySelector("#block-shorts").addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "set-youtube-shorts-blocked", enabled: true })
      .then((result) => {
        if (!result?.ok) throw new Error("Could not save Shorts preference");
        youtubeShortsBlocked = true;
        host.remove();
        youtubePromptHost = null;
        convertYoutubeShortLinks();
      })
      .catch(() => {
        card.querySelector(".tag").textContent = "RÉESSAIE";
      });
  });
}

function countYoutubeShortScroll(event) {
  if (!protectionEnabled || !isYoutubeShortsPage() || youtubeShortsBlocked || youtubePromptHost) return;
  const now = Date.now();
  if (now - youtubeLastScrollAt < 380) return;
  const scrollDown = event.type === "wheel"
    ? event.deltaY > 0
    : event.type === "touchend" && youtubeTouchStartY - event.changedTouches[0].clientY > 45;
  if (!scrollDown) return;
  youtubeLastScrollAt = now;
  youtubeShortScrollCount += 1;
  if (youtubeShortScrollCount >= 10) showYoutubeShortsWarning();
}

function handleYoutubeShortLink(event) {
  if (!protectionEnabled || !youtubeShortsBlocked || !/(^|\.)youtube\.com$/.test(location.hostname)) return;
  const link = event.composedPath().find((node) => node instanceof HTMLAnchorElement);
  const regularUrl = link && regularYoutubeUrl(link.href);
  if (!regularUrl) return;
  event.preventDefault();
  event.stopImmediatePropagation();
  location.assign(regularUrl);
}

function removeCookiePopups() {
  if (!protectionEnabled || !cookiePopupEnabled) return;

  const candidates = new Set(cookiePopupSelectors.flatMap((selector) => [...document.querySelectorAll(selector)]));
  let removedCookiePopup = false;

  for (const element of candidates) {
    if (!element.isConnected || handledElements.has(element) || !isVisible(element)) continue;
    const isCookieBackdrop = element.matches(".popup__backdrop");
    const label = `${element.id} ${typeof element.className === "string" ? element.className : ""} ${element.innerText ?? ""}`;
    const popup = element.parentElement;
    const pairedPopups = isCookieBackdrop && popup
      ? [...popup.children].filter((sibling) => sibling !== element && /popup|modal|dialog/i.test(`${sibling.id} ${sibling.className}`) && cookieText.test(sibling.innerText ?? ""))
      : [];
    if (isCookieBackdrop && !cookieText.test(label) && pairedPopups.length === 0) continue;
    if (!isCookieBackdrop && !cookieText.test(label)) continue;

    if (!isCookieBackdrop) removeRelatedBackdrops(element);
    handledElements.add(element);
    element.remove();
    for (const pairedPopup of pairedPopups) {
      handledElements.add(pairedPopup);
      pairedPopup.remove();
    }
    if (popup && popup !== document.body && popup.children.length === 0 && !popup.textContent.trim()) {
      handledElements.add(popup);
      popup.remove();
    }
    recordBlocked();
    removedCookiePopup = true;
  }

  if (removedCookiePopup) restorePageScroll();
}

function inspectPage() {
  cleanTrackingParameters();
  scanForRickrolls();
  handleYoutubeAds();
  handleSpotifyAds();
  updateDiscordTools();
  convertYoutubeShortLinks();

  if (protectionEnabled) {
    removeLargeAdPopups();
    removeCanYouBlockItAdSlots();
    const selectors = location.hostname === "adblock.turtlecute.org"
      ? [...adSelectors, ...testCosmeticSelectors]
      : adSelectors;
    for (const selector of selectors) {
      document.querySelectorAll(selector).forEach((element) => {
        if (handledElements.has(element)) return;
        handledElements.add(element);
        element.remove();
        recordBlocked();
      });
    }
  }

  removeCookiePopups();
}

chrome.storage.local.get(["protectionEnabled", "cookiePopupEnabled", "cookieRejectEnabled", "antiTrackingEnabled", "discordToolsEnabled", "antiRickrollEnabled", "youtubeShortsBlocked"]).then((state) => {
  protectionEnabled = state.protectionEnabled !== false;
  document.documentElement.dataset.dpProtectionEnabled = String(protectionEnabled);
  cookiePopupEnabled = (state.cookiePopupEnabled ?? state.cookieRejectEnabled) !== false;
  antiTrackingEnabled = state.antiTrackingEnabled !== false;
  discordToolsEnabled = state.discordToolsEnabled !== false;
  antiRickrollEnabled = state.antiRickrollEnabled !== false;
  youtubeShortsBlocked = state.youtubeShortsBlocked === true;
  return chrome.runtime.sendMessage({ type: "consume-rickroll-approval", url: location.href })
    .catch(() => ({ approved: false }));
}).then((approval) => {
  rickrollPageApproved = approval?.approved === true;
  updateDiscordTools();
  inspectPage();
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "local") return;
  if (changes.protectionEnabled) {
    protectionEnabled = changes.protectionEnabled.newValue !== false;
    document.documentElement.dataset.dpProtectionEnabled = String(protectionEnabled);
    if (!protectionEnabled) {
      cancelElementPicker();
      youtubePromptHost?.remove();
      youtubePromptHost = null;
    }
  }
  if (changes.cookiePopupEnabled) cookiePopupEnabled = changes.cookiePopupEnabled.newValue !== false;
  if (changes.antiTrackingEnabled) antiTrackingEnabled = changes.antiTrackingEnabled.newValue !== false;
  if (changes.discordToolsEnabled) discordToolsEnabled = changes.discordToolsEnabled.newValue !== false;
  if (changes.antiRickrollEnabled) {
    antiRickrollEnabled = changes.antiRickrollEnabled.newValue !== false;
    rickrollWarningRequested = false;
  }
  if (changes.youtubeShortsBlocked) youtubeShortsBlocked = changes.youtubeShortsBlocked.newValue === true;
  inspectPage();
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "start-element-picker") {
    if (!protectionEnabled) {
      sendResponse({ ok: false, reason: "Protection is disabled" });
      return;
    }
    startElementPicker();
    sendResponse({ ok: true });
    return;
  }

  const avatarCommands = new Set([
    "open-avatar-url-tool",
    "open-avatar-decoration-tool",
    "reset-avatar-customization"
  ]);
  if (avatarCommands.has(message?.type)) {
    if (!protectionEnabled || !discordToolsEnabled || location.hostname !== "discord.com") {
      sendResponse({ ok: false, reason: "Discord tools disabled" });
      return;
    }
    createDiscordPanel();
    discordPanelIsOpen = true;
    discordPanelRoot.querySelector(".panel").hidden = false;
    if (message.type === "open-avatar-url-tool") {
      setDiscordPanelStatus(contextAvatarImage ? "Avatar sélectionné. Entre une URL HTTPS." : "Clic droit sur un avatar pour le sélectionner.");
      discordPanelRoot.querySelector("#dp-avatar-url").focus();
    } else if (message.type === "open-avatar-decoration-tool") {
      setDiscordPanelStatus(contextAvatarImage ? "Choisis une couleur d’anneau." : "Clic droit sur un avatar pour le sélectionner.");
    } else {
      resetLocalAvatarChanges();
    }
    sendResponse({ ok: true });
    return;
  }

});

document.addEventListener("click", confirmLinkNavigation, true);
document.addEventListener("click", interceptRickrollLink, true);
document.addEventListener("contextmenu", captureContextAvatar, true);
document.addEventListener("click", handleYoutubeShortLink, true);
document.addEventListener("wheel", countYoutubeShortScroll, { passive: true });
document.addEventListener("touchstart", (event) => {
  if (event.touches.length) youtubeTouchStartY = event.touches[0].clientY;
}, { passive: true });
document.addEventListener("touchend", countYoutubeShortScroll, { passive: true });
if (/(^|\.)youtube\.com$/.test(location.hostname)) setInterval(handleYoutubeAds, 700);
if (/(^|\.)spotify\.com$/.test(location.hostname)) setInterval(handleSpotifyAds, 1000);

new MutationObserver(inspectPage).observe(document.documentElement, {
  childList: true,
  subtree: true,
  attributes: true,
  attributeFilter: ["href", "src", "poster", "title", "alt", "aria-label", "data-title"]
});
window.addEventListener("popstate", updateDiscordTools);

window.addEventListener("message", (event) => {
  if (event.source !== window || event.origin !== window.location.origin) return;
  const request = event.data;
  if (request?.type !== "DP_EXTENSION_PING" || typeof request.requestId !== "string") return;

  chrome.runtime.sendMessage({ type: "get-state" }).then((state) => {
    const protectionIsEnabled = state?.protectionEnabled !== false;
    window.postMessage({
      type: "DP_EXTENSION_PONG",
      requestId: request.requestId,
      protectionEnabled: protectionIsEnabled,
      cookiePopupEnabled: protectionIsEnabled && (state?.cookiePopupEnabled ?? state?.cookieRejectEnabled) !== false,
      antiTrackingEnabled: protectionIsEnabled && state?.antiTrackingEnabled !== false,
      discordToolsEnabled: protectionIsEnabled && state?.discordToolsEnabled !== false,
      antiRickrollEnabled: protectionIsEnabled && state?.antiRickrollEnabled !== false,
      productivityModeEnabled: protectionIsEnabled && state?.productivityModeEnabled === true,
      blockedToday: state?.blockedToday ?? 0
    }, window.location.origin);
  }).catch(() => undefined);
});
