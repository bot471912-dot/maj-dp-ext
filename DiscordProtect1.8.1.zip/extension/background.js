// SPDX-FileCopyrightText: 2026 Discord Protect project
// SPDX-License-Identifier: CC-BY-NC-SA-4.0
// https://creativecommons.org/licenses/by-nc-sa/4.0/
const RULESET_ID = "base_rules";
const ANTI_TRACKING_RULESET_ID = "anti_tracking_rules";
const DEFAULT_ENABLED = true;
const DEFAULT_COOKIE_POPUP_ENABLED = true;
const DEFAULT_ANTI_TRACKING_ENABLED = true;
const DEFAULT_DISCORD_TOOLS_ENABLED = true;
const DEFAULT_ANTI_RICKROLL_ENABLED = false;
const DEFAULT_PRODUCTIVITY_MODE_ENABLED = false;
const GOOGLEBOT_RULE_ID = 90001;
const GOOGLEBOT_USER_AGENT = "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)";
const RECENT_CLICK_WINDOW_MS = 5000;
const PRODUCTIVITY_RULE_ID_BASE = 1000;
const MAX_BLOCKED_SITES = 100;
let writes = Promise.resolve();

function recentClickKey(tabId) {
  return `recent-navigation-click:${tabId}`;
}

function approvedNavigationKey(tabId) {
  return `approved-navigation:${tabId}`;
}

function pendingNavigationKey(tabId) {
  return `pending-navigation:${tabId}`;
}

function rickrollApprovalKey(tabId) {
  return `rickroll-approved-once:${tabId}`;
}

function normalizeTrustedHostname(hostname) {
  return String(hostname ?? "").toLowerCase().replace(/\.$/, "");
}

function normalizeBlockedSite(value) {
  const input = String(value ?? "").trim();
  if (!input || (input.includes("://") && !/^https?:\/\//i.test(input))) return null;

  let parsed;
  try {
    parsed = new URL(/^https?:\/\//i.test(input) ? input : `https://${input}`);
  } catch {
    return null;
  }
  if ((parsed.protocol !== "http:" && parsed.protocol !== "https:") || parsed.username || parsed.password) return null;

  let hostname = normalizeTrustedHostname(parsed.hostname);
  if (hostname.startsWith("www.")) hostname = hostname.slice(4);
  return hostname || null;
}

function normalizeBlockedSites(values) {
  if (!Array.isArray(values)) return [];
  return [...new Set(values.map(normalizeBlockedSite).filter(Boolean))].slice(0, MAX_BLOCKED_SITES);
}

async function updateProductivityRules(enabled, blockedSites) {
  const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
  const removeRuleIds = existingRules
    .filter((rule) => rule.id >= PRODUCTIVITY_RULE_ID_BASE && rule.id < PRODUCTIVITY_RULE_ID_BASE + MAX_BLOCKED_SITES)
    .map((rule) => rule.id);
  const addRules = enabled
    ? blockedSites.slice(0, MAX_BLOCKED_SITES).map((domain, index) => ({
      id: PRODUCTIVITY_RULE_ID_BASE + index,
      priority: 1,
      action: { type: "block" },
      condition: { requestDomains: [domain], resourceTypes: ["main_frame"] }
    }))
    : [];

  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules });
}

function isTrustedRedirectHost(hostname, trustedDomains) {
  const candidate = normalizeTrustedHostname(hostname);
  return trustedDomains.some((domain) => {
    const trusted = normalizeTrustedHostname(domain);
    return candidate === trusted || candidate.endsWith(`.${trusted}`);
  });
}

function isRickrollDestination(value) {
  let target;
  try {
    target = new URL(value);
  } catch {
    return false;
  }
  const normalized = `${target.href} ${target.pathname} ${target.search}`.toLowerCase();
  return normalized.includes("dqw4w9wgxcq")
    || /rick\s*roll|rick\s*astley|never[+\s_-]+gonna[+\s_-]+give[+\s_-]+you[+\s_-]+up/i.test(normalized);
}

function currentDateKey() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

async function applyRules(enabled) {
  await chrome.declarativeNetRequest.updateEnabledRulesets({
    enableRulesetIds: enabled ? [RULESET_ID] : [],
    disableRulesetIds: enabled ? [] : [RULESET_ID]
  });
}

async function applyAntiTrackingRules(enabled) {
  await chrome.declarativeNetRequest.updateEnabledRulesets({
    enableRulesetIds: enabled ? [ANTI_TRACKING_RULESET_ID] : [],
    disableRulesetIds: enabled ? [] : [ANTI_TRACKING_RULESET_ID]
  });
}

async function applyNotificationBlocking(enabled) {
  if (enabled) {
    await chrome.contentSettings.notifications.set({
      primaryPattern: "<all_urls>",
      setting: "block",
      scope: "regular"
    });
    return;
  }
  await chrome.contentSettings.notifications.clear({ scope: "regular" });
}

function registerDiscordContextMenu() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "discord-protect-avatar-url",
      title: "Discord Protect : changer l’avatar local…",
      contexts: ["all"],
      documentUrlPatterns: ["https://discord.com/*"]
    });
    chrome.contextMenus.create({
      id: "discord-protect-avatar-decoration",
      title: "Discord Protect : décorer cet avatar…",
      contexts: ["all"],
      documentUrlPatterns: ["https://discord.com/*"]
    });
    chrome.contextMenus.create({
      id: "discord-protect-avatar-reset",
      title: "Discord Protect : retirer la personnalisation locale",
      contexts: ["all"],
      documentUrlPatterns: ["https://discord.com/*"]
    });
  });
}

async function initialize(resetSessionFeatures = false) {
  if (resetSessionFeatures) {
    await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [GOOGLEBOT_RULE_ID] });
    await chrome.storage.local.set({ googlebotTabId: null });
  }
  const state = await chrome.storage.local.get([
    "protectionEnabled",
    "cookiePopupEnabled",
    "cookieRejectEnabled",
    "antiTrackingEnabled",
    "discordToolsEnabled",
    "antiRickrollEnabled",
    "productivityModeEnabled",
    "blockedSites",
    "youtubeShortsBlocked",
    "blockedToday",
    "statsDate"
  ]);
  const statsDate = currentDateKey();
  const nextState = {
    protectionEnabled: state.protectionEnabled ?? DEFAULT_ENABLED,
    cookiePopupEnabled: state.cookiePopupEnabled ?? state.cookieRejectEnabled ?? DEFAULT_COOKIE_POPUP_ENABLED,
    antiTrackingEnabled: state.antiTrackingEnabled ?? DEFAULT_ANTI_TRACKING_ENABLED,
    discordToolsEnabled: state.discordToolsEnabled ?? DEFAULT_DISCORD_TOOLS_ENABLED,
    antiRickrollEnabled: state.antiRickrollEnabled ?? DEFAULT_ANTI_RICKROLL_ENABLED,
    productivityModeEnabled: state.productivityModeEnabled ?? DEFAULT_PRODUCTIVITY_MODE_ENABLED,
    blockedSites: normalizeBlockedSites(state.blockedSites),
    youtubeShortsBlocked: state.youtubeShortsBlocked ?? false,
    blockedToday: state.statsDate === statsDate ? (state.blockedToday ?? 0) : 0,
    statsDate
  };
  await chrome.storage.local.set(nextState);
  if (state.cookieRejectEnabled !== undefined) await chrome.storage.local.remove("cookieRejectEnabled");
  await applyRules(nextState.protectionEnabled);
  await applyAntiTrackingRules(nextState.antiTrackingEnabled);
  await applyNotificationBlocking(nextState.protectionEnabled);
  await updateProductivityRules(nextState.productivityModeEnabled, nextState.blockedSites);
}

chrome.runtime.onInstalled.addListener(() => {
  void initialize(true);
  registerDiscordContextMenu();
});
chrome.runtime.onStartup.addListener(() => void initialize(true));
void initialize();

chrome.contextMenus.onClicked.addListener((info, tab) => {
  const actions = {
    "discord-protect-avatar-url": "open-avatar-url-tool",
    "discord-protect-avatar-decoration": "open-avatar-decoration-tool",
    "discord-protect-avatar-reset": "reset-avatar-customization"
  };
  const type = actions[info.menuItemId];
  if (!type || !tab?.id) return;
  chrome.tabs.sendMessage(tab.id, { type }).catch(() => undefined);
});

chrome.webNavigation.onBeforeNavigate.addListener(async (details) => {
  if (details.frameId !== 0 || !/^https?:\/\//i.test(details.url)) return;

  const key = pendingNavigationKey(details.tabId);
  const stored = await chrome.storage.session.get(key);
  const previous = stored[key];
  const isContinuation = previous
    && previous.url !== details.url
    && details.timeStamp - previous.timeStamp < 15000;

  await chrome.storage.session.set({
    [key]: {
      url: details.url,
      timeStamp: details.timeStamp,
      redirectChain: Boolean(previous?.redirectChain || isContinuation)
    }
  });
});

chrome.webNavigation.onCommitted.addListener(async (details) => {
  if (details.frameId !== 0 || !/^https?:\/\//i.test(details.url)) return;

  const approvedKey = approvedNavigationKey(details.tabId);
  const clickKey = recentClickKey(details.tabId);
  const pendingKey = pendingNavigationKey(details.tabId);
  const stored = await chrome.storage.session.get([approvedKey, clickKey, pendingKey]);
  const approvedUrl = stored[approvedKey];
  const pendingNavigation = stored[pendingKey];
  if (approvedUrl === details.url) {
    await chrome.storage.session.remove([approvedKey, clickKey, pendingKey]);
    return;
  }

  const recentClickAt = stored[clickKey] ?? 0;
  const hasRecentClick = Date.now() - recentClickAt <= RECENT_CLICK_WINDOW_MS;
  const hasRedirectQualifier = details.transitionQualifiers.includes("client_redirect")
    || details.transitionQualifiers.includes("server_redirect");
  const wasRedirected = hasRedirectQualifier || Boolean(pendingNavigation?.redirectChain);
  const isInsecureHttp = details.url.startsWith("http://");
  const trustedState = isInsecureHttp
    ? { trustedRedirectDomains: [] }
    : await chrome.storage.local.get("trustedRedirectDomains");
  const trustedRedirectDomains = Array.isArray(trustedState.trustedRedirectDomains)
    ? trustedState.trustedRedirectDomains
    : [];
  const destinationIsTrusted = !isInsecureHttp
    && isTrustedRedirectHost(new URL(details.url).hostname, trustedRedirectDomains);
  const isRickrollNavigation = isRickrollDestination(details.url);
  const needsWarning = isRickrollNavigation
    || (wasRedirected && !hasRecentClick)
    || (isInsecureHttp && (!hasRecentClick || hasRedirectQualifier || Boolean(pendingNavigation?.redirectChain)));
  await chrome.storage.session.remove([clickKey, pendingKey]);
  if (!needsWarning || (wasRedirected && destinationIsTrusted && !isInsecureHttp && !isRickrollNavigation)) return;

  const warningPage = isInsecureHttp ? "http-warning.html" : "redirect-warning.html";
  const warningUrl = new URL(chrome.runtime.getURL(warningPage));
  warningUrl.searchParams.set("target", details.url);
  if (isRickrollNavigation) warningUrl.searchParams.set("reason", "rickroll");
  void chrome.tabs.update(details.tabId, { url: warningUrl.href });
});

chrome.webNavigation.onCreatedNavigationTarget.addListener(async (details) => {
  const sourceKey = recentClickKey(details.sourceTabId);
  const source = await chrome.storage.session.get(sourceKey);
  const clickedAt = source[sourceKey] ?? 0;
  if (Date.now() - clickedAt <= RECENT_CLICK_WINDOW_MS) {
    await chrome.storage.session.set({ [recentClickKey(details.tabId)]: clickedAt });
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  void chrome.storage.session.remove([recentClickKey(tabId), approvedNavigationKey(tabId), pendingNavigationKey(tabId), rickrollApprovalKey(tabId)]);
  chrome.storage.local.get("googlebotTabId").then((state) => {
    if (state.googlebotTabId !== tabId) return;
    chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [GOOGLEBOT_RULE_ID] })
      .then(() => chrome.storage.local.set({ googlebotTabId: null }))
      .catch(() => undefined);
  });
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "navigation-intent") {
    const tabId = _sender.tab?.id;
    if (Number.isInteger(tabId)) {
      chrome.storage.session.set({ [recentClickKey(tabId)]: Date.now() })
        .then(() => sendResponse({ ok: true }))
        .catch(() => sendResponse({ ok: false }));
      return true;
    }
    sendResponse({ ok: false });
    return;
  }

  if (message?.type === "confirmed-http-navigation") {
    const sourceTabId = _sender.tab?.id;
    const target = message.url;
    let parsedTarget;
    try {
      parsedTarget = new URL(target);
    } catch {
      sendResponse({ ok: false });
      return;
    }
    if (!Number.isInteger(sourceTabId) || parsedTarget.protocol !== "http:") {
      sendResponse({ ok: false });
      return;
    }

    if (message.newTab) {
      chrome.tabs.create({ url: "about:blank", active: true }).then((tab) => {
        const tabId = tab.id;
        return chrome.storage.session.set({
          [approvedNavigationKey(tabId)]: parsedTarget.href,
          [recentClickKey(tabId)]: Date.now()
        }).then(() => chrome.tabs.update(tabId, { url: parsedTarget.href }));
      }).then(() => sendResponse({ ok: true })).catch(() => sendResponse({ ok: false }));
    } else {
      chrome.storage.session.set({
        [approvedNavigationKey(sourceTabId)]: parsedTarget.href,
        [recentClickKey(sourceTabId)]: Date.now()
      }).then(() => chrome.tabs.update(sourceTabId, { url: parsedTarget.href }))
        .then(() => sendResponse({ ok: true }))
        .catch(() => sendResponse({ ok: false }));
    }
    return true;
  }

  if (message?.type === "rickroll-warning-navigation") {
    const sourceTabId = _sender.tab?.id;
    let target;
    try {
      target = new URL(message.target);
    } catch {
      sendResponse({ ok: false });
      return;
    }
    if (!Number.isInteger(sourceTabId) || (target.protocol !== "http:" && target.protocol !== "https:")) {
      sendResponse({ ok: false });
      return;
    }

    const warningUrl = new URL(chrome.runtime.getURL("redirect-warning.html"));
    warningUrl.searchParams.set("target", target.href);
    warningUrl.searchParams.set("reason", "rickroll");
    const opening = message.newTab
      ? chrome.tabs.create({ url: warningUrl.href, active: true })
      : chrome.tabs.update(sourceTabId, { url: warningUrl.href });
    opening.then(() => sendResponse({ ok: true })).catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "consume-rickroll-approval") {
    const tabId = _sender.tab?.id;
    let target;
    try {
      target = new URL(message.url);
    } catch {
      sendResponse({ approved: false });
      return;
    }
    if (!Number.isInteger(tabId) || (target.protocol !== "http:" && target.protocol !== "https:")) {
      sendResponse({ approved: false });
      return;
    }

    const key = rickrollApprovalKey(tabId);
    chrome.storage.session.get(key).then((state) => {
      const approved = state[key] === target.href;
      return chrome.storage.session.remove(key).then(() => sendResponse({ approved }));
    }).catch(() => sendResponse({ approved: false }));
    return true;
  }

  if (message?.type === "get-state") {
    chrome.storage.local.get(["protectionEnabled", "cookiePopupEnabled", "cookieRejectEnabled", "antiTrackingEnabled", "discordToolsEnabled", "antiRickrollEnabled", "productivityModeEnabled", "blockedSites", "youtubeShortsBlocked", "googlebotTabId", "blockedToday", "statsDate"]).then(async (state) => {
      const today = currentDateKey();
      if (state.statsDate !== today) {
        await chrome.storage.local.set({ blockedToday: 0, statsDate: today });
        state.blockedToday = 0;
      }
      sendResponse({
        protectionEnabled: state.protectionEnabled ?? DEFAULT_ENABLED,
        cookiePopupEnabled: state.cookiePopupEnabled ?? state.cookieRejectEnabled ?? DEFAULT_COOKIE_POPUP_ENABLED,
        antiTrackingEnabled: state.antiTrackingEnabled ?? DEFAULT_ANTI_TRACKING_ENABLED,
        discordToolsEnabled: state.discordToolsEnabled ?? DEFAULT_DISCORD_TOOLS_ENABLED,
        antiRickrollEnabled: state.antiRickrollEnabled ?? DEFAULT_ANTI_RICKROLL_ENABLED,
        productivityModeEnabled: state.productivityModeEnabled ?? DEFAULT_PRODUCTIVITY_MODE_ENABLED,
        blockedSites: normalizeBlockedSites(state.blockedSites),
        youtubeShortsBlocked: state.youtubeShortsBlocked === true,
        googlebotMode: Number.isInteger(message.tabId) && state.googlebotTabId === message.tabId,
        blockedToday: state.blockedToday ?? 0
      });
    });
    return true;
  }

  if (message?.type === "set-protection-state") {
    const enabled = Boolean(message.enabled);
    chrome.storage.local.set({ protectionEnabled: enabled })
      .then(() => applyRules(enabled))
      .then(() => applyNotificationBlocking(enabled))
      .then(() => sendResponse({ ok: true, protectionEnabled: enabled }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "set-cookie-popup-state") {
    const enabled = Boolean(message.enabled);
    chrome.storage.local.set({ cookiePopupEnabled: enabled })
      .then(() => sendResponse({ ok: true, cookiePopupEnabled: enabled }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "set-anti-tracking-state") {
    const enabled = Boolean(message.enabled);
    chrome.storage.local.set({ antiTrackingEnabled: enabled })
      .then(() => applyAntiTrackingRules(enabled))
      .then(() => sendResponse({ ok: true, antiTrackingEnabled: enabled }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "set-discord-tools-state") {
    const enabled = Boolean(message.enabled);
    chrome.storage.local.set({ discordToolsEnabled: enabled })
      .then(() => sendResponse({ ok: true, discordToolsEnabled: enabled }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "set-anti-rickroll-state") {
    const enabled = Boolean(message.enabled);
    chrome.storage.local.set({ antiRickrollEnabled: enabled })
      .then(() => sendResponse({ ok: true, antiRickrollEnabled: enabled }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "set-productivity-mode") {
    const enabled = Boolean(message.enabled);
    chrome.storage.local.get("blockedSites").then(async (state) => {
      const blockedSites = normalizeBlockedSites(state.blockedSites);
      await updateProductivityRules(enabled, blockedSites);
      await chrome.storage.local.set({ productivityModeEnabled: enabled, blockedSites });
      sendResponse({ ok: true, productivityModeEnabled: enabled, blockedSites });
    }).catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "add-blocked-site") {
    const domain = normalizeBlockedSite(message.domain);
    if (!domain) {
      sendResponse({ ok: false, reason: "invalid-domain" });
      return;
    }
    chrome.storage.local.get(["blockedSites", "productivityModeEnabled"]).then(async (state) => {
      const blockedSites = normalizeBlockedSites(state.blockedSites);
      if (blockedSites.includes(domain)) {
        sendResponse({ ok: true, blockedSites, duplicate: true });
        return;
      }
      if (blockedSites.length >= MAX_BLOCKED_SITES) {
        sendResponse({ ok: false, reason: "limit-reached" });
        return;
      }
      const nextBlockedSites = [...blockedSites, domain];
      await updateProductivityRules(state.productivityModeEnabled === true, nextBlockedSites);
      await chrome.storage.local.set({ blockedSites: nextBlockedSites });
      sendResponse({ ok: true, blockedSites: nextBlockedSites });
    }).catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "remove-blocked-site") {
    const domain = normalizeBlockedSite(message.domain);
    if (!domain) {
      sendResponse({ ok: false, reason: "invalid-domain" });
      return;
    }
    chrome.storage.local.get(["blockedSites", "productivityModeEnabled"]).then(async (state) => {
      const blockedSites = normalizeBlockedSites(state.blockedSites).filter((site) => site !== domain);
      await updateProductivityRules(state.productivityModeEnabled === true, blockedSites);
      await chrome.storage.local.set({ blockedSites });
      sendResponse({ ok: true, blockedSites });
    }).catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "set-youtube-shorts-blocked") {
    const enabled = Boolean(message.enabled);
    chrome.storage.local.set({ youtubeShortsBlocked: enabled })
      .then(() => sendResponse({ ok: true, youtubeShortsBlocked: enabled }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "set-googlebot-mode") {
    const tabId = message.tabId;
    const enabled = Boolean(message.enabled);
    if (!Number.isInteger(tabId) || tabId < 0) {
      sendResponse({ ok: false });
      return;
    }

    const addRules = enabled ? [{
      id: GOOGLEBOT_RULE_ID,
      priority: 2,
      action: {
        type: "modifyHeaders",
        requestHeaders: [{ header: "user-agent", operation: "set", value: GOOGLEBOT_USER_AGENT }]
      },
      condition: {
        tabIds: [tabId],
        resourceTypes: ["main_frame", "sub_frame", "stylesheet", "script", "image", "font", "object", "xmlhttprequest", "ping", "csp_report", "media", "websocket", "other"]
      }
    }] : [];

    chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: [GOOGLEBOT_RULE_ID],
      addRules
    }).then(() => chrome.storage.local.set({ googlebotTabId: enabled ? tabId : null }))
      .then(() => sendResponse({ ok: true, googlebotMode: enabled }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "confirm-redirect") {
    const target = message.target;
    const tabId = message.tabId;
    let parsedTarget;
    try {
      parsedTarget = new URL(target);
    } catch {
      sendResponse({ ok: false });
      return;
    }
    if (!Number.isInteger(tabId) || (parsedTarget.protocol !== "http:" && parsedTarget.protocol !== "https:")) {
      sendResponse({ ok: false });
      return;
    }

    const rememberDomain = Boolean(message.trustDomain) && parsedTarget.protocol === "https:";
    const saveApproval = rememberDomain
      ? chrome.storage.local.get("trustedRedirectDomains").then((state) => {
        const existingDomains = Array.isArray(state.trustedRedirectDomains) ? state.trustedRedirectDomains : [];
        const hostname = normalizeTrustedHostname(parsedTarget.hostname);
        const trustedRedirectDomains = [...new Set([...existingDomains.map(normalizeTrustedHostname), hostname])];
        return chrome.storage.local.set({ trustedRedirectDomains });
      })
      : Promise.resolve();

    const navigationApprovals = {
      [approvedNavigationKey(tabId)]: parsedTarget.href,
      [recentClickKey(tabId)]: Date.now()
    };
    if (message.skipRickrollOnce === true) navigationApprovals[rickrollApprovalKey(tabId)] = parsedTarget.href;
    saveApproval.then(() => chrome.storage.session.set(navigationApprovals))
      .then(() => chrome.tabs.update(tabId, { url: parsedTarget.href }))
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "go-back") {
    if (!Number.isInteger(message.tabId)) {
      sendResponse({ ok: false });
      return;
    }
    chrome.tabs.goBack(message.tabId)
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "factory-reset") {
    const resetOperation = writes.then(async () => {
      await chrome.storage.local.clear();
      await applyRules(DEFAULT_ENABLED);
      await applyAntiTrackingRules(DEFAULT_ANTI_TRACKING_ENABLED);
      await applyNotificationBlocking(DEFAULT_ENABLED);
      await updateProductivityRules(DEFAULT_PRODUCTIVITY_MODE_ENABLED, []);
      await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [GOOGLEBOT_RULE_ID] });
      await chrome.storage.local.set({
        protectionEnabled: DEFAULT_ENABLED,
        cookiePopupEnabled: DEFAULT_COOKIE_POPUP_ENABLED,
        antiTrackingEnabled: DEFAULT_ANTI_TRACKING_ENABLED,
        discordToolsEnabled: DEFAULT_DISCORD_TOOLS_ENABLED,
        antiRickrollEnabled: DEFAULT_ANTI_RICKROLL_ENABLED,
        productivityModeEnabled: DEFAULT_PRODUCTIVITY_MODE_ENABLED,
        blockedSites: [],
        youtubeShortsBlocked: false,
        googlebotTabId: null,
        blockedToday: 0,
        statsDate: currentDateKey()
      });
    });
    writes = resetOperation.catch(() => undefined);
    resetOperation.then(
      () => sendResponse({ ok: true }),
      () => sendResponse({ ok: false })
    );
    return true;
  }

  if (message?.type === "threat-blocked" && Number.isInteger(message.count) && message.count > 0) {
    writes = writes.then(async () => {
      const today = currentDateKey();
      const state = await chrome.storage.local.get(["blockedToday", "statsDate"]);
      const blockedToday = (state.statsDate === today ? (state.blockedToday ?? 0) : 0) + message.count;
      await chrome.storage.local.set({ blockedToday, statsDate: today });
    }).catch(() => undefined);
  }
});
