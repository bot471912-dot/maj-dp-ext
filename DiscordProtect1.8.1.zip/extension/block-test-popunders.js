// SPDX-FileCopyrightText: 2026 Discord Protect project
// SPDX-License-Identifier: CC-BY-NC-SA-4.0
// https://creativecommons.org/licenses/by-nc-sa/4.0/
const blockedOpen = () => null;
Object.defineProperty(window, "open", {
  configurable: false,
  get: () => blockedOpen,
  set: () => {}
});

document.addEventListener("click", (event) => {
  const link = event.composedPath().find((node) => node instanceof HTMLAnchorElement);
  if (!link) return;

  let destination;
  try {
    destination = new URL(link.href, location.href);
  } catch {
    return;
  }
  const isTestAdLink = destination.origin === location.origin
    && /\/extreme-test\/ad\.com(?:\/|$)/i.test(destination.pathname);
  const isAdNetworkLink = /(^|\.)(?:12ezo5v60\.com|fvcwqkkqmuv\.com|ybs2ffs7v\.com|adsco\.re|pncloudfl\.com|antiadblocksystems\.com)$/i.test(destination.hostname);
  if (!isTestAdLink && !isAdNetworkLink) return;

  event.preventDefault();
  event.stopImmediatePropagation();
}, true);
