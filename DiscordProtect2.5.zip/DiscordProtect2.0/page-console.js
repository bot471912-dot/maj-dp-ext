// SPDX-FileCopyrightText: 2026 Discord Protect project
// SPDX-License-Identifier: CC-BY-NC-SA-4.0
// https://creativecommons.org/licenses/by-nc-sa/4.0/
(() => {
  async function getTargetTab() {
    const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (Number.isInteger(activeTab?.id) && /^https?:\/\//i.test(activeTab.url ?? "")) return activeTab;

    const state = await chrome.storage.session.get("lastWebTabId");
    if (!Number.isInteger(state.lastWebTabId)) return null;
    try {
      const lastWebTab = await chrome.tabs.get(state.lastWebTabId);
      return /^https?:\/\//i.test(lastWebTab.url ?? "") ? lastWebTab : null;
    } catch {
      return null;
    }
  }

  async function execute(source) {
    const tab = await getTargetTab();
    if (!Number.isInteger(tab?.id)) {
      throw new Error("Ouvrez d’abord un site HTTP ou HTTPS dans un onglet.");
    }

    const [injection] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      func: async (command) => {
        const messages = [];
        const originals = new Map();
        const levels = ["debug", "info", "log", "warn", "error"];
        const format = (value) => {
          if (typeof value === "string") return value;
          if (value instanceof Error) return value.stack || `${value.name}: ${value.message}`;
          try {
            const serialized = JSON.stringify(value, null, 2);
            return typeof serialized === "undefined" ? String(value) : serialized;
          } catch {
            return String(value);
          }
        };

        for (const level of levels) {
          const descriptor = Object.getOwnPropertyDescriptor(console, level);
          const original = console[level];
          if (typeof original !== "function") continue;
          try {
            Object.defineProperty(console, level, {
              ...(descriptor || { configurable: true, enumerable: true, writable: true }),
              value: function (...args) {
                messages.push(args.map(format).join(" "));
                return Reflect.apply(original, this, args);
              }
            });
            originals.set(level, descriptor);
          } catch {
            // Keep running if the page prevents console interception.
          }
        }

        try {
          const value = await (0, eval)(command);
          let output;
          if (typeof value === "string") {
            output = value;
          } else if (typeof value === "undefined") {
            output = messages.length ? messages.join("\n") : "Aucune valeur renvoyée (undefined).";
          } else {
            try {
              output = JSON.stringify(value, null, 2);
            } catch {
              output = String(value);
            }
            if (typeof output === "undefined") output = String(value);
          }
          if (typeof value !== "undefined" && messages.length) output = `${messages.join("\n")}\n${output}`;
          return { ok: true, output };
        } catch (error) {
          return { ok: false, error: error instanceof Error ? error.message : String(error) };
        } finally {
          for (const [level, descriptor] of originals) {
            try {
              if (descriptor) Object.defineProperty(console, level, descriptor);
              else delete console[level];
            } catch {
              // A page may prevent restoring its console methods.
            }
          }
        }
      },
      args: [source]
    });
    if (!injection?.result?.ok) {
      throw new Error(injection?.result?.error || "La commande n’a pas pu être exécutée.");
    }
    return { tab, output: injection.result.output };
  }

  async function clearSiteCookies() {
    const tab = await getTargetTab();
    if (!Number.isInteger(tab?.id) || !tab.url) {
      throw new Error("Ouvre d’abord un site HTTP ou HTTPS dans un onglet.");
    }
    const target = new URL(tab.url);
    const hostname = target.hostname.toLowerCase();
    const labels = hostname.split(".");
    const domains = labels.map((_, index) => labels.slice(index).join("."));
    const matches = await Promise.all(domains.map((domain) => chrome.cookies.getAll({ domain })));
    const candidates = new Map();
    for (const cookies of matches) {
      for (const cookie of cookies) {
        const cookieDomain = cookie.domain.replace(/^\./, "").toLowerCase();
        const appliesToHost = hostname === cookieDomain
          || (cookie.domain.startsWith(".") && hostname.endsWith(`.${cookieDomain}`));
        if (!appliesToHost) continue;
        const partition = cookie.partitionKey ? JSON.stringify(cookie.partitionKey) : "";
        const key = `${cookie.storeId}\n${cookie.domain}\n${cookie.path}\n${cookie.name}\n${partition}`;
        candidates.set(key, cookie);
      }
    }

    const results = await Promise.allSettled([...candidates.values()].map(async (cookie) => {
      const cookieUrl = new URL(`${cookie.secure ? "https:" : target.protocol}//${hostname}`);
      cookieUrl.pathname = cookie.path || "/";
      const details = {
        url: cookieUrl.href,
        name: cookie.name,
        storeId: cookie.storeId
      };
      if (cookie.partitionKey) details.partitionKey = cookie.partitionKey;
      const removed = await chrome.cookies.remove(details);
      return removed !== null;
    }));
    const removed = results.filter((result) => result.status === "fulfilled" && result.value).length;
    const failures = results.length - removed;
    if (failures > 0) {
      throw new Error(`Suppression partielle pour ${hostname} : ${removed}/${results.length} cookies supprimés.`);
    }
    return { hostname, found: candidates.size, removed };
  }

  window.discordProtectPageConsole = { execute, getTargetTab, clearSiteCookies };
})();
