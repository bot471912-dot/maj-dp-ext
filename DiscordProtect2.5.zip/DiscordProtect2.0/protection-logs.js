// SPDX-FileCopyrightText: 2026 Discord Protect project
// SPDX-License-Identifier: CC-BY-NC-SA-4.0
// https://creativecommons.org/licenses/by-nc-sa/4.0/
const logsList = document.querySelector("#logs-list");
const logsStatus = document.querySelector("#logs-status");
const clearLogsButton = document.querySelector("#clear-logs");
const dateFormatter = new Intl.DateTimeFormat("fr-FR", {
  dateStyle: "medium",
  timeStyle: "medium"
});

function renderLogs(logs) {
  logsList.replaceChildren();
  const validLogs = logs.filter((entry) => entry
    && Number.isFinite(entry.timestamp)
    && !Number.isNaN(new Date(entry.timestamp).getTime())
    && typeof entry.hostname === "string"
    && Number.isInteger(entry.count)
    && entry.count > 0)
    .sort((first, second) => second.timestamp - first.timestamp);

  if (validLogs.length === 0) {
    const emptyState = document.createElement("li");
    emptyState.className = "empty-state";
    emptyState.textContent = "Aucune action de protection enregistrée pour le moment.";
    logsList.append(emptyState);
    logsStatus.textContent = "";
    return;
  }

  for (const entry of validLogs) {
    const item = document.createElement("li");
    item.className = "log-entry";
    const time = document.createElement("time");
    time.className = "log-time";
    time.dateTime = new Date(entry.timestamp).toISOString();
    time.textContent = dateFormatter.format(entry.timestamp);
    const type = document.createElement("span");
    const isRedirectWarning = typeof entry.type === "string" && entry.type.startsWith("redirect-");
    type.className = isRedirectWarning ? "log-type warning" : "log-type";
    if (isRedirectWarning) item.classList.add("warning-entry");
    type.textContent = isRedirectWarning
      ? "AVERTISSEMENT DE REDIRECTION"
      : "ACTION DE PROTECTION";
    const domain = document.createElement("span");
    domain.className = "log-domain";
    domain.textContent = entry.hostname;
    if (typeof entry.sourceHostname === "string" && entry.sourceHostname) {
      const source = document.createElement("span");
      source.className = "log-source";
      source.textContent = `Depuis ${entry.sourceHostname}`;
      domain.append(source);
    }
    const detail = document.createElement("span");
    detail.className = "log-detail";
    detail.textContent = typeof entry.detail === "string" && entry.detail
      ? entry.detail
      : entry.type === "page-action"
        ? "Action de protection détectée sur la page"
        : "Action enregistrée par Discord Protect";
    const count = document.createElement("span");
    count.className = "log-count";
    count.textContent = `${entry.count} action${entry.count === 1 ? "" : "s"} de protection`;
    item.append(time, type, domain, detail, count);
    logsList.append(item);
  }
  logsStatus.textContent = `${validLogs.length} entrée${validLogs.length === 1 ? "" : "s"} enregistrée${validLogs.length === 1 ? "" : "s"}.`;
}

async function loadLogs() {
  logsStatus.classList.remove("error");
  try {
    const result = await chrome.runtime.sendMessage({ type: "get-protection-logs" });
    if (!result?.ok || !Array.isArray(result.logs)) throw new Error("Logs unavailable");
    renderLogs(result.logs);
  } catch {
    logsStatus.classList.add("error");
    logsStatus.textContent = "Impossible de charger les logs. Réessayez en rechargeant cette page.";
  }
}

clearLogsButton.addEventListener("click", async () => {
  clearLogsButton.disabled = true;
  logsStatus.classList.remove("error");
  logsStatus.textContent = "Effacement…";
  try {
    const result = await chrome.runtime.sendMessage({ type: "clear-protection-logs" });
    if (!result?.ok) throw new Error("Log clearing failed");
    renderLogs([]);
  } catch {
    logsStatus.classList.add("error");
    logsStatus.textContent = "Impossible d’effacer les logs. Réessayez.";
  } finally {
    clearLogsButton.disabled = false;
  }
});

void loadLogs();
