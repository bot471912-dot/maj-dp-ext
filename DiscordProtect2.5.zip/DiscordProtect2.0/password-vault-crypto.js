// SPDX-FileCopyrightText: 2026 Discord Protect project
// SPDX-License-Identifier: CC-BY-NC-SA-4.0
// https://creativecommons.org/licenses/by-nc-sa/4.0/
(() => {
  const ITERATIONS = 250000;
  const encoder = new TextEncoder();
  const decoder = new TextDecoder();
  const VERIFIER = "Discord Protect password vault";

  function toBase64(bytes) {
    let binary = "";
    for (const byte of bytes) binary += String.fromCharCode(byte);
    return btoa(binary);
  }

  function fromBase64(value) {
    const binary = atob(value);
    return Uint8Array.from(binary, (character) => character.charCodeAt(0));
  }

  async function deriveKey(masterPassword, salt) {
    const material = await crypto.subtle.importKey(
      "raw",
      encoder.encode(masterPassword),
      "PBKDF2",
      false,
      ["deriveKey"]
    );
    return crypto.subtle.deriveKey(
      { name: "PBKDF2", salt, iterations: ITERATIONS, hash: "SHA-256" },
      material,
      { name: "AES-GCM", length: 256 },
      false,
      ["encrypt", "decrypt"]
    );
  }

  async function encryptText(key, value) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const ciphertext = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv },
      key,
      encoder.encode(value)
    );
    return { iv: toBase64(iv), ciphertext: toBase64(new Uint8Array(ciphertext)) };
  }

  async function decryptText(key, record) {
    const plaintext = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: fromBase64(record.iv) },
      key,
      fromBase64(record.ciphertext)
    );
    return decoder.decode(plaintext);
  }

  async function createVault(masterPassword) {
    const salt = crypto.getRandomValues(new Uint8Array(16));
    const key = await deriveKey(masterPassword, salt);
    return {
      salt: toBase64(salt),
      verifier: await encryptText(key, VERIFIER),
      entries: []
    };
  }

  async function unlockVault(masterPassword, vault) {
    if (!vault?.salt || !vault?.verifier || !Array.isArray(vault.entries)) {
      throw new Error("Coffre absent ou endommagé.");
    }
    const key = await deriveKey(masterPassword, fromBase64(vault.salt));
    let verifier;
    try {
      verifier = await decryptText(key, vault.verifier);
    } catch (error) {
      if (error.name === "OperationError") throw new Error("Mot de passe maître incorrect.");
      throw error;
    }
    if (verifier !== VERIFIER) throw new Error("Mot de passe maître incorrect.");
    return key;
  }

  globalThis.PasswordVaultCrypto = Object.freeze({
    createVault,
    decryptText,
    encryptText,
    unlockVault
  });
})();
