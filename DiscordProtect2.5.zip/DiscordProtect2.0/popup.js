// SPDX-FileCopyrightText: 2026 Discord Protect project
// SPDX-License-Identifier: CC-BY-NC-SA-4.0
// https://creativecommons.org/licenses/by-nc-sa/4.0/
const SITE_URL = "https://bot471912-dot.github.io/discordProtect/";
const BOT_URL = "https://discord.com/oauth2/authorize?client_id=1511044136340553849&permissions=8&scope=bot%20applications.commands";
// Chrome does not expose the extension's local folder name to its scripts.
const PACKAGE_FOLDER_VERSION = "2.0";
const UPDATE_REPOSITORY_URL = "https://api.github.com/repos/bot471912-dot/maj-dp-ext/contents/";
const UPDATE_CHECK_INTERVAL_MS = 6 * 60 * 60 * 1000;

const toggleButton = document.querySelector("#protection-toggle");
const statusText = document.querySelector("#status-text");
const statusDot = document.querySelector("#status-dot");
const statusDetail = document.querySelector("#status-detail");
const blockedCount = document.querySelector("#blocked-count");
const cookieToggle = document.querySelector("#cookie-toggle");
const cookieStatusText = document.querySelector("#cookie-status-text");
const cookieStatusDot = document.querySelector("#cookie-status-dot");
const cookieStatusDetail = document.querySelector("#cookie-status-detail");
const trackerToggle = document.querySelector("#tracker-toggle");
const trackerStatusText = document.querySelector("#tracker-status-text");
const trackerStatusDot = document.querySelector("#tracker-status-dot");
const trackerStatusDetail = document.querySelector("#tracker-status-detail");
const trackerSettingsButton = document.querySelector("#tracker-settings");
const discordToolsToggle = document.querySelector("#discord-tools-toggle");
const discordToolsStatusText = document.querySelector("#discord-tools-status-text");
const discordToolsStatusDot = document.querySelector("#discord-tools-status-dot");
const discordToolsStatusDetail = document.querySelector("#discord-tools-status-detail");
const shortsToggle = document.querySelector("#shorts-toggle");
const shortsStatusText = document.querySelector("#shorts-status-text");
const shortsStatusDot = document.querySelector("#shorts-status-dot");
const shortsStatusDetail = document.querySelector("#shorts-status-detail");
const rickrollToggle = document.querySelector("#rickroll-toggle");
const rickrollStatusText = document.querySelector("#rickroll-status-text");
const rickrollStatusDot = document.querySelector("#rickroll-status-dot");
const rickrollStatusDetail = document.querySelector("#rickroll-status-detail");
const nsfwToggle = document.querySelector("#nsfw-toggle");
const nsfwStatusText = document.querySelector("#nsfw-status-text");
const nsfwStatusDot = document.querySelector("#nsfw-status-dot");
const nsfwStatusDetail = document.querySelector("#nsfw-status-detail");
const productivityToggle = document.querySelector("#productivity-toggle");
const productivityStatusText = document.querySelector("#productivity-status-text");
const productivityStatusDot = document.querySelector("#productivity-status-dot");
const productivityStatusDetail = document.querySelector("#productivity-status-detail");
const blockedSiteForm = document.querySelector("#blocked-site-form");
const blockedSiteInput = document.querySelector("#blocked-site-input");
const blockedSitesList = document.querySelector("#blocked-sites-list");
const productivityNote = document.querySelector("#productivity-note");
const googlebotToggle = document.querySelector("#googlebot-toggle");
const googlebotStatusText = document.querySelector("#googlebot-status-text");
const googlebotStatusDot = document.querySelector("#googlebot-status-dot");
const googlebotStatusDetail = document.querySelector("#googlebot-status-detail");
const resetButton = document.querySelector("#factory-reset");
const resetStatus = document.querySelector("#reset-status");
const protectionLogsButton = document.querySelector("#protection-logs");
const fullConfigLink = document.querySelector("#full-config-link");
const configOpenStatus = document.querySelector("#config-open-status");
const pageCommandForm = document.querySelector("#page-command-form");
const pageCommandSection = document.querySelector("#page-command-section");
const pageCommandInput = document.querySelector("#page-command-input");
const pageCommandSubmit = document.querySelector("#page-command-submit");
const pageCommandStatus = document.querySelector("#page-command-status");
const developerModeToggle = document.querySelector("#developer-mode-toggle");
const developerTools = document.querySelector("#developer-tools");
const developerModeStatus = document.querySelector("#developer-mode-status");
const copyPageUrlButton = document.querySelector("#copy-page-url");
const reloadPageTabButton = document.querySelector("#reload-page-tab");
const clearSiteCookiesButton = document.querySelector("#clear-site-cookies");
const inspectPageElementButton = document.querySelector("#inspect-page-element");
const elementInspectionResult = document.querySelector("#element-inspection-result");
const copyElementSelectorButton = document.querySelector("#copy-element-selector");
const copyImageUrlButton = document.querySelector("#copy-image-url");
const pickElementButton = document.querySelector("#pick-element");
const pickerStatus = document.querySelector("#picker-status");
const updateNotice = document.querySelector("#update-available");
const updateNoticeTitle = document.querySelector("#update-notice-title");
const updateCheckStatus = document.querySelector("#update-check-status");
const updateDownload = document.querySelector("#update-download");
const updateVersion = document.querySelector("#update-version");
let activeTabId;

function compareVersions(firstVersion, secondVersion) {
  const first = firstVersion.split(".").map(Number);
  const second = secondVersion.split(".").map(Number);
  const length = Math.max(first.length, second.length);
  for (let index = 0; index < length; index += 1) {
    const difference = (first[index] ?? 0) - (second[index] ?? 0);
    if (difference !== 0) return Math.sign(difference);
  }
  return 0;
}

function setUpdateCheckStatus(message, isError = false) {
  if (!updateCheckStatus) return;
  updateCheckStatus.textContent = message;
  updateCheckStatus.classList.toggle("error", isError);
}

async function checkForUpdates() {
  if (!updateNotice || !updateNoticeTitle || !updateDownload || !updateVersion) return;
  try {
    const cached = await chrome.storage.local.get("latestUpdateCheck");
    let latest = cached.latestUpdateCheck;
    if (!latest
      || !Number.isFinite(latest.checkedAt)
      || Date.now() - latest.checkedAt >= UPDATE_CHECK_INTERVAL_MS
      || typeof latest.version !== "string"
      || typeof latest.zipName !== "string"
      || typeof latest.downloadUrl !== "string") {
      const response = await fetch(UPDATE_REPOSITORY_URL, {
        headers: { Accept: "application/vnd.github+json" },
        cache: "no-store"
      });
      if (!response.ok) throw new Error(`GitHub update check failed with status ${response.status}`);
      const files = await response.json();
      if (!Array.isArray(files)) throw new Error("GitHub returned an invalid file list");
      const packages = files.flatMap((file) => {
        if (file?.type !== "file" || typeof file.name !== "string") return [];
        const match = /^DiscordProtect(\d{1,6}(?:\.\d{1,6})*)\.zip$/i.exec(file.name);
        if (!match || typeof file.download_url !== "string") return [];
        try {
          const downloadUrl = new URL(file.download_url);
          if (downloadUrl.protocol !== "https:"
            || downloadUrl.hostname !== "raw.githubusercontent.com"
            || !downloadUrl.pathname.endsWith(`/${file.name}`)) return [];
          return [{ version: match[1], zipName: file.name, downloadUrl: downloadUrl.href }];
        } catch {
          return [];
        }
      });
      latest = packages.reduce((current, candidate) =>
        !current || compareVersions(candidate.version, current.version) > 0 ? candidate : current, null);
      if (!latest) throw new Error("No versioned extension archive was found on GitHub");
      latest.checkedAt = Date.now();
      await chrome.storage.local.set({ latestUpdateCheck: latest });
    }

    updateNotice.hidden = false;
    if (compareVersions(latest.version, PACKAGE_FOLDER_VERSION) > 0) {
      updateNoticeTitle.textContent = `Mise à jour disponible : ${latest.version}`;
      updateVersion.textContent = latest.version;
      updateDownload.hidden = false;
      updateDownload.href = latest.downloadUrl;
      updateDownload.setAttribute("aria-label", `Télécharger Discord Protect version ${latest.version}`);
      setUpdateCheckStatus(`Dossier utilisé : ${PACKAGE_FOLDER_VERSION} · dernière version GitHub : ${latest.version}.`);
      return;
    }

    updateNoticeTitle.textContent = "Discord Protect est à jour";
    updateVersion.textContent = PACKAGE_FOLDER_VERSION;
    updateDownload.hidden = true;
    updateDownload.removeAttribute("href");
    setUpdateCheckStatus(`Dossier utilisé : ${PACKAGE_FOLDER_VERSION} · dernière version GitHub : ${latest.version}.`);
  } catch (error) {
    console.error("Could not check for extension updates.", error);
    updateNotice.hidden = false;
    updateNoticeTitle.textContent = "Vérification des mises à jour indisponible";
    updateVersion.textContent = "";
    updateDownload.hidden = true;
    updateDownload.removeAttribute("href");
    setUpdateCheckStatus("Vérifie ta connexion et réessaie à la prochaine ouverture.", true);
  }
}

async function getCurrentState() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (/^https?:\/\//i.test(tab?.url ?? "")) {
    activeTabId = tab.id;
  } else {
    const state = await chrome.storage.session.get("lastWebTabId");
    activeTabId = Number.isInteger(state.lastWebTabId) ? state.lastWebTabId : undefined;
    if (Number.isInteger(activeTabId)) {
      try {
        const lastWebTab = await chrome.tabs.get(activeTabId);
        if (!/^https?:\/\//i.test(lastWebTab.url ?? "")) activeTabId = undefined;
      } catch {
        activeTabId = undefined;
      }
    }
  }
  return chrome.runtime.sendMessage({ type: "get-state", tabId: activeTabId });
}

function renderState(state) {
  const enabled = Boolean(state.protectionEnabled);
  toggleButton.setAttribute("aria-checked", String(enabled));
  statusText.textContent = enabled ? "Active" : "Désactivée";
  statusText.classList.toggle("off", !enabled);
  statusDot.classList.toggle("off", !enabled);
  statusDetail.textContent = enabled
    ? "Publicités, traceurs et notifications web bloqués"
    : "Toutes les protections sont en pause; tes préférences sont conservées";
  blockedCount.textContent = String(state.blockedToday ?? 0);

  const cookiePopupEnabled = enabled && Boolean(state.cookiePopupEnabled);
  cookieToggle.disabled = !enabled;
  cookieToggle.setAttribute("aria-checked", String(cookiePopupEnabled));
  cookieStatusText.textContent = cookiePopupEnabled ? "Actif" : "Désactivé";
  cookieStatusText.classList.toggle("off", !cookiePopupEnabled);
  cookieStatusDot.classList.toggle("off", !cookiePopupEnabled);
  cookieStatusDetail.textContent = !enabled
    ? "Protection générale désactivée (préférence conservée)"
    : cookiePopupEnabled ? "Supprime popup et backdrop compatibles" : "Le masquage est en pause";

  const antiTrackingEnabled = enabled && Boolean(state.antiTrackingEnabled);
  trackerToggle.disabled = !enabled;
  trackerToggle.setAttribute("aria-checked", String(antiTrackingEnabled));
  trackerStatusText.textContent = antiTrackingEnabled ? "Actif" : "Désactivé";
  trackerStatusText.classList.toggle("off", !antiTrackingEnabled);
  trackerStatusDot.classList.toggle("off", !antiTrackingEnabled);
  const fingerprintSettings = state.fingerprintSettings;
  trackerStatusDetail.textContent = !enabled
    ? "Protection générale désactivée (préférence conservée)"
    : antiTrackingEnabled
      ? fingerprintSettings?.enabled
        ? "Nettoie les liens et applique le profil fictif choisi ⚙"
        : "Nettoie les liens et masque le site précédent aux domaines tiers ⚙"
      : "Le nettoyage des liens et des référents est en pause ⚙";

  const discordToolsEnabled = enabled && Boolean(state.discordToolsEnabled);
  discordToolsToggle.disabled = !enabled;
  discordToolsToggle.setAttribute("aria-checked", String(discordToolsEnabled));
  discordToolsStatusText.textContent = discordToolsEnabled ? "Actif" : "Désactivé";
  discordToolsStatusText.classList.toggle("off", !discordToolsEnabled);
  discordToolsStatusDot.classList.toggle("off", !discordToolsEnabled);
  discordToolsStatusDetail.textContent = !enabled
    ? "Protection générale désactivée (préférence conservée)"
    : discordToolsEnabled ? "Personnalisation et infos visibles de profil" : "Outils Discord en pause";

  const shortsBlocked = enabled && Boolean(state.youtubeShortsBlocked);
  shortsToggle.disabled = !enabled;
  shortsToggle.setAttribute("aria-checked", String(shortsBlocked));
  shortsStatusText.textContent = shortsBlocked ? "Actif" : "Inactif";
  shortsStatusText.classList.toggle("off", !shortsBlocked);
  shortsStatusDot.classList.toggle("off", !shortsBlocked);
  shortsStatusDetail.textContent = !enabled
    ? "Protection générale désactivée"
    : shortsBlocked ? "Les Shorts s’ouvrent en vidéo classique" : "Alerte après 10 défilements vers le bas";

  const antiRickrollEnabled = enabled && Boolean(state.antiRickrollEnabled);
  rickrollToggle.disabled = !enabled;
  rickrollToggle.setAttribute("aria-checked", String(antiRickrollEnabled));
  rickrollStatusText.textContent = antiRickrollEnabled ? "Actif" : "Désactivé";
  rickrollStatusText.classList.toggle("off", !antiRickrollEnabled);
  rickrollStatusDot.classList.toggle("off", !antiRickrollEnabled);
  rickrollStatusDetail.textContent = !enabled
    ? "Protection générale désactivée (préférence conservée)"
    : antiRickrollEnabled ? "Bloque les vidéos et GIF reconnus" : "Détection anti-Rickroll en pause";

  const noNsfwEnabled = enabled && Boolean(state.noNsfwEnabled);
  nsfwToggle.disabled = !enabled;
  nsfwToggle.setAttribute("aria-checked", String(noNsfwEnabled));
  nsfwStatusText.textContent = noNsfwEnabled ? "Actif" : "Désactivé";
  nsfwStatusText.classList.toggle("off", !noNsfwEnabled);
  nsfwStatusDot.classList.toggle("off", !noNsfwEnabled);
  nsfwStatusDetail.textContent = !enabled
    ? "Protection générale désactivée (préférence conservée)"
    : noNsfwEnabled ? "Bloque domaines et URL explicites sans option ignorer" : "Blocage NSFW en pause";

  const googlebotMode = enabled && Boolean(state.googlebotMode);
  googlebotToggle.disabled = !enabled;
  googlebotToggle.setAttribute("aria-pressed", String(googlebotMode));
  googlebotToggle.textContent = googlebotMode ? "Désactiver" : "Activer";
  googlebotStatusText.textContent = googlebotMode ? "Actif" : "Inactif";
  googlebotStatusText.classList.toggle("off", !googlebotMode);
  googlebotStatusDot.classList.toggle("off", !googlebotMode);
  googlebotStatusDetail.textContent = !enabled
    ? "Protection générale désactivée"
    : googlebotMode ? "User-Agent émulé dans cet onglet" : "Émulation limitée à cet onglet";

  renderProductivityState(state);
  pickElementButton.disabled = !enabled;
  if (!enabled) pickerStatus.textContent = "Protection générale désactivée";
}

function renderProductivityState(state) {
  const protectionEnabled = Boolean(state.protectionEnabled);
  const enabled = protectionEnabled && Boolean(state.productivityModeEnabled);
  const sites = Array.isArray(state.blockedSites) ? state.blockedSites : [];
  productivityToggle.disabled = !protectionEnabled;
  productivityToggle.setAttribute("aria-checked", String(enabled));
  productivityStatusText.textContent = enabled ? "Actif" : "Désactivé";
  productivityStatusText.classList.toggle("off", !enabled);
  productivityStatusDot.classList.toggle("off", !enabled);
  productivityStatusDetail.textContent = !protectionEnabled
    ? `${sites.length} site${sites.length === 1 ? "" : "s"} enregistré${sites.length === 1 ? "" : "s"}, protection générale désactivée`
    : enabled
    ? `${sites.length} site${sites.length === 1 ? "" : "s"} bloqué${sites.length === 1 ? "" : "s"}`
    : sites.length
      ? `${sites.length} site${sites.length === 1 ? "" : "s"} enregistré${sites.length === 1 ? "" : "s"}, blocage en pause`
      : "Aucun site bloqué";

  blockedSitesList.replaceChildren();
  for (const domain of sites) {
    const row = document.createElement("li");
    row.className = "blocked-site-row";
    const label = document.createElement("span");
    label.className = "blocked-site-domain";
    label.textContent = domain;
    const removeButton = document.createElement("button");
    removeButton.className = "remove-site-button";
    removeButton.type = "button";
    removeButton.dataset.domain = domain;
    removeButton.textContent = "Débloquer";
    removeButton.setAttribute("aria-label", `Débloquer ${domain}`);
    row.append(label, removeButton);
    blockedSitesList.append(row);
  }
}

getCurrentState().then(renderState).catch(() => {
  statusText.textContent = "Indisponible";
  statusDetail.textContent = "Rechargez l’extension pour réessayer";
});
void checkForUpdates();

function setDeveloperMode(enabled) {
  const isEnabled = enabled === true;
  if (developerModeToggle) developerModeToggle.setAttribute("aria-checked", String(isEnabled));
  if (developerTools) developerTools.hidden = !isEnabled;
  if (pageCommandSection) pageCommandSection.hidden = !isEnabled;
  if (isEnabled) void showLatestElementInspection();
}

chrome.storage.local.get("developerModeEnabled")
  .then((state) => setDeveloperMode(state.developerModeEnabled))
  .catch((error) => {
    console.error("Could not read developer mode setting.", error);
    if (developerModeStatus) {
      developerModeStatus.classList.add("error");
      developerModeStatus.textContent = "Impossible de lire le réglage du mode développeur.";
    }
  });

protectionLogsButton.addEventListener("click", () => {
  void chrome.tabs.create({ url: chrome.runtime.getURL("protection-logs.html") });
});

developerModeToggle?.addEventListener("click", async () => {
  developerModeToggle.disabled = true;
  const enabled = developerModeToggle.getAttribute("aria-checked") !== "true";
  try {
    await chrome.storage.local.set({ developerModeEnabled: enabled });
    setDeveloperMode(enabled);
    if (developerModeStatus) {
      developerModeStatus.classList.remove("error");
      developerModeStatus.textContent = enabled
        ? "Mode développeur activé."
        : "Mode développeur désactivé.";
    }
  } catch (error) {
    console.error("Could not update developer mode setting.", error);
    if (developerModeStatus) {
      developerModeStatus.classList.add("error");
      developerModeStatus.textContent = "Impossible d’enregistrer le réglage. Réessaie.";
    }
  } finally {
    developerModeToggle.disabled = false;
  }
});

document.querySelectorAll(".developer-shortcut[data-command]").forEach((button) => {
  button.addEventListener("click", () => {
    if (pageCommandInput) {
      pageCommandInput.value = button.dataset.command;
      pageCommandInput.focus();
    }
  });
});

let inspectedElementDetails;

function renderElementInspection(result) {
  if (!elementInspectionResult) return;
  if (result?.cancelled) {
    inspectedElementDetails = undefined;
    elementInspectionResult.textContent = "Inspection annulée.";
  } else if (result?.details && typeof result.details.selector === "string") {
    inspectedElementDetails = result.details;
    elementInspectionResult.textContent = JSON.stringify(result.details, null, 2);
  } else {
    inspectedElementDetails = undefined;
    elementInspectionResult.textContent = "Sélectionne « Inspecter un élément », puis clique sur un élément dans l’onglet web.";
  }
  if (copyElementSelectorButton) copyElementSelectorButton.disabled = !inspectedElementDetails?.selector;
  if (copyImageUrlButton) copyImageUrlButton.disabled = !inspectedElementDetails?.image?.url;
}

async function showLatestElementInspection(tabId) {
  if (!elementInspectionResult) return;
  try {
    const targetTab = Number.isInteger(tabId)
      ? await chrome.tabs.get(tabId)
      : await window.discordProtectPageConsole.getTargetTab();
    if (!Number.isInteger(targetTab?.id)) return;
    const key = `developer-element-inspection:${targetTab.id}`;
    const stored = await chrome.storage.session.get(key);
    const result = stored[key];
    if (!result) return;
    await chrome.storage.session.remove(key);
    renderElementInspection(result);
  } catch (error) {
    console.error("Could not read developer element inspection.", error);
    elementInspectionResult.textContent = "Impossible de lire le résultat d’inspection.";
  }
}

inspectPageElementButton?.addEventListener("click", async () => {
  inspectPageElementButton.disabled = true;
  pageCommandStatus.classList.remove("error");
  pageCommandStatus.textContent = "Préparation du sélecteur…";
  renderElementInspection(null);
  try {
    const settings = await chrome.storage.local.get("developerModeEnabled");
    if (settings.developerModeEnabled !== true) throw new Error("Active le mode développeur pour utiliser l’inspecteur.");
    const targetTab = await window.discordProtectPageConsole.getTargetTab();
    if (!Number.isInteger(targetTab?.id)) throw new Error("Aucun onglet web actif à inspecter.");
    if (document.body.dataset.fullConfig !== "true") {
      await chrome.storage.session.set({ lastWebTabId: targetTab.id });
      await chrome.tabs.create({
        url: `${chrome.runtime.getURL("config.html")}?inspectElement=1`
      });
      return;
    }
    const resultKey = `developer-element-inspection:${targetTab.id}`;
    await chrome.storage.session.remove(resultKey);
    try {
      await chrome.tabs.sendMessage(targetTab.id, { type: "start-developer-element-inspection" });
    } catch {
      await chrome.scripting.executeScript({ target: { tabId: targetTab.id }, files: ["content.js"] });
      await chrome.tabs.sendMessage(targetTab.id, { type: "start-developer-element-inspection" });
    }
    pageCommandStatus.textContent = "Clique sur un élément de la page. Appuie sur Échap pour annuler.";
    const startedAt = Date.now();
    while (Date.now() - startedAt < 90000) {
      await new Promise((resolve) => setTimeout(resolve, 400));
      const stored = await chrome.storage.session.get(resultKey);
      if (stored[resultKey]) {
        await chrome.storage.session.remove(resultKey);
        renderElementInspection(stored[resultKey]);
        pageCommandStatus.textContent = stored[resultKey].cancelled
          ? "Inspection annulée."
          : "Élément inspecté. Les détails sont affichés ci-dessus.";
        return;
      }
    }
    pageCommandStatus.textContent = "Délai d’inspection dépassé. Relance la sélection.";
  } catch (error) {
    console.error("Could not start developer element inspection.", error);
    pageCommandStatus.classList.add("error");
    pageCommandStatus.textContent = String(error?.message ?? "Impossible de démarrer l’inspecteur.");
  } finally {
    inspectPageElementButton.disabled = false;
  }
});

if (document.body.dataset.fullConfig === "true"
  && new URLSearchParams(location.search).get("inspectElement") === "1") {
  const cleanUrl = new URL(location.href);
  cleanUrl.searchParams.delete("inspectElement");
  history.replaceState(null, "", cleanUrl.href);
  setTimeout(() => inspectPageElementButton?.click(), 0);
}

async function copyInspectionValue(value, description) {
  if (!value) return;
  try {
    await navigator.clipboard.writeText(value);
    pageCommandStatus.classList.remove("error");
    pageCommandStatus.textContent = `${description} copié.`;
  } catch (error) {
    console.error(`Could not copy ${description.toLowerCase()}.`, error);
    pageCommandStatus.classList.add("error");
    pageCommandStatus.textContent = `Impossible de copier ${description.toLowerCase()}.`;
  }
}

copyElementSelectorButton?.addEventListener("click", () => {
  void copyInspectionValue(inspectedElementDetails?.selector, "Sélecteur CSS");
});

copyImageUrlButton?.addEventListener("click", () => {
  void copyInspectionValue(inspectedElementDetails?.image?.url, "URL de l’image");
});

copyPageUrlButton?.addEventListener("click", async () => {
  try {
    const tab = await window.discordProtectPageConsole.getTargetTab();
    if (!tab?.url) throw new Error("Aucun onglet web actif à copier.");
    await navigator.clipboard.writeText(tab.url);
    pageCommandStatus.classList.remove("error");
    pageCommandStatus.textContent = `URL copiée : ${tab.url}`;
  } catch (error) {
    console.error("Could not copy the active page URL.", error);
    pageCommandStatus.classList.add("error");
    pageCommandStatus.textContent = String(error?.message ?? "Impossible de copier l’URL.");
  }
});

reloadPageTabButton?.addEventListener("click", async () => {
  try {
    const tab = await window.discordProtectPageConsole.getTargetTab();
    if (!Number.isInteger(tab?.id)) throw new Error("Aucun onglet web actif à recharger.");
    await chrome.tabs.reload(tab.id);
    pageCommandStatus.classList.remove("error");
    pageCommandStatus.textContent = "Rechargement de l’onglet demandé.";
  } catch (error) {
    console.error("Could not reload the active page.", error);
    pageCommandStatus.classList.add("error");
    pageCommandStatus.textContent = String(error?.message ?? "Impossible de recharger l’onglet.");
  }
});

clearSiteCookiesButton?.addEventListener("click", async () => {
  const confirmed = window.confirm(
    "Supprimer les cookies du domaine du site ouvert, y compris les cookies HttpOnly ? Tu peux être déconnecté de ce site."
  );
  if (!confirmed) return;

  clearSiteCookiesButton.disabled = true;
  pageCommandStatus.classList.remove("error");
  pageCommandStatus.textContent = "Suppression des cookies du site…";
  try {
    const result = await window.discordProtectPageConsole.clearSiteCookies();
    pageCommandStatus.textContent = result.removed
      ? `${result.removed} cookie(s) supprimé(s) pour ${result.hostname}.`
      : `Aucun cookie trouvé pour ${result.hostname}.`;
  } catch (error) {
    console.error("Could not clear cookies for the active site.", error);
    pageCommandStatus.classList.add("error");
    pageCommandStatus.textContent = String(error?.message ?? "Impossible de supprimer les cookies.");
  } finally {
    clearSiteCookiesButton.disabled = false;
  }
});

pageCommandForm?.addEventListener("submit", async (event) => {
  event.preventDefault();
  const source = pageCommandInput.value.trim();
  if (!source) return;

  pageCommandSubmit.disabled = true;
  pageCommandStatus.classList.remove("error");
  pageCommandStatus.textContent = "Exécution…";
  try {
    const result = await window.discordProtectPageConsole.execute(source);
    pageCommandStatus.classList.remove("error");
    pageCommandStatus.textContent = `Résultat : ${result.output}`;
  } catch (error) {
    console.error("Could not execute a page command.", error);
    pageCommandStatus.classList.add("error");
    pageCommandStatus.textContent = String(error?.message ?? "Impossible d’exécuter cette commande.");
  } finally {
    pageCommandSubmit.disabled = false;
  }
});

fullConfigLink?.addEventListener("click", async (event) => {
  event.preventDefault();
  configOpenStatus.textContent = "";
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (Number.isInteger(tab?.id) && /^https?:\/\//i.test(tab.url ?? "")) {
      await chrome.storage.session.set({ lastWebTabId: tab.id });
    }
    await chrome.tabs.create({ url: chrome.runtime.getURL("config.html") });
  } catch (error) {
    console.error("Could not open the full configuration page.", error);
    configOpenStatus.textContent = "Impossible d’ouvrir la configuration complète.";
  }
});

toggleButton.addEventListener("click", async () => {
  toggleButton.disabled = true;
  try {
    const current = await getCurrentState();
    const result = await chrome.runtime.sendMessage({
      type: "set-protection-state",
      enabled: !current.protectionEnabled
    });
    if (result?.ok) renderState({ ...current, protectionEnabled: result.protectionEnabled });
  } catch {
    statusDetail.textContent = "Impossible de modifier la protection";
  } finally {
    toggleButton.disabled = false;
  }
});

cookieToggle.addEventListener("click", async () => {
  cookieToggle.disabled = true;
  try {
    const current = await getCurrentState();
    const result = await chrome.runtime.sendMessage({
      type: "set-cookie-popup-state",
      enabled: !current.cookiePopupEnabled
    });
    if (result?.ok) renderState({ ...current, cookiePopupEnabled: result.cookiePopupEnabled });
  } catch {
    cookieStatusDetail.textContent = "Impossible de modifier le masquage";
  } finally {
    cookieToggle.disabled = false;
  }
});

googlebotToggle.addEventListener("click", async () => {
  googlebotToggle.disabled = true;
  try {
    const current = await getCurrentState();
    if (!Number.isInteger(activeTabId)) throw new Error("No active tab");
    const result = await chrome.runtime.sendMessage({
      type: "set-googlebot-mode",
      enabled: !current.googlebotMode,
      tabId: activeTabId
    });
    if (!result?.ok) throw new Error("User-Agent override rejected");
    renderState({ ...current, googlebotMode: result.googlebotMode });
  } catch {
    googlebotStatusDetail.textContent = "Chrome n’a pas accepté le changement de User-Agent";
  } finally {
    googlebotToggle.disabled = false;
  }
});

trackerToggle.addEventListener("click", async () => {
  trackerToggle.disabled = true;
  try {
    const current = await getCurrentState();
    const result = await chrome.runtime.sendMessage({
      type: "set-anti-tracking-state",
      enabled: !current.antiTrackingEnabled
    });
    if (result?.ok) renderState({ ...current, antiTrackingEnabled: result.antiTrackingEnabled });
  } catch {
    trackerStatusDetail.textContent = "Impossible de modifier l’anti-traceurs";
  } finally {
    trackerToggle.disabled = false;
  }
});

trackerSettingsButton.addEventListener("click", () => {
  chrome.tabs.create({ url: chrome.runtime.getURL("privacy-settings.html") }).catch(() => {
    trackerStatusDetail.textContent = "Impossible d’ouvrir les réglages de confidentialité";
  });
});

discordToolsToggle.addEventListener("click", async () => {
  discordToolsToggle.disabled = true;
  try {
    const current = await getCurrentState();
    const result = await chrome.runtime.sendMessage({
      type: "set-discord-tools-state",
      enabled: !current.discordToolsEnabled
    });
    if (result?.ok) renderState({ ...current, discordToolsEnabled: result.discordToolsEnabled });
  } catch {
    discordToolsStatusDetail.textContent = "Impossible de modifier les outils Discord";
  } finally {
    discordToolsToggle.disabled = false;
  }
});

shortsToggle.addEventListener("click", async () => {
  shortsToggle.disabled = true;
  try {
    const current = await getCurrentState();
    const result = await chrome.runtime.sendMessage({
      type: "set-youtube-shorts-blocked",
      enabled: !current.youtubeShortsBlocked
    });
    if (result?.ok) renderState({ ...current, youtubeShortsBlocked: result.youtubeShortsBlocked });
  } catch {
    shortsStatusDetail.textContent = "Impossible de modifier ce réglage";
  } finally {
    shortsToggle.disabled = false;
  }
});

rickrollToggle.addEventListener("click", async () => {
  rickrollToggle.disabled = true;
  try {
    const current = await getCurrentState();
    const result = await chrome.runtime.sendMessage({
      type: "set-anti-rickroll-state",
      enabled: !current.antiRickrollEnabled
    });
    if (result?.ok) renderState({ ...current, antiRickrollEnabled: result.antiRickrollEnabled });
  } catch {
    rickrollStatusDetail.textContent = "Impossible de modifier l’anti-Rick Roll";
  } finally {
    rickrollToggle.disabled = false;
  }
});

nsfwToggle.addEventListener("click", async () => {
  nsfwToggle.disabled = true;
  try {
    const current = await getCurrentState();
    const result = await chrome.runtime.sendMessage({
      type: "set-no-nsfw-state",
      enabled: !current.noNsfwEnabled
    });
    if (result?.ok) renderState({ ...current, noNsfwEnabled: result.noNsfwEnabled });
    else nsfwStatusDetail.textContent = "Impossible de modifier le blocage No NSFW";
  } catch {
    nsfwStatusDetail.textContent = "Impossible de modifier le blocage No NSFW";
  } finally {
    nsfwToggle.disabled = false;
  }
});

productivityToggle.addEventListener("click", async () => {
  productivityToggle.disabled = true;
  try {
    const current = await getCurrentState();
    const result = await chrome.runtime.sendMessage({
      type: "set-productivity-mode",
      enabled: !current.productivityModeEnabled
    });
    if (!result?.ok) throw new Error("Productivity mode update failed");
    renderState({ ...current, ...result });
    productivityNote.textContent = result.productivityModeEnabled ? "Blocage activé." : "Blocage mis en pause; la liste est conservée.";
  } catch {
    productivityNote.textContent = "Impossible de modifier le mode Productivité.";
  } finally {
    productivityToggle.disabled = false;
  }
});

blockedSiteForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const submitButton = blockedSiteForm.querySelector("button[type='submit']");
  submitButton.disabled = true;
  try {
    const result = await chrome.runtime.sendMessage({
      type: "add-blocked-site",
      domain: blockedSiteInput.value
    });
    if (!result?.ok) {
      productivityNote.textContent = result?.reason === "limit-reached"
        ? "La liste peut contenir au maximum 100 sites."
        : "Entre un nom de domaine valide, par exemple exemple.com.";
      return;
    }
    renderProductivityState({
      productivityModeEnabled: productivityToggle.getAttribute("aria-checked") === "true",
      blockedSites: result.blockedSites
    });
    productivityNote.textContent = result.duplicate ? "Ce site est déjà dans la liste." : `${result.blockedSites.at(-1)} ajouté à la liste.`;
    blockedSiteInput.value = "";
  } catch {
    productivityNote.textContent = "Impossible d’enregistrer ce site.";
  } finally {
    submitButton.disabled = false;
  }
});

blockedSitesList.addEventListener("click", async (event) => {
  const removeButton = event.target.closest(".remove-site-button");
  if (!removeButton) return;
  removeButton.disabled = true;
  const domain = removeButton.dataset.domain;
  try {
    const result = await chrome.runtime.sendMessage({ type: "remove-blocked-site", domain });
    if (!result?.ok) throw new Error("Could not remove blocked site");
    renderProductivityState({
      productivityModeEnabled: productivityToggle.getAttribute("aria-checked") === "true",
      blockedSites: result.blockedSites
    });
    productivityNote.textContent = `${domain} retiré de la liste.`;
  } catch {
    productivityNote.textContent = `Impossible de débloquer ${domain}.`;
    removeButton.disabled = false;
  }
});

pickElementButton.addEventListener("click", async () => {
  pickElementButton.disabled = true;
  pickerStatus.textContent = "Cliquez sur un élément à retirer; Échap annule.";
  try {
    const tab = Number.isInteger(activeTabId) ? await chrome.tabs.get(activeTabId) : null;
    if (!tab?.id || !/^https?:\/\//i.test(tab.url ?? "")) throw new Error("No active web tab");
    let response;
    try {
      response = await chrome.tabs.sendMessage(tab.id, { type: "start-element-picker" });
    } catch {
      response = null;
    }
    if (!response?.ok) {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
      response = await chrome.tabs.sendMessage(tab.id, { type: "start-element-picker" });
    }
    if (!response?.ok) throw new Error("Picker unavailable");
    if (document.body.dataset.fullConfig !== "true") window.close();
    else {
      pickerStatus.textContent = "Sélection active dans l’onglet. Échap pour annuler.";
      pickElementButton.disabled = false;
    }
  } catch (error) {
    const message = String(error?.message ?? "");
    pickerStatus.textContent = /Cannot access|cannot be scripted|extensions|host permission/i.test(message)
      ? "Chrome interdit la sélection sur cette page (page système ou Chrome Web Store)."
      : "Sélection indisponible. Rechargez la page et réessayez.";
    pickElementButton.disabled = false;
  }
});

resetButton.addEventListener("click", async () => {
  const confirmed = window.confirm("Réinitialiser Discord Protect ? Les réglages, le compteur et le coffre chiffré seront effacés.");
  if (!confirmed) return;

  resetButton.disabled = true;
  resetStatus.textContent = "Réinitialisation…";
  try {
    const result = await chrome.runtime.sendMessage({ type: "factory-reset" });
    if (!result?.ok) throw new Error("Factory reset failed");
    const state = await getCurrentState();
    renderState(state);
    resetStatus.textContent = "Paramètres réinitialisés. Compteur remis à zéro.";
  } catch {
    resetStatus.textContent = "Échec de la réinitialisation. Réessayez.";
  } finally {
    resetButton.disabled = false;
  }
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === "local" && changes.developerModeEnabled) {
    setDeveloperMode(changes.developerModeEnabled.newValue);
  }
  if (areaName === "session" && elementInspectionResult) {
    void showLatestElementInspection();
  }
  if (areaName === "local" && (changes.blockedToday || changes.protectionEnabled || changes.cookiePopupEnabled || changes.antiTrackingEnabled || changes.discordToolsEnabled || changes.antiRickrollEnabled || changes.noNsfwEnabled || changes.productivityModeEnabled || changes.blockedSites || changes.youtubeShortsBlocked || changes.googlebotTabId)) {
    getCurrentState().then(renderState).catch(() => undefined);
  }
});

document.querySelector("#website-link").href = SITE_URL;
document.querySelector("#bot-link").href = BOT_URL;
