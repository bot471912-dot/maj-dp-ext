// SPDX-FileCopyrightText: 2026 Discord Protect project
// SPDX-License-Identifier: CC-BY-NC-SA-4.0
// https://creativecommons.org/licenses/by-nc-sa/4.0/
const form = document.querySelector("#credential-form");
const siteInput = document.querySelector("#site");
const usernameInput = document.querySelector("#username");
const passwordInput = document.querySelector("#password");
const masterPasswordInput = document.querySelector("#master-password");
const confirmMasterInput = document.querySelector("#confirm-master-password");
const confirmLabel = document.querySelector("#confirm-label");
const masterHelp = document.querySelector("#master-help");
const formStatus = document.querySelector("#form-status");
const credentialList = document.querySelector("#credential-list");
const emptyState = document.querySelector("#empty-state");

async function getVault() {
  const stored = await chrome.storage.local.get("passwordVault");
  return stored.passwordVault ?? null;
}

function renderVault(vault) {
  credentialList.replaceChildren();
  const entries = vault?.entries ?? [];
  emptyState.hidden = entries.length > 0;
  for (const entry of entries) {
    const row = document.createElement("li");
    row.className = "credential-row";
    const details = document.createElement("div");
    details.className = "credential-details";
    const origin = document.createElement("strong");
    origin.textContent = entry.origin;
    const username = document.createElement("span");
    username.textContent = "Identifiant chiffré";
    const remove = document.createElement("button");
    remove.className = "delete-button";
    remove.type = "button";
    remove.textContent = "Supprimer";
    remove.addEventListener("click", () => deleteEntry(entry.id));
    details.append(origin, username);
    row.append(details, remove);
    credentialList.append(row);
  }
}

function updateMasterFields(vault) {
  const creating = !vault;
  confirmMasterInput.hidden = !creating;
  confirmLabel.hidden = !creating;
  confirmMasterInput.required = creating;
  masterPasswordInput.autocomplete = creating ? "new-password" : "current-password";
  masterPasswordInput.minLength = creating ? 12 : 1;
  masterHelp.textContent = creating
    ? "Choisis au moins 12 caractères. Ce mot de passe ne peut pas être récupéré."
    : "Saisis ton mot de passe maître pour chiffrer ce nouvel identifiant.";
}

function normalizeOrigin(value) {
  const parsed = new URL(value);
  if (!["http:", "https:"].includes(parsed.protocol) || parsed.username || parsed.password) {
    throw new Error("Utilise une adresse de site HTTP ou HTTPS valide.");
  }
  return parsed.origin;
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  formStatus.textContent = "";
  const submitButton = form.querySelector("button[type='submit']");
  submitButton.disabled = true;
  let masterPassword = masterPasswordInput.value;
  try {
    const origin = normalizeOrigin(siteInput.value.trim());
    const username = usernameInput.value.trim();
    const password = passwordInput.value;
    let vault = await getVault();
    if (!vault) {
      if (masterPassword.length < 12) throw new Error("Le mot de passe maître doit contenir au moins 12 caractères.");
      if (masterPassword !== confirmMasterInput.value) throw new Error("Les mots de passe maître ne correspondent pas.");
      vault = await PasswordVaultCrypto.createVault(masterPassword);
    }

    const key = await PasswordVaultCrypto.unlockVault(masterPassword, vault);
    const encrypted = await PasswordVaultCrypto.encryptText(key, JSON.stringify({ username, password }));
    vault.entries.push({
      id: crypto.randomUUID(),
      origin,
      ...encrypted
    });
    await chrome.storage.local.set({ passwordVault: vault });
    renderVault(vault);
    form.reset();
    masterPassword = "";
    formStatus.textContent = "Identifiant chiffré et enregistré sur cet appareil.";
    updateMasterFields(vault);
  } catch (error) {
    formStatus.textContent = error.message || "Impossible d’enregistrer cet identifiant.";
  } finally {
    masterPassword = "";
    masterPasswordInput.value = "";
    confirmMasterInput.value = "";
    passwordInput.value = "";
    submitButton.disabled = false;
  }
});

async function deleteEntry(id) {
  if (!window.confirm("Supprimer cet identifiant chiffré ?")) return;
  try {
    const vault = await getVault();
    vault.entries = vault.entries.filter((entry) => entry.id !== id);
    await chrome.storage.local.set({ passwordVault: vault });
    renderVault(vault);
    formStatus.textContent = "Identifiant supprimé.";
  } catch (error) {
    formStatus.textContent = error.message || "Impossible de supprimer cet identifiant.";
  }
}

getVault()
  .then((vault) => {
    updateMasterFields(vault);
    renderVault(vault);
  })
  .catch((error) => {
    formStatus.textContent = error.message || "Impossible de lire le coffre.";
  });
