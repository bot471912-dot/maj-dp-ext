// SPDX-FileCopyrightText: 2026 Discord Protect project
// SPDX-License-Identifier: CC-BY-NC-SA-4.0
// https://creativecommons.org/licenses/by-nc-sa/4.0/
const query = new URLSearchParams(location.search);
const rawTarget = query.get("target") ?? "";
const reason = query.get("reason");
const targetElement = document.querySelector("#target-url");
const titleElement = document.querySelector("#warning-title");
const copyElement = document.querySelector("#warning-copy");
const statusElement = document.querySelector("#status");
const continueButton = document.querySelector("#continue-button");
const backButton = document.querySelector("#back-button");
const trustOption = document.querySelector("#trust-option");
const trustDomainCheckbox = document.querySelector("#trust-domain-checkbox");
const trustDomainLabel = document.querySelector("#trust-domain-label");
let targetUrl;
const isRickrollWarning = reason === "rickroll";
const isNsfwWarning = reason === "nsfw";

try {
  targetUrl = new URL(rawTarget);
  if (targetUrl.protocol !== "http:" && targetUrl.protocol !== "https:") throw new Error("Unsupported URL scheme");
  targetElement.textContent = targetUrl.href;
  if (targetUrl.protocol === "https:") {
    trustDomainLabel.textContent = `Toujours autoriser ${targetUrl.hostname} et ses sous-domaines`;
  } else {
    trustOption.hidden = true;
  }
} catch {
  targetElement.textContent = "Adresse invalide";
  continueButton.disabled = true;
  trustOption.hidden = true;
}

if (isNsfwWarning) {
  document.title = "Contenu bloqué | Discord Protect";
  titleElement.textContent = "Contenu NSFW bloqué";
  copyElement.textContent = "La destination correspond à un domaine adulte connu ou contient des mots-clés explicites dans son adresse. Le mode No NSFW ne permet pas de continuer.";
  trustOption.hidden = true;
  continueButton.hidden = true;
} else if (isRickrollWarning) {
  document.title = "Rickroll à confirmer | Discord Protect";
  titleElement.textContent = "Avertissement anti-Rickroll";
  copyElement.textContent = "Ce contenu correspond à un Rickroll connu ou à un lien qui y mène. Vérifiez la destination avant de continuer.";
  trustOption.hidden = true;
  continueButton.textContent = "Continuer quand même";
} else if (reason === "http" || targetUrl?.protocol === "http:") {
  titleElement.textContent = "Connexion HTTP non sécurisée";
  copyElement.textContent = "Cette adresse utilise HTTP. Les données échangées peuvent être interceptées ou modifiées.";
} else {
  titleElement.textContent = "Redirection automatique détectée";
  copyElement.textContent = "Aucun clic récent n’a été associé à cette navigation. Vérifiez l’adresse avant de continuer.";
}

continueButton.addEventListener("click", async () => {
  continueButton.disabled = true;
  backButton.disabled = true;
  statusElement.textContent = "Ouverture de la destination…";
  try {
    const tab = await chrome.tabs.getCurrent();
    const result = await chrome.runtime.sendMessage({
      type: "confirm-redirect",
      target: targetUrl.href,
      trustDomain: trustDomainCheckbox.checked,
      skipRickrollOnce: isRickrollWarning,
      tabId: tab?.id
    });
    if (!result?.ok) throw new Error("Navigation could not continue");
  } catch {
    statusElement.textContent = "Impossible d’ouvrir cette destination.";
    continueButton.disabled = false;
    backButton.disabled = false;
  }
});

backButton.addEventListener("click", async () => {
  backButton.disabled = true;
  statusElement.textContent = "Retour à la page précédente…";
  try {
    const tab = await chrome.tabs.getCurrent();
    const result = await chrome.runtime.sendMessage({ type: "go-back", tabId: tab?.id });
    if (!result?.ok) statusElement.textContent = "Aucune page précédente. Vous pouvez fermer cet onglet.";
  } catch {
    statusElement.textContent = "Aucune page précédente. Vous pouvez fermer cet onglet.";
    backButton.disabled = false;
  }
});
