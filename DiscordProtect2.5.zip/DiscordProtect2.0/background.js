// SPDX-FileCopyrightText: 2026 Discord Protect project
// SPDX-License-Identifier: CC-BY-NC-SA-4.0
// https://creativecommons.org/licenses/by-nc-sa/4.0/
importScripts("password-vault-crypto.js");

const RULESET_ID = "base_rules";
const ANTI_TRACKING_RULESET_ID = "anti_tracking_rules";
const DEFAULT_ENABLED = true;
const DEFAULT_COOKIE_POPUP_ENABLED = true;
const DEFAULT_ANTI_TRACKING_ENABLED = true;
const DEFAULT_DISCORD_TOOLS_ENABLED = true;
const DEFAULT_ANTI_RICKROLL_ENABLED = false;
const DEFAULT_NO_NSFW_ENABLED = true;
const DEFAULT_PRODUCTIVITY_MODE_ENABLED = false;
const DEFAULT_DEVELOPER_MODE_ENABLED = false;
const GOOGLEBOT_RULE_ID = 90001;
const GOOGLEBOT_USER_AGENT = "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)";
const FINGERPRINT_RULE_ID = 90002;
const DEFAULT_FINGERPRINT_SETTINGS = Object.freeze({
  enabled: false,
  platform: "windows",
  customUserAgent: "",
  timezone: "UTC",
  maskUserAgent: true,
  maskTimezone: true,
  maskBattery: true,
  maskHardware: true,
  maskScreen: true
});
const FINGERPRINT_PROFILES = Object.freeze({
  windows: Object.freeze({
    platform: "Win32",
    clientHintPlatform: "Windows",
    platformVersion: "15.0.0",
    uaPlatform: "Windows NT 10.0; Win64; x64",
    architecture: "x86",
    screen: Object.freeze({ width: 1440, height: 900, availableHeight: 860, pixelRatio: 1 }),
    cores: 8,
    memory: 8,
    batteryLevel: 0.75
  }),
  mac: Object.freeze({
    platform: "MacIntel",
    clientHintPlatform: "macOS",
    platformVersion: "14.0.0",
    uaPlatform: "Macintosh; Intel Mac OS X 10_15_7",
    architecture: "x86",
    screen: Object.freeze({ width: 1440, height: 900, availableHeight: 860, pixelRatio: 2 }),
    cores: 8,
    memory: 8,
    batteryLevel: 0.75
  }),
  linux: Object.freeze({
    platform: "Linux x86_64",
    clientHintPlatform: "Linux",
    platformVersion: "",
    uaPlatform: "X11; Linux x86_64",
    architecture: "x86",
    screen: Object.freeze({ width: 1366, height: 768, availableHeight: 728, pixelRatio: 1 }),
    cores: 8,
    memory: 8,
    batteryLevel: 0.75
  })
});
const RECENT_CLICK_WINDOW_MS = 5000;
const PRODUCTIVITY_RULE_ID_BASE = 1000;
const MAX_BLOCKED_SITES = 100;
const MAX_PROTECTION_LOG_ENTRIES = 200;
const PROTECTION_LOG_DETAILS = Object.freeze({
  "page-action": "Action de protection détectée sur la page",
  "popup-blocked": "Fenêtre surgissante indésirable retirée",
  "ad-blocked": "Publicité retirée ou neutralisée",
  "element-removed": "Élément de page retiré à la demande",
  "tracking-cleaned": "Paramètres de suivi retirés d’un lien",
  "redirect-blocked": "Redirection hors du domaine autorisé bloquée",
  "rickroll-blocked": "Contenu Rick Roll bloqué",
  "nsfw-blocked": "Lien vers un contenu explicite bloqué",
  "cookie-popup-removed": "Fenêtre de consentement aux cookies masquée",
  "redirect-http-warning": "Avertissement affiché : destination en HTTP non sécurisé",
  "redirect-suspicious-warning": "Avertissement affiché : redirection inattendue",
  "redirect-nsfw-warning": "Avertissement affiché : destination explicite bloquée",
  "redirect-rickroll-warning": "Avertissement affiché : destination Rick Roll bloquée"
});
let writes = Promise.resolve();

function queueProtectionLogs(entries) {
  if (entries.length === 0) return Promise.resolve();
  const operation = writes.then(async () => {
    const state = await chrome.storage.local.get("protectionLogs");
    const logs = Array.isArray(state.protectionLogs) ? state.protectionLogs : [];
    logs.push(...entries.map((entry) => ({
      timestamp: Date.now(),
      hostname: entry.hostname,
      ...(entry.sourceHostname ? { sourceHostname: entry.sourceHostname } : {}),
      type: entry.type,
      detail: PROTECTION_LOG_DETAILS[entry.type],
      count: entry.count
    })));
    await chrome.storage.local.set({
      protectionLogs: logs.slice(-MAX_PROTECTION_LOG_ENTRIES)
    });
  });
  writes = operation.catch((error) => console.error("Could not record protection logs.", error));
  return operation;
}

function makeRedirectLog(type, targetUrl, sourceUrl) {
  const target = new URL(targetUrl);
  if (target.protocol !== "http:" && target.protocol !== "https:") {
    throw new Error("Protection log target must use HTTP or HTTPS.");
  }
  let sourceHostname;
  try {
    const source = new URL(sourceUrl);
    if (source.protocol === "http:" || source.protocol === "https:") sourceHostname = source.hostname;
  } catch {
    sourceHostname = undefined;
  }
  return {
    type,
    hostname: target.hostname,
    ...(sourceHostname ? { sourceHostname } : {}),
    count: 1
  };
}

function recentClickKey(tabId) {
  return `recent-navigation-click:${tabId}`;
}

function approvedNavigationKey(tabId) {
  return `approved-navigation:${tabId}`;
}

function pendingNavigationKey(tabId) {
  return `pending-navigation:${tabId}`;
}

function extensionNavigationKey(tabId) {
  return `extension-navigation:${tabId}`;
}

function movixTargetKey(tabId) {
  return `movix-origin:${tabId}`;
}

function rickrollApprovalKey(tabId) {
  return `rickroll-approved-once:${tabId}`;
}

function normalizeFingerprintSettings(value) {
  const settings = value && typeof value === "object" ? value : {};
  const customUserAgent = typeof settings.customUserAgent === "string"
    && settings.customUserAgent.length <= 256
    && /^[\x20-\x7E]*$/.test(settings.customUserAgent)
    ? settings.customUserAgent.trim()
    : "";
  let timezone = "UTC";
  if (typeof settings.timezone === "string") {
    try {
      new Intl.DateTimeFormat("en-US", { timeZone: settings.timezone });
      timezone = settings.timezone;
    } catch {
      timezone = "UTC";
    }
  }
  return {
    enabled: settings.enabled === true,
    platform: Object.hasOwn(FINGERPRINT_PROFILES, settings.platform) ? settings.platform : DEFAULT_FINGERPRINT_SETTINGS.platform,
    customUserAgent,
    timezone,
    maskUserAgent: settings.maskUserAgent !== false,
    maskTimezone: settings.maskTimezone !== false,
    maskBattery: settings.maskBattery !== false,
    maskHardware: settings.maskHardware !== false,
    maskScreen: settings.maskScreen !== false
  };
}

function getFingerprintUserAgent(settings) {
  const majorVersion = navigator.userAgent.match(/(?:Chrome|Chromium)\/(\d+)/)?.[1] ?? "131";
  const profile = FINGERPRINT_PROFILES[settings.platform];
  return settings.customUserAgent
    || `Mozilla/5.0 (${profile.uaPlatform}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${majorVersion}.0.0.0 Safari/537.36`;
}

async function updateFingerprintUserAgentRule(settings, enabled, googlebotTabId) {
  const existing = await chrome.declarativeNetRequest.getSessionRules();
  const removeRuleIds = existing.filter((rule) => rule.id === FINGERPRINT_RULE_ID).map((rule) => rule.id);
  const addRules = enabled && settings.enabled && settings.maskUserAgent
    ? [{
      id: FINGERPRINT_RULE_ID,
      priority: 1,
      action: {
        type: "modifyHeaders",
        requestHeaders: [
          {
            header: "user-agent",
            operation: "set",
            value: getFingerprintUserAgent(settings)
          }
        ]
      },
      condition: {
        ...(Number.isInteger(googlebotTabId) ? { excludeTabIds: [googlebotTabId] } : {}),
        resourceTypes: ["main_frame", "sub_frame", "stylesheet", "script", "image", "font", "object", "xmlhttprequest", "ping", "csp_report", "media", "websocket", "other"]
      }
    }]
    : [];
  await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds, addRules });
}

function applyPageFingerprint(settings, profile, enabled) {
  const key = Symbol.for("discordProtect.fingerprintState");
  const previous = window[key];
  if (previous?.restore) previous.restore();
  if (!enabled) {
    delete window[key];
    return { enabled: false, applied: 0, failed: [] };
  }

  const changes = [];
  const failed = [];
  const patch = (target, property, descriptor) => {
    const original = Object.getOwnPropertyDescriptor(target, property);
    try {
      Object.defineProperty(target, property, { ...descriptor, configurable: true });
      changes.push(() => {
        const current = Object.getOwnPropertyDescriptor(target, property);
        if (!current || current.get !== descriptor.get && current.value !== descriptor.value) return;
        if (original) Object.defineProperty(target, property, original);
        else delete target[property];
      });
    } catch {
      failed.push(property);
      return;
    }
  };

  const brandMajor = navigator.userAgent.match(/(?:Chrome|Chromium)\/(\d+)/)?.[1] ?? "131";
  const brands = [
    { brand: "Not(A:Brand", version: "8" },
    { brand: "Chromium", version: brandMajor },
    { brand: "Google Chrome", version: brandMajor }
  ];
  if (settings.maskUserAgent) {
    const userAgent = settings.customUserAgent
      || `Mozilla/5.0 (${profile.uaPlatform}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${brandMajor}.0.0.0 Safari/537.36`;
    patch(Navigator.prototype, "userAgent", { get: () => userAgent });
    patch(Navigator.prototype, "platform", { get: () => profile.platform });
    const userAgentData = {
      brands,
      mobile: false,
      platform: profile.clientHintPlatform,
      getHighEntropyValues: async (hints = []) => {
        const highEntropy = {
          architecture: profile.architecture,
          bitness: "64",
          brands,
          fullVersionList: brands.map((brand) => ({ ...brand, version: brand.brand === "Not(A:Brand" ? "8.0.0.0" : `${brandMajor}.0.0.0` })),
          mobile: false,
          model: "",
          platform: profile.clientHintPlatform,
          platformVersion: profile.platformVersion,
          uaFullVersion: `${brandMajor}.0.0.0`,
          wow64: false
        };
        return Object.fromEntries(["brands", "mobile", "platform", ...hints].filter((hint) => hint in highEntropy).map((hint) => [hint, highEntropy[hint]]));
      },
      toJSON: () => ({ brands, mobile: false, platform: profile.clientHintPlatform })
    };
    patch(Navigator.prototype, "userAgentData", { get: () => userAgentData });
  }
  if (settings.maskTimezone) {
    const OriginalDateTimeFormat = Intl.DateTimeFormat;
    const timezone = settings.timezone || "UTC";
    const WrappedDateTimeFormat = function (locales, options = {}) {
      const formatterOptions = options && typeof options === "object" ? options : {};
      return new OriginalDateTimeFormat(locales, { ...formatterOptions, timeZone: formatterOptions.timeZone ?? timezone });
    };
    Object.setPrototypeOf(WrappedDateTimeFormat, OriginalDateTimeFormat);
    WrappedDateTimeFormat.prototype = OriginalDateTimeFormat.prototype;
    patch(Intl, "DateTimeFormat", { value: WrappedDateTimeFormat, writable: true });
    const partsFormatter = new OriginalDateTimeFormat("en-US-u-ca-gregory-nu-latn", {
      timeZone: timezone,
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hourCycle: "h23"
    });
    const getParts = (date) => {
      const values = Object.fromEntries(partsFormatter.formatToParts(date).map((part) => [part.type, part.value]));
      return {
        year: Number(values.year),
        month: Number(values.month),
        day: Number(values.day),
        hour: Number(values.hour),
        minute: Number(values.minute),
        second: Number(values.second),
        millisecond: date.getUTCMilliseconds()
      };
    };
    const getOffset = (timestamp) => {
      const date = new Date(timestamp);
      const parts = getParts(date);
      return Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour, parts.minute, parts.second)
        - Math.floor(timestamp / 1000) * 1000;
    };
    const fromParts = (parts) => {
      const wallTime = Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour, parts.minute, parts.second, parts.millisecond);
      let timestamp = wallTime;
      for (let pass = 0; pass < 3; pass += 1) timestamp = wallTime - getOffset(timestamp);
      return timestamp;
    };
    const localGetters = {
      getDate: (parts) => parts.day,
      getDay: (parts) => new Date(Date.UTC(parts.year, parts.month - 1, parts.day)).getUTCDay(),
      getFullYear: (parts) => parts.year,
      getHours: (parts) => parts.hour,
      getMilliseconds: (parts) => parts.millisecond,
      getMinutes: (parts) => parts.minute,
      getMonth: (parts) => parts.month - 1,
      getSeconds: (parts) => parts.second,
      getYear: (parts) => parts.year - 1900
    };
    for (const [method, getValue] of Object.entries(localGetters)) {
      patch(Date.prototype, method, {
        value: function () {
          return getValue(getParts(new Date(Date.prototype.getTime.call(this))));
        },
        writable: true
      });
    }
    patch(Date.prototype, "getTimezoneOffset", {
      value: function () {
        return -getOffset(Date.prototype.getTime.call(this)) / 60000;
      },
      writable: true
    });
    const setterFields = {
      setDate: ["day"],
      setFullYear: ["year", "month", "day"],
      setHours: ["hour", "minute", "second", "millisecond"],
      setMilliseconds: ["millisecond"],
      setMinutes: ["minute", "second", "millisecond"],
      setMonth: ["month", "day"],
      setSeconds: ["second", "millisecond"]
    };
    for (const [method, fields] of Object.entries(setterFields)) {
      patch(Date.prototype, method, {
        value: function (...args) {
          const timestamp = Date.prototype.getTime.call(this);
          if (Number.isNaN(timestamp)) return NaN;
          const parts = getParts(new Date(timestamp));
          fields.forEach((field, index) => {
            if (index < args.length && args[index] !== undefined) {
              const value = Number(args[index]);
              parts[field] = field === "month" ? value + 1 : value;
            }
          });
          const updated = fromParts(parts);
          Date.prototype.setTime.call(this, updated);
          return updated;
        },
        writable: true
      });
    }
    patch(Date.prototype, "setYear", {
      value: function (year) {
        const timestamp = Date.prototype.getTime.call(this);
        if (Number.isNaN(timestamp)) return NaN;
        const parts = getParts(new Date(timestamp));
        parts.year = Number(year) >= 0 && Number(year) <= 99 ? Number(year) + 1900 : Number(year);
        const updated = fromParts(parts);
        Date.prototype.setTime.call(this, updated);
        return updated;
      },
      writable: true
    });
    const formatInTimezone = (date, locales, options) => {
      const formatterOptions = options && typeof options === "object" ? options : {};
      return new OriginalDateTimeFormat(locales, { ...formatterOptions, timeZone: formatterOptions.timeZone ?? timezone }).format(date);
    };
    patch(Date.prototype, "toLocaleString", {
      value: function (locales, options) { return formatInTimezone(this, locales, options); },
      writable: true
    });
    patch(Date.prototype, "toLocaleDateString", {
      value: function (locales, options) { return formatInTimezone(this, locales, options); },
      writable: true
    });
    patch(Date.prototype, "toLocaleTimeString", {
      value: function (locales, options) { return formatInTimezone(this, locales, options); },
      writable: true
    });
    patch(Date.prototype, "toDateString", {
      value: function () {
        const weekdays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
        const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        const parts = getParts(new Date(Date.prototype.getTime.call(this)));
        return `${weekdays[new Date(Date.UTC(parts.year, parts.month - 1, parts.day)).getUTCDay()]} ${months[parts.month - 1]} ${String(parts.day).padStart(2, "0")} ${parts.year}`;
      },
      writable: true
    });
    patch(Date.prototype, "toTimeString", {
      value: function () {
        const parts = getParts(new Date(Date.prototype.getTime.call(this)));
        const offset = -getOffset(Date.prototype.getTime.call(this)) / 60000;
        const sign = offset >= 0 ? "+" : "-";
        const pad = (value) => String(Math.abs(value)).padStart(2, "0");
        const hours = Math.floor(Math.abs(offset) / 60);
        const minutes = Math.abs(offset) % 60;
        return `${pad(parts.hour)}:${pad(parts.minute)}:${pad(parts.second)} GMT${sign}${pad(hours)}${pad(minutes)} (${timezone})`;
      },
      writable: true
    });
    patch(Date.prototype, "toString", {
      value: function () {
        return `${this.toDateString()} ${this.toTimeString()}`;
      },
      writable: true
    });
  }
  if (settings.maskBattery) {
    const fakeBattery = new EventTarget();
    Object.defineProperties(fakeBattery, {
      charging: { value: false, enumerable: true },
      chargingTime: { value: Infinity, enumerable: true },
      dischargingTime: { value: 7200, enumerable: true },
      level: { value: profile.batteryLevel, enumerable: true }
    });
    patch(Navigator.prototype, "getBattery", { value: () => Promise.resolve(fakeBattery), writable: true });
  }
  if (settings.maskHardware) {
    patch(Navigator.prototype, "hardwareConcurrency", { get: () => profile.cores });
    patch(Navigator.prototype, "deviceMemory", { get: () => profile.memory });
  }
  if (settings.maskScreen) {
    patch(window.screen, "width", { get: () => profile.screen.width });
    patch(window.screen, "height", { get: () => profile.screen.height });
    patch(window.screen, "availWidth", { get: () => profile.screen.width });
    patch(window.screen, "availHeight", { get: () => profile.screen.availableHeight });
    patch(window.screen, "colorDepth", { get: () => 24 });
    patch(window.screen, "pixelDepth", { get: () => 24 });
    patch(window, "devicePixelRatio", { get: () => profile.screen.pixelRatio });
  }

  window[key] = {
    restore() {
      for (const restore of changes.reverse()) restore();
    }
  };
  return { enabled: true, applied: changes.length, failed };
}

async function refreshFingerprintProtection(tabIds, updateHeaderRule = true) {
  const state = await chrome.storage.local.get(["protectionEnabled", "antiTrackingEnabled", "fingerprintSettings", "googlebotTabId"]);
  const settings = normalizeFingerprintSettings(state.fingerprintSettings);
  const enabled = state.protectionEnabled !== false && state.antiTrackingEnabled !== false && settings.enabled;
  if (updateHeaderRule) {
    await updateFingerprintUserAgentRule(settings, state.protectionEnabled !== false && state.antiTrackingEnabled !== false, state.googlebotTabId);
  }
  const profile = FINGERPRINT_PROFILES[settings.platform];
  const tabList = tabIds ?? (await chrome.tabs.query({})).map((tab) => tab.id).filter(Number.isInteger);
  const targets = await Promise.all(tabList.map(async (entry) => {
    if (typeof entry === "object") return entry;
    try {
      const frames = await chrome.webNavigation.getAllFrames({ tabId: entry });
      if (frames?.length) return frames.map((frame) => ({ tabId: entry, frameIds: [frame.frameId] }));
    } catch {
      // Restricted browser pages may not expose frame information.
    }
    return [{ tabId: entry, frameIds: [0] }];
  }));
  const flattenedTargets = targets.flat();
  const results = await Promise.allSettled(flattenedTargets.map((target) => {
    const tabEnabled = enabled && state.googlebotTabId !== target.tabId;
    return chrome.scripting.executeScript({
      target,
      world: "MAIN",
      injectImmediately: true,
      func: applyPageFingerprint,
      args: [settings, profile, tabEnabled]
    });
  }));
  const injections = results
    .filter((result) => result.status === "fulfilled")
    .flatMap((result) => result.value ?? [])
    .map((frameResult) => frameResult.result)
    .filter((result) => result && typeof result === "object");
  return {
    active: enabled,
    applied: injections.filter((result) => result.enabled).length,
    patchedProperties: injections.reduce((total, result) => total + result.applied, 0),
    failedProperties: [...new Set(injections.flatMap((result) => result.failed ?? []))],
    unavailable: results.filter((result) => result.status === "rejected").length
  };
}

function normalizeTrustedHostname(hostname) {
  return String(hostname ?? "").toLowerCase().replace(/\.$/, "");
}

function normalizeBlockedSite(value) {
  const input = String(value ?? "").trim();
  if (!input || (input.includes("://") && !/^https?:\/\//i.test(input))) return null;

  let parsed;
  try {
    parsed = new URL(/^https?:\/\//i.test(input) ? input : `https://${input}`);
  } catch {
    return null;
  }
  if ((parsed.protocol !== "http:" && parsed.protocol !== "https:") || parsed.username || parsed.password) return null;

  let hostname = normalizeTrustedHostname(parsed.hostname);
  if (hostname.startsWith("www.")) hostname = hostname.slice(4);
  return hostname || null;
}

function normalizeBlockedSites(values) {
  if (!Array.isArray(values)) return [];
  return [...new Set(values.map(normalizeBlockedSite).filter(Boolean))].slice(0, MAX_BLOCKED_SITES);
}

async function updateProductivityRules(enabled, blockedSites) {
  const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
  const removeRuleIds = existingRules
    .filter((rule) => rule.id >= PRODUCTIVITY_RULE_ID_BASE && rule.id < PRODUCTIVITY_RULE_ID_BASE + MAX_BLOCKED_SITES)
    .map((rule) => rule.id);
  const addRules = enabled
    ? blockedSites.slice(0, MAX_BLOCKED_SITES).map((domain, index) => ({
      id: PRODUCTIVITY_RULE_ID_BASE + index,
      priority: 1,
      action: { type: "block" },
      condition: { requestDomains: [domain], resourceTypes: ["main_frame"] }
    }))
    : [];

  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules });
}

function isTrustedRedirectHost(hostname, trustedDomains) {
  const candidate = normalizeTrustedHostname(hostname);
  return trustedDomains.some((domain) => {
    const trusted = normalizeTrustedHostname(domain);
    return candidate === trusted || candidate.endsWith(`.${trusted}`);
  });
}

function isRickrollDestination(value) {
  let target;
  try {
    target = new URL(value);
  } catch {
    return false;
  }
  const normalized = `${target.href} ${target.pathname} ${target.search}`.toLowerCase();
  return normalized.includes("dqw4w9wgxcq")
    || /rick\s*roll|rick\s*astley|never[+\s_-]+gonna[+\s_-]+give[+\s_-]+you[+\s_-]+up/i.test(normalized);
}

const NSFW_DOMAINS = Object.freeze([
  "pornhub.com", "xvideos.com", "xnxx.com", "xhamster.com", "redtube.com", "youporn.com",
  "spankbang.com", "brazzers.com", "onlyfans.com", "fansly.com", "chaturbate.com",
  "stripchat.com", "livejasmin.com", "myfreecams.com", "cam4.com", "nhentai.net",
  "rule34.xxx", "e621.net"
]);
const NSFW_URL_PATTERN = /(?:^|\s)(?:nsfw|adult|porn|porno|xxx|hentai|erotic|nudes?|naked|lewd|sex|camgirl|camsex|rule\s*34)(?=$|\s)/i;

function isNsfwDestination(value) {
  let target;
  try {
    target = new URL(value);
  } catch {
    return false;
  }
  if (target.protocol !== "http:" && target.protocol !== "https:") return false;
  const hostname = target.hostname.toLowerCase().replace(/\.$/, "");
  if (NSFW_DOMAINS.some((domain) => hostname === domain || hostname.endsWith(`.${domain}`))) return true;
  let decodedUrl = target.href;
  try {
    decodedUrl = decodeURIComponent(decodedUrl.replace(/\+/g, " "));
  } catch {
    // Keep the raw URL if a component has invalid percent encoding.
  }
  return NSFW_URL_PATTERN.test(decodedUrl.replace(/[./_+=?&#%-]+/g, " "));
}

function currentDateKey() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

async function applyRules(enabled) {
  await chrome.declarativeNetRequest.updateEnabledRulesets({
    enableRulesetIds: enabled ? [RULESET_ID] : [],
    disableRulesetIds: enabled ? [] : [RULESET_ID]
  });
}

async function applyAntiTrackingRules(enabled) {
  await chrome.declarativeNetRequest.updateEnabledRulesets({
    enableRulesetIds: enabled ? [ANTI_TRACKING_RULESET_ID] : [],
    disableRulesetIds: enabled ? [] : [ANTI_TRACKING_RULESET_ID]
  });
}

async function applyNotificationBlocking(enabled) {
  if (enabled) {
    await chrome.contentSettings.notifications.set({
      primaryPattern: "<all_urls>",
      setting: "block",
      scope: "regular"
    });
    return;
  }
  await chrome.contentSettings.notifications.clear({ scope: "regular" });
}

async function applyProtectionState(state) {
  const enabled = state.protectionEnabled === true;
  await applyRules(enabled);
  await applyAntiTrackingRules(enabled && state.antiTrackingEnabled !== false);
  await updateFingerprintUserAgentRule(
    normalizeFingerprintSettings(state.fingerprintSettings),
    enabled && state.antiTrackingEnabled !== false,
    state.googlebotTabId
  );
  await applyNotificationBlocking(enabled);
  await updateProductivityRules(enabled && state.productivityModeEnabled === true, state.blockedSites);
  if (!enabled) {
    await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [GOOGLEBOT_RULE_ID] });
    if (state.googlebotTabId !== null && state.googlebotTabId !== undefined) {
      await chrome.storage.local.set({ googlebotTabId: null });
    }
  }
}

function registerDiscordContextMenu() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "discord-protect-avatar-url",
      title: "Discord Protect : changer l’avatar local…",
      contexts: ["all"],
      documentUrlPatterns: ["https://discord.com/*"]
    });
    chrome.contextMenus.create({
      id: "discord-protect-avatar-decoration",
      title: "Discord Protect : décorer cet avatar…",
      contexts: ["all"],
      documentUrlPatterns: ["https://discord.com/*"]
    });
    chrome.contextMenus.create({
      id: "discord-protect-avatar-reset",
      title: "Discord Protect : retirer la personnalisation locale",
      contexts: ["all"],
      documentUrlPatterns: ["https://discord.com/*"]
    });
  });
}

async function initialize(resetSessionFeatures = false) {
  if (resetSessionFeatures) {
    await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [GOOGLEBOT_RULE_ID] });
    await chrome.storage.local.set({ googlebotTabId: null });
  }
  const state = await chrome.storage.local.get([
    "protectionEnabled",
    "developerModeEnabled",
    "cookiePopupEnabled",
    "cookieRejectEnabled",
    "antiTrackingEnabled",
    "discordToolsEnabled",
    "antiRickrollEnabled",
    "noNsfwEnabled",
    "productivityModeEnabled",
    "blockedSites",
    "googlebotTabId",
    "fingerprintSettings",
    "youtubeShortsBlocked",
    "blockedToday",
    "statsDate"
  ]);
  const statsDate = currentDateKey();
  const nextState = {
    protectionEnabled: state.protectionEnabled ?? DEFAULT_ENABLED,
    developerModeEnabled: state.developerModeEnabled ?? DEFAULT_DEVELOPER_MODE_ENABLED,
    cookiePopupEnabled: state.cookiePopupEnabled ?? state.cookieRejectEnabled ?? DEFAULT_COOKIE_POPUP_ENABLED,
    antiTrackingEnabled: state.antiTrackingEnabled ?? DEFAULT_ANTI_TRACKING_ENABLED,
    discordToolsEnabled: state.discordToolsEnabled ?? DEFAULT_DISCORD_TOOLS_ENABLED,
    antiRickrollEnabled: state.antiRickrollEnabled ?? DEFAULT_ANTI_RICKROLL_ENABLED,
    noNsfwEnabled: state.noNsfwEnabled ?? DEFAULT_NO_NSFW_ENABLED,
    fingerprintSettings: normalizeFingerprintSettings(state.fingerprintSettings),
    productivityModeEnabled: state.productivityModeEnabled ?? DEFAULT_PRODUCTIVITY_MODE_ENABLED,
    blockedSites: normalizeBlockedSites(state.blockedSites),
    youtubeShortsBlocked: state.youtubeShortsBlocked ?? false,
    blockedToday: state.statsDate === statsDate ? (state.blockedToday ?? 0) : 0,
    statsDate
  };
  await chrome.storage.local.set(nextState);
  if (state.cookieRejectEnabled !== undefined) await chrome.storage.local.remove("cookieRejectEnabled");
  await applyProtectionState({ ...nextState, googlebotTabId: state.googlebotTabId });
  await refreshFingerprintProtection();
}

chrome.runtime.onInstalled.addListener(() => {
  void initialize(true);
  registerDiscordContextMenu();
});
chrome.runtime.onStartup.addListener(() => void initialize(true));
void initialize();

chrome.contextMenus.onClicked.addListener((info, tab) => {
  const actions = {
    "discord-protect-avatar-url": "open-avatar-url-tool",
    "discord-protect-avatar-decoration": "open-avatar-decoration-tool",
    "discord-protect-avatar-reset": "reset-avatar-customization"
  };
  const type = actions[info.menuItemId];
  if (!type || !tab?.id) return;
  chrome.tabs.sendMessage(tab.id, { type }).catch(() => undefined);
});

chrome.webNavigation.onBeforeNavigate.addListener(async (details) => {
  if (details.frameId !== 0 || !/^https?:\/\//i.test(details.url)) return;
  const protectionState = await chrome.storage.local.get("protectionEnabled");
  if (protectionState.protectionEnabled === false) return;

  const key = pendingNavigationKey(details.tabId);
  const stored = await chrome.storage.session.get(key);
  const previous = stored[key];
  const tabMovixTarget = await chrome.storage.session.get(movixTargetKey(details.tabId));
  let movixSourceUrl = tabMovixTarget[movixTargetKey(details.tabId)]?.sourceUrl ?? previous?.movixSourceUrl ?? "";
  if (!movixSourceUrl && !new URL(details.url).hostname.toLowerCase().includes("movix")) {
    try {
      const tab = await chrome.tabs.get(details.tabId);
      const currentUrl = new URL(tab.url);
      if (currentUrl.hostname.toLowerCase().includes("movix")) movixSourceUrl = currentUrl.href;
    } catch {
      // The tab may have closed before its navigation event was handled.
    }
  }
  const isContinuation = previous
    && previous.url !== details.url
    && details.timeStamp - previous.timeStamp < 15000;
  let sourceHostname = previous?.sourceHostname;
  if (previous?.url && previous.url !== details.url) {
    try {
      sourceHostname = new URL(previous.url).hostname;
    } catch {
      sourceHostname = undefined;
    }
  } else if (!sourceHostname) {
    try {
      const currentTab = await chrome.tabs.get(details.tabId);
      const currentUrl = new URL(currentTab.url);
      if ((currentUrl.protocol === "http:" || currentUrl.protocol === "https:")
        && currentUrl.href !== details.url) {
        sourceHostname = currentUrl.hostname;
      }
    } catch {
      // The tab may close before its previous address can be read.
    }
  }

  await chrome.storage.session.set({
    [key]: {
      url: details.url,
      timeStamp: details.timeStamp,
      redirectChain: Boolean(previous?.redirectChain || isContinuation),
      sourceHostname,
      movixSourceUrl
    }
  });
});

chrome.webNavigation.onCommitted.addListener(async (details) => {
  if (!/^https?:\/\//i.test(details.url)) return;
  if (details.frameId !== 0) {
    try {
      const result = await refreshFingerprintProtection([{ tabId: details.tabId, frameIds: [details.frameId] }], false);
      if (result.unavailable > 0) console.warn(`Privacy profile could not be applied in frame ${details.frameId}.`);
    } catch (error) {
      console.error("Could not apply the privacy profile to a committed frame.", error);
    }
    return;
  }

  const approvedKey = approvedNavigationKey(details.tabId);
  const clickKey = recentClickKey(details.tabId);
  const pendingKey = pendingNavigationKey(details.tabId);
  const extensionNavigationStorageKey = extensionNavigationKey(details.tabId);
  const protectionState = await chrome.storage.local.get(["protectionEnabled", "antiRickrollEnabled", "noNsfwEnabled"]);
  if (protectionState.protectionEnabled === false) {
    await chrome.storage.session.remove([approvedKey, clickKey, pendingKey, extensionNavigationStorageKey, movixTargetKey(details.tabId)]);
    return;
  }
  try {
    const fingerprintResult = await refreshFingerprintProtection([details.tabId], false);
    if (fingerprintResult.unavailable > 0) {
      console.warn(`Privacy profile could not be applied in tab ${details.tabId}.`);
    }
  } catch (error) {
    console.error("Could not apply the privacy profile to the committed tab.", error);
  }
  const stored = await chrome.storage.session.get([approvedKey, clickKey, pendingKey, extensionNavigationStorageKey]);
  const approvedUrl = stored[approvedKey];
  const pendingNavigation = stored[pendingKey];
  const isNsfwNavigation = protectionState.noNsfwEnabled === true && isNsfwDestination(details.url);
  const movixTargetStorageKey = movixTargetKey(details.tabId);
  const movixTargetState = await chrome.storage.session.get(movixTargetStorageKey);
  const movixTarget = movixTargetState[movixTargetStorageKey];
  if (!new URL(details.url).hostname.toLowerCase().includes("movix")) {
    if (movixTarget?.sourceUrl || pendingNavigation?.movixSourceUrl) {
      await chrome.storage.session.remove([clickKey, pendingKey, movixTargetStorageKey]);
      if (movixTarget?.closeOnRedirect) {
        await chrome.tabs.remove(details.tabId);
      } else {
        const returnUrl = movixTarget?.sourceUrl ?? pendingNavigation.movixSourceUrl;
        await chrome.tabs.update(details.tabId, { url: returnUrl });
      }
      return;
    }
  }
  if (approvedUrl === details.url && !isNsfwNavigation) {
    await chrome.storage.session.remove([approvedKey, clickKey, pendingKey, extensionNavigationStorageKey]);
    return;
  }

  const recentClickAt = stored[clickKey] ?? 0;
  const hasRecentClick = Date.now() - recentClickAt <= RECENT_CLICK_WINDOW_MS;
  const hasRedirectQualifier = details.transitionQualifiers.includes("client_redirect")
    || details.transitionQualifiers.includes("server_redirect");
  const wasRedirected = hasRedirectQualifier || Boolean(pendingNavigation?.redirectChain);
  const isInsecureHttp = details.url.startsWith("http://");
  const trustedState = isInsecureHttp
    ? { trustedRedirectDomains: [] }
    : await chrome.storage.local.get("trustedRedirectDomains");
  const trustedRedirectDomains = Array.isArray(trustedState.trustedRedirectDomains)
    ? trustedState.trustedRedirectDomains
    : [];
  const destinationIsTrusted = !isInsecureHttp
    && isTrustedRedirectHost(new URL(details.url).hostname, trustedRedirectDomains);
  const isRickrollNavigation = protectionState.antiRickrollEnabled === true
    && isRickrollDestination(details.url);
  let redirectTouchesYoutube = false;
  try {
    const destinationHostname = new URL(details.url).hostname.toLowerCase();
    const sourceHostname = normalizeTrustedHostname(pendingNavigation?.sourceHostname);
    redirectTouchesYoutube = destinationHostname === "youtube.com"
      || destinationHostname.endsWith(".youtube.com")
      || sourceHostname === "youtube.com"
      || sourceHostname.endsWith(".youtube.com");
  } catch {
    redirectTouchesYoutube = false;
  }
  const extensionNavigation = stored[extensionNavigationStorageKey];
  const wasExtensionNavigation = extensionNavigation
    && Date.now() - extensionNavigation.createdAt <= 15000;
  const needsWarning = isRickrollNavigation
    || isNsfwNavigation
    || (wasRedirected && !hasRecentClick && !redirectTouchesYoutube)
    || (isInsecureHttp && (!hasRecentClick || hasRedirectQualifier || Boolean(pendingNavigation?.redirectChain)));
  await chrome.storage.session.remove([clickKey, pendingKey, extensionNavigationStorageKey]);
  if (wasExtensionNavigation && !isRickrollNavigation && !isNsfwNavigation) return;
  if (!needsWarning || (wasRedirected && destinationIsTrusted && !isInsecureHttp && !isRickrollNavigation && !isNsfwNavigation)) return;

  const warningPage = isInsecureHttp ? "http-warning.html" : "redirect-warning.html";
  const warningUrl = new URL(chrome.runtime.getURL(warningPage));
  warningUrl.searchParams.set("target", details.url);
  if (isNsfwNavigation) warningUrl.searchParams.set("reason", "nsfw");
  else if (isRickrollNavigation) warningUrl.searchParams.set("reason", "rickroll");
  const logType = isNsfwNavigation
    ? "redirect-nsfw-warning"
    : isRickrollNavigation
      ? "redirect-rickroll-warning"
      : isInsecureHttp
        ? "redirect-http-warning"
        : "redirect-suspicious-warning";
  void chrome.tabs.update(details.tabId, { url: warningUrl.href }).then(() => {
    void queueProtectionLogs([makeRedirectLog(logType, details.url, pendingNavigation?.sourceHostname)]);
  }).catch((error) => console.error("Could not open the redirect warning page.", error));
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.url && !/^https?:\/\//i.test(changeInfo.url)) {
    chrome.storage.session.get("lastWebTabId").then((state) => {
      if (state.lastWebTabId === tabId) return chrome.storage.session.remove("lastWebTabId");
      return undefined;
    }).catch((error) => console.warn("Could not update the last active web tab.", error));
  }
  if (changeInfo.status !== "complete" || !/^https?:\/\//i.test(tab.url ?? "")) return;
  refreshFingerprintProtection([tabId])
    .then((result) => {
      if (result.unavailable > 0 || result.failedProperties.length > 0) {
        console.warn("Privacy profile was only partially applied after tab load.", {
          tabId,
          unavailableFrames: result.unavailable,
          failedProperties: result.failedProperties
        });
      }
    })
    .catch((error) => console.error("Could not apply the privacy profile after tab load.", error));
});

chrome.tabs.onActivated.addListener(({ tabId }) => {
  chrome.tabs.get(tabId).then((tab) => {
    if (/^https?:\/\//i.test(tab.url ?? "")) {
      return chrome.storage.session.set({ lastWebTabId: tabId });
    }
    return undefined;
  }).catch((error) => console.warn("Could not remember the active web tab.", error));
});

chrome.webNavigation.onCreatedNavigationTarget.addListener(async (details) => {
  const protectionState = await chrome.storage.local.get("protectionEnabled");
  if (protectionState.protectionEnabled === false) return;
  try {
    const sourceTab = await chrome.tabs.get(details.sourceTabId);
    const sourceUrl = new URL(sourceTab.url);
    if (sourceUrl.hostname.toLowerCase().includes("movix")) {
      await chrome.storage.session.set({
        [movixTargetKey(details.tabId)]: {
          sourceUrl: sourceUrl.href,
          closeOnRedirect: true
        }
      });
    }
  } catch {
    // The source tab may have closed before the new target was inspected.
  }
  const sourceKey = recentClickKey(details.sourceTabId);
  const source = await chrome.storage.session.get(sourceKey);
  const clickedAt = source[sourceKey] ?? 0;
  if (Date.now() - clickedAt <= RECENT_CLICK_WINDOW_MS) {
    await chrome.storage.session.set({ [recentClickKey(details.tabId)]: clickedAt });
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  void chrome.storage.session.remove([recentClickKey(tabId), approvedNavigationKey(tabId), pendingNavigationKey(tabId), extensionNavigationKey(tabId), movixTargetKey(tabId), rickrollApprovalKey(tabId)]);
  chrome.storage.local.get("googlebotTabId").then((state) => {
    if (state.googlebotTabId !== tabId) return;
    chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [GOOGLEBOT_RULE_ID] })
      .then(() => chrome.storage.local.set({ googlebotTabId: null }))
      .catch(() => undefined);
  });
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "developer-element-inspected"
    || message?.type === "developer-element-inspection-cancelled") {
    const tabId = _sender.tab?.id;
    if (_sender.id !== chrome.runtime.id || !Number.isInteger(tabId)) {
      sendResponse({ ok: false });
      return;
    }
    const details = message.details;
    if (message.type === "developer-element-inspected"
      && (!details || typeof details !== "object"
        || typeof details.selector !== "string"
        || details.selector.length > 2000
        || typeof details.tagName !== "string"
        || details.tagName.length > 64
        || (details.image && (typeof details.image.url !== "string" || details.image.url.length > 10000)))) {
      sendResponse({ ok: false });
      return;
    }
    chrome.storage.local.get("developerModeEnabled").then((state) => {
      if (state.developerModeEnabled !== true) {
        sendResponse({ ok: false });
        return;
      }
      const key = `developer-element-inspection:${tabId}`;
      const result = message.type === "developer-element-inspected"
        ? {
          details: {
            tagName: details.tagName,
            selector: details.selector,
            text: typeof details.text === "string" ? details.text.slice(0, 300) : "",
            html: typeof details.html === "string" ? details.html.slice(0, 1200) : "",
            dimensions: details.dimensions,
            ...(details.image ? {
              image: {
                url: details.image.url,
                width: Number.isFinite(details.image.width) ? details.image.width : 0,
                height: Number.isFinite(details.image.height) ? details.image.height : 0
              }
            } : {})
          },
          completedAt: Date.now()
        }
        : { cancelled: true, completedAt: Date.now() };
      return chrome.storage.session.set({ [key]: result }).then(() => sendResponse({ ok: true }));
    }).catch((error) => {
      console.error("Could not save developer element inspection.", error);
      sendResponse({ ok: false });
    });
    return true;
  }

  if (message?.type === "decrypt-password-vault-entry") {
    let senderOrigin;
    try {
      senderOrigin = new URL(_sender.url).origin;
    } catch {
      sendResponse({ ok: false, error: "Cette page ne peut pas accéder au coffre." });
      return;
    }
    if (_sender.id !== chrome.runtime.id
      || !/^https?:$/.test(new URL(_sender.url).protocol)
      || typeof message.masterPassword !== "string"
      || !message.masterPassword
      || typeof message.entryId !== "string") {
      sendResponse({ ok: false, error: "Demande de déchiffrement invalide." });
      return;
    }

    chrome.storage.local.get("passwordVault").then(async (stored) => {
      const vault = stored.passwordVault;
      const entry = vault?.entries?.find((candidate) => candidate.id === message.entryId);
      if (!entry || entry.origin !== senderOrigin) {
        throw new Error("Cet identifiant n’existe pas pour ce site.");
      }
      const key = await PasswordVaultCrypto.unlockVault(message.masterPassword, vault);
      const credential = JSON.parse(await PasswordVaultCrypto.decryptText(key, entry));
      if (typeof credential.password !== "string") {
        throw new Error("L’identifiant enregistré est invalide.");
      }
      sendResponse({ ok: true, credential });
    }).catch((error) => {
      if (error.message !== "Mot de passe maître incorrect."
        && error.message !== "Cet identifiant n’existe pas pour ce site."
        && error.message !== "L’identifiant enregistré est invalide.") {
        console.error("Could not decrypt a password vault entry.", error);
      }
      sendResponse({ ok: false, error: error.message || "Impossible de déchiffrer cet identifiant." });
    });
    return true;
  }

  if (message?.type === "get-protection-logs") {
    chrome.storage.local.get("protectionLogs").then((state) => {
      sendResponse({
        ok: true,
        logs: Array.isArray(state.protectionLogs) ? state.protectionLogs : []
      });
    }).catch((error) => {
      console.error("Could not load protection logs.", error);
      sendResponse({ ok: false });
    });
    return true;
  }

  if (message?.type === "clear-protection-logs") {
    const clearOperation = writes.then(() => chrome.storage.local.set({ protectionLogs: [] }));
    writes = clearOperation.catch(() => undefined);
    clearOperation.then(
      () => sendResponse({ ok: true }),
      (error) => {
        console.error("Could not clear protection logs.", error);
        sendResponse({ ok: false });
      }
    );
    return true;
  }

  if (message?.type === "nsfw-warning-navigation") {
    const sourceTabId = _sender.tab?.id;
    const sourceUrl = _sender.tab?.url;
    let target;
    try {
      target = new URL(message.target);
    } catch {
      sendResponse({ ok: false });
      return;
    }
    if (!Number.isInteger(sourceTabId)
      || (target.protocol !== "http:" && target.protocol !== "https:")
      || !isNsfwDestination(target.href)) {
      sendResponse({ ok: false });
      return;
    }
    chrome.storage.local.get(["protectionEnabled", "noNsfwEnabled"]).then((state) => {
      if (state.protectionEnabled === false || state.noNsfwEnabled !== true) {
        sendResponse({ ok: false });
        return;
      }
      const warningUrl = new URL(chrome.runtime.getURL("redirect-warning.html"));
      warningUrl.searchParams.set("target", target.href);
      warningUrl.searchParams.set("reason", "nsfw");
      const opening = message.newTab
        ? chrome.tabs.create({ url: warningUrl.href, active: true })
        : chrome.tabs.update(sourceTabId, { url: warningUrl.href });
      opening.then(() => {
        void queueProtectionLogs([makeRedirectLog("redirect-nsfw-warning", target.href, sourceUrl)]);
        sendResponse({ ok: true });
      }).catch((error) => {
        console.error("Could not open the no-NSFW warning page.", error);
        sendResponse({ ok: false });
      });
    }).catch((error) => {
      console.error("Could not read the no-NSFW setting.", error);
      sendResponse({ ok: false });
    });
    return true;
  }
  if (message?.type === "extension-navigation-intent") {
    const tabId = _sender.tab?.id;
    let target;
    try {
      target = new URL(message.url);
    } catch {
      sendResponse({ ok: false });
      return;
    }
    let sourceOrigin;
    try {
      sourceOrigin = new URL(_sender.tab?.url).origin;
    } catch {
      sendResponse({ ok: false });
      return;
    }
    if (!Number.isInteger(tabId)
      || !/^https?:$/.test(target.protocol)
      || target.origin !== sourceOrigin) {
      sendResponse({ ok: false });
      return;
    }
    chrome.storage.session.set({
      [extensionNavigationKey(tabId)]: {
        url: target.href,
        createdAt: Date.now()
      }
    }).then(() => sendResponse({ ok: true })).catch((error) => {
      console.error("Could not register extension-triggered navigation.", error);
      sendResponse({ ok: false });
    });
    return true;
  }

  if (message?.type === "navigation-intent") {
    const tabId = _sender.tab?.id;
    if (Number.isInteger(tabId)) {
      chrome.storage.session.set({ [recentClickKey(tabId)]: Date.now() })
        .then(() => sendResponse({ ok: true }))
        .catch(() => sendResponse({ ok: false }));
      return true;
    }
    sendResponse({ ok: false });
    return;
  }

  if (message?.type === "confirmed-http-navigation") {
    const sourceTabId = _sender.tab?.id;
    const target = message.url;
    let parsedTarget;
    try {
      parsedTarget = new URL(target);
    } catch {
      sendResponse({ ok: false });
      return;
    }
    if (!Number.isInteger(sourceTabId) || parsedTarget.protocol !== "http:") {
      sendResponse({ ok: false });
      return;
    }

    if (message.newTab) {
      chrome.tabs.create({ url: "about:blank", active: true }).then((tab) => {
        const tabId = tab.id;
        return chrome.storage.session.set({
          [approvedNavigationKey(tabId)]: parsedTarget.href,
          [recentClickKey(tabId)]: Date.now()
        }).then(() => chrome.tabs.update(tabId, { url: parsedTarget.href }));
      }).then(() => sendResponse({ ok: true })).catch(() => sendResponse({ ok: false }));
    } else {
      chrome.storage.session.set({
        [approvedNavigationKey(sourceTabId)]: parsedTarget.href,
        [recentClickKey(sourceTabId)]: Date.now()
      }).then(() => chrome.tabs.update(sourceTabId, { url: parsedTarget.href }))
        .then(() => sendResponse({ ok: true }))
        .catch(() => sendResponse({ ok: false }));
    }
    return true;
  }

  if (message?.type === "rickroll-warning-navigation") {
    const sourceTabId = _sender.tab?.id;
    const sourceUrl = _sender.tab?.url;
    let target;
    try {
      target = new URL(message.target);
    } catch {
      sendResponse({ ok: false });
      return;
    }
    if (!Number.isInteger(sourceTabId) || (target.protocol !== "http:" && target.protocol !== "https:")) {
      sendResponse({ ok: false });
      return;
    }

    chrome.storage.local.get(["protectionEnabled", "antiRickrollEnabled"]).then((state) => {
      if (state.protectionEnabled === false || state.antiRickrollEnabled !== true) {
        sendResponse({ ok: false });
        return;
      }
      const warningUrl = new URL(chrome.runtime.getURL("redirect-warning.html"));
      warningUrl.searchParams.set("target", target.href);
      warningUrl.searchParams.set("reason", "rickroll");
      const opening = message.newTab
        ? chrome.tabs.create({ url: warningUrl.href, active: true })
        : chrome.tabs.update(sourceTabId, { url: warningUrl.href });
      opening.then(() => {
        void queueProtectionLogs([makeRedirectLog("redirect-rickroll-warning", target.href, sourceUrl)]);
        sendResponse({ ok: true });
      }).catch((error) => {
        console.error("Could not open the Rick Roll warning page.", error);
        sendResponse({ ok: false });
      });
    }).catch((error) => {
      console.error("Could not read the anti-Rickroll setting.", error);
      sendResponse({ ok: false });
    });
    return true;
  }

  if (message?.type === "consume-rickroll-approval") {
    const tabId = _sender.tab?.id;
    let target;
    try {
      target = new URL(message.url);
    } catch {
      sendResponse({ approved: false });
      return;
    }
    if (!Number.isInteger(tabId) || (target.protocol !== "http:" && target.protocol !== "https:")) {
      sendResponse({ approved: false });
      return;
    }

    const key = rickrollApprovalKey(tabId);
    chrome.storage.session.get(key).then((state) => {
      const approved = state[key] === target.href;
      return chrome.storage.session.remove(key).then(() => sendResponse({ approved }));
    }).catch(() => sendResponse({ approved: false }));
    return true;
  }

  if (message?.type === "get-state") {
    chrome.storage.local.get(["protectionEnabled", "developerModeEnabled", "cookiePopupEnabled", "cookieRejectEnabled", "antiTrackingEnabled", "discordToolsEnabled", "antiRickrollEnabled", "noNsfwEnabled", "productivityModeEnabled", "blockedSites", "youtubeShortsBlocked", "googlebotTabId", "fingerprintSettings", "blockedToday", "statsDate"]).then(async (state) => {
      const today = currentDateKey();
      if (state.statsDate !== today) {
        await chrome.storage.local.set({ blockedToday: 0, statsDate: today });
        state.blockedToday = 0;
      }
      sendResponse({
        protectionEnabled: state.protectionEnabled ?? DEFAULT_ENABLED,
        developerModeEnabled: state.developerModeEnabled ?? DEFAULT_DEVELOPER_MODE_ENABLED,
        cookiePopupEnabled: state.cookiePopupEnabled ?? state.cookieRejectEnabled ?? DEFAULT_COOKIE_POPUP_ENABLED,
        antiTrackingEnabled: state.antiTrackingEnabled ?? DEFAULT_ANTI_TRACKING_ENABLED,
        fingerprintSettings: normalizeFingerprintSettings(state.fingerprintSettings),
        discordToolsEnabled: state.discordToolsEnabled ?? DEFAULT_DISCORD_TOOLS_ENABLED,
        antiRickrollEnabled: state.antiRickrollEnabled ?? DEFAULT_ANTI_RICKROLL_ENABLED,
        noNsfwEnabled: state.noNsfwEnabled ?? DEFAULT_NO_NSFW_ENABLED,
        productivityModeEnabled: state.productivityModeEnabled ?? DEFAULT_PRODUCTIVITY_MODE_ENABLED,
        blockedSites: normalizeBlockedSites(state.blockedSites),
        youtubeShortsBlocked: state.youtubeShortsBlocked === true,
        googlebotMode: state.protectionEnabled !== false && Number.isInteger(message.tabId) && state.googlebotTabId === message.tabId,
        blockedToday: state.blockedToday ?? 0
      });
    });
    return true;
  }

  if (message?.type === "set-protection-state") {
    const enabled = Boolean(message.enabled);
    chrome.storage.local.get(["antiTrackingEnabled", "productivityModeEnabled", "blockedSites", "googlebotTabId", "fingerprintSettings"])
      .then((state) => {
        const nextState = { ...state, protectionEnabled: enabled, blockedSites: normalizeBlockedSites(state.blockedSites) };
        return chrome.storage.local.set({ protectionEnabled: enabled }).then(() => applyProtectionState(nextState));
      })
      .then(() => refreshFingerprintProtection())
      .then(() => sendResponse({ ok: true, protectionEnabled: enabled }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "set-cookie-popup-state") {
    const enabled = Boolean(message.enabled);
    chrome.storage.local.set({ cookiePopupEnabled: enabled })
      .then(() => sendResponse({ ok: true, cookiePopupEnabled: enabled }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "set-anti-tracking-state") {
    const enabled = Boolean(message.enabled);
    chrome.storage.local.set({ antiTrackingEnabled: enabled })
      .then(() => chrome.storage.local.get("protectionEnabled"))
      .then((state) => applyAntiTrackingRules(state.protectionEnabled !== false && enabled))
      .then(() => refreshFingerprintProtection())
      .then(() => sendResponse({ ok: true, antiTrackingEnabled: enabled }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "set-fingerprint-settings") {
    const settings = normalizeFingerprintSettings(message.settings);
    chrome.storage.local.set({ fingerprintSettings: settings })
      .then(() => {
        sendResponse({
          ok: true,
          applying: true,
          requestId: message.requestId,
          fingerprintSettings: settings
        });
        refreshFingerprintProtection()
          .then((result) => chrome.runtime.sendMessage({
            type: "fingerprint-application-complete",
            requestId: message.requestId,
            ...result
          }))
          .catch((error) => {
            console.error("Could not apply the saved privacy profile to open tabs.", error);
            return chrome.runtime.sendMessage({
              type: "fingerprint-application-complete",
              requestId: message.requestId,
              ok: false
            }).catch((notificationError) => {
              console.error("Could not report the privacy profile application failure.", notificationError);
            });
          });
      })
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "set-discord-tools-state") {
    const enabled = Boolean(message.enabled);
    chrome.storage.local.set({ discordToolsEnabled: enabled })
      .then(() => sendResponse({ ok: true, discordToolsEnabled: enabled }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "set-anti-rickroll-state") {
    const enabled = Boolean(message.enabled);
    chrome.storage.local.set({ antiRickrollEnabled: enabled })
      .then(() => sendResponse({ ok: true, antiRickrollEnabled: enabled }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "set-no-nsfw-state") {
    const enabled = Boolean(message.enabled);
    chrome.storage.local.set({ noNsfwEnabled: enabled })
      .then(() => sendResponse({ ok: true, noNsfwEnabled: enabled }))
      .catch((error) => {
        console.error("Could not update the no-NSFW setting.", error);
        sendResponse({ ok: false });
      });
    return true;
  }

  if (message?.type === "set-productivity-mode") {
    const enabled = Boolean(message.enabled);
    chrome.storage.local.get(["blockedSites", "protectionEnabled"]).then(async (state) => {
      const blockedSites = normalizeBlockedSites(state.blockedSites);
      await updateProductivityRules(state.protectionEnabled !== false && enabled, blockedSites);
      await chrome.storage.local.set({ productivityModeEnabled: enabled, blockedSites });
      sendResponse({ ok: true, productivityModeEnabled: enabled, blockedSites });
    }).catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "add-blocked-site") {
    const domain = normalizeBlockedSite(message.domain);
    if (!domain) {
      sendResponse({ ok: false, reason: "invalid-domain" });
      return;
    }
    chrome.storage.local.get(["blockedSites", "productivityModeEnabled", "protectionEnabled"]).then(async (state) => {
      const blockedSites = normalizeBlockedSites(state.blockedSites);
      if (blockedSites.includes(domain)) {
        sendResponse({ ok: true, blockedSites, duplicate: true });
        return;
      }
      if (blockedSites.length >= MAX_BLOCKED_SITES) {
        sendResponse({ ok: false, reason: "limit-reached" });
        return;
      }
      const nextBlockedSites = [...blockedSites, domain];
      await updateProductivityRules(state.protectionEnabled !== false && state.productivityModeEnabled === true, nextBlockedSites);
      await chrome.storage.local.set({ blockedSites: nextBlockedSites });
      sendResponse({ ok: true, blockedSites: nextBlockedSites });
    }).catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "remove-blocked-site") {
    const domain = normalizeBlockedSite(message.domain);
    if (!domain) {
      sendResponse({ ok: false, reason: "invalid-domain" });
      return;
    }
    chrome.storage.local.get(["blockedSites", "productivityModeEnabled", "protectionEnabled"]).then(async (state) => {
      const blockedSites = normalizeBlockedSites(state.blockedSites).filter((site) => site !== domain);
      await updateProductivityRules(state.protectionEnabled !== false && state.productivityModeEnabled === true, blockedSites);
      await chrome.storage.local.set({ blockedSites });
      sendResponse({ ok: true, blockedSites });
    }).catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "set-youtube-shorts-blocked") {
    const enabled = Boolean(message.enabled);
    chrome.storage.local.set({ youtubeShortsBlocked: enabled })
      .then(() => sendResponse({ ok: true, youtubeShortsBlocked: enabled }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "set-googlebot-mode") {
    const tabId = message.tabId;
    const enabled = Boolean(message.enabled);
    if (!Number.isInteger(tabId) || tabId < 0) {
      sendResponse({ ok: false });
      return;
    }
    if (enabled) {
      chrome.storage.local.get("protectionEnabled").then((state) => {
        if (state.protectionEnabled === false) {
          sendResponse({ ok: false, reason: "Protection is disabled" });
          return;
        }
        applyGooglebotMode(tabId, true, sendResponse);
      }).catch(() => sendResponse({ ok: false }));
      return true;
    }

    applyGooglebotMode(tabId, false, sendResponse);
    return true;
  }

  if (message?.type === "confirm-redirect") {
    const target = message.target;
    const tabId = message.tabId;
    let parsedTarget;
    try {
      parsedTarget = new URL(target);
    } catch {
      sendResponse({ ok: false });
      return;
    }
    if (!Number.isInteger(tabId) || (parsedTarget.protocol !== "http:" && parsedTarget.protocol !== "https:")) {
      sendResponse({ ok: false });
      return;
    }

    const rememberDomain = Boolean(message.trustDomain) && parsedTarget.protocol === "https:";
    const saveApproval = rememberDomain
      ? chrome.storage.local.get("trustedRedirectDomains").then((state) => {
        const existingDomains = Array.isArray(state.trustedRedirectDomains) ? state.trustedRedirectDomains : [];
        const hostname = normalizeTrustedHostname(parsedTarget.hostname);
        const trustedRedirectDomains = [...new Set([...existingDomains.map(normalizeTrustedHostname), hostname])];
        return chrome.storage.local.set({ trustedRedirectDomains });
      })
      : Promise.resolve();

    const navigationApprovals = {
      [approvedNavigationKey(tabId)]: parsedTarget.href,
      [recentClickKey(tabId)]: Date.now()
    };
    if (message.skipRickrollOnce === true) navigationApprovals[rickrollApprovalKey(tabId)] = parsedTarget.href;
    saveApproval.then(() => chrome.storage.session.set(navigationApprovals))
      .then(() => chrome.tabs.update(tabId, { url: parsedTarget.href }))
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "go-back") {
    if (!Number.isInteger(message.tabId)) {
      sendResponse({ ok: false });
      return;
    }
    chrome.tabs.goBack(message.tabId)
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "factory-reset") {
    const resetOperation = writes.then(async () => {
      await chrome.storage.local.clear();
      await applyProtectionState({
        protectionEnabled: DEFAULT_ENABLED,
        developerModeEnabled: DEFAULT_DEVELOPER_MODE_ENABLED,
        antiTrackingEnabled: DEFAULT_ANTI_TRACKING_ENABLED,
        fingerprintSettings: { ...DEFAULT_FINGERPRINT_SETTINGS },
        productivityModeEnabled: DEFAULT_PRODUCTIVITY_MODE_ENABLED,
        blockedSites: [],
        googlebotTabId: null
      });
      await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [GOOGLEBOT_RULE_ID, FINGERPRINT_RULE_ID] });
      await chrome.storage.local.set({
        protectionEnabled: DEFAULT_ENABLED,
        developerModeEnabled: DEFAULT_DEVELOPER_MODE_ENABLED,
        cookiePopupEnabled: DEFAULT_COOKIE_POPUP_ENABLED,
        antiTrackingEnabled: DEFAULT_ANTI_TRACKING_ENABLED,
        discordToolsEnabled: DEFAULT_DISCORD_TOOLS_ENABLED,
        antiRickrollEnabled: DEFAULT_ANTI_RICKROLL_ENABLED,
        noNsfwEnabled: DEFAULT_NO_NSFW_ENABLED,
        fingerprintSettings: { ...DEFAULT_FINGERPRINT_SETTINGS },
        productivityModeEnabled: DEFAULT_PRODUCTIVITY_MODE_ENABLED,
        blockedSites: [],
        youtubeShortsBlocked: false,
        googlebotTabId: null,
        blockedToday: 0,
        protectionLogs: [],
        statsDate: currentDateKey()
      });
      await refreshFingerprintProtection();
    });
    writes = resetOperation.catch(() => undefined);
    resetOperation.then(
      () => sendResponse({ ok: true }),
      () => sendResponse({ ok: false })
    );
    return true;
  }

  if (message?.type === "threat-blocked"
    && _sender.id === chrome.runtime.id
    && Number.isInteger(_sender.tab?.id)
    && Number.isInteger(message.count)
    && message.count > 0) {
    let hostname;
    try {
      const senderUrl = new URL(_sender.url);
      if (senderUrl.protocol !== "http:" && senderUrl.protocol !== "https:") return;
      hostname = senderUrl.hostname;
    } catch {
      return;
    }
    writes = writes.then(async () => {
      const today = currentDateKey();
      const state = await chrome.storage.local.get(["blockedToday", "statsDate", "protectionLogs"]);
      const blockedToday = (state.statsDate === today ? (state.blockedToday ?? 0) : 0) + message.count;
      const logs = Array.isArray(state.protectionLogs) ? state.protectionLogs : [];
      const actionCounts = new Map();
      let remainingCount = message.count;
      if (Array.isArray(message.actions)) {
        for (const action of message.actions) {
          if (!action
            || typeof action.type !== "string"
            || !Object.hasOwn(PROTECTION_LOG_DETAILS, action.type)
            || !Number.isInteger(action.count)
            || action.count <= 0
            || remainingCount <= 0) continue;
          const actionCount = Math.min(action.count, remainingCount);
          actionCounts.set(action.type, (actionCounts.get(action.type) ?? 0) + actionCount);
          remainingCount -= actionCount;
        }
      }
      if (remainingCount > 0) actionCounts.set("page-action", (actionCounts.get("page-action") ?? 0) + remainingCount);
      const timestamp = Date.now();
      for (const [type, count] of actionCounts) {
        logs.push({
          timestamp,
          hostname,
          type,
          detail: PROTECTION_LOG_DETAILS[type],
          count
        });
      }
      await chrome.storage.local.set({
        blockedToday,
        statsDate: today,
        protectionLogs: logs.slice(-MAX_PROTECTION_LOG_ENTRIES)
      });
    }).catch((error) => console.error("Could not record protection activity.", error));
  }
});

function applyGooglebotMode(tabId, enabled, sendResponse) {
  const addRules = enabled ? [{
    id: GOOGLEBOT_RULE_ID,
    priority: 2,
    action: {
      type: "modifyHeaders",
      requestHeaders: [{ header: "user-agent", operation: "set", value: GOOGLEBOT_USER_AGENT }]
    },
    condition: {
      tabIds: [tabId],
      resourceTypes: ["main_frame", "sub_frame", "stylesheet", "script", "image", "font", "object", "xmlhttprequest", "ping", "csp_report", "media", "websocket", "other"]
    }
  }] : [];

  chrome.declarativeNetRequest.updateSessionRules({
    removeRuleIds: [GOOGLEBOT_RULE_ID],
    addRules
  }).then(() => chrome.storage.local.set({ googlebotTabId: enabled ? tabId : null }))
    .then(() => refreshFingerprintProtection([tabId]))
    .then(() => sendResponse({ ok: true, googlebotMode: enabled }))
    .catch(() => sendResponse({ ok: false }));
}
