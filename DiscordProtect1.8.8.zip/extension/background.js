// SPDX-FileCopyrightText: 2026 Discord Protect project
// SPDX-License-Identifier: CC-BY-NC-SA-4.0
// https://creativecommons.org/licenses/by-nc-sa/4.0/
const RULESET_ID = "base_rules";
const ANTI_TRACKING_RULESET_ID = "anti_tracking_rules";
const DEFAULT_ENABLED = true;
const DEFAULT_COOKIE_POPUP_ENABLED = true;
const DEFAULT_ANTI_TRACKING_ENABLED = true;
const DEFAULT_DISCORD_TOOLS_ENABLED = true;
const DEFAULT_ANTI_RICKROLL_ENABLED = false;
const DEFAULT_PRODUCTIVITY_MODE_ENABLED = false;
const GOOGLEBOT_RULE_ID = 90001;
const GOOGLEBOT_USER_AGENT = "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)";
const FINGERPRINT_RULE_ID = 90002;
const DEFAULT_FINGERPRINT_SETTINGS = Object.freeze({
  enabled: false,
  platform: "windows",
  maskUserAgent: true,
  maskTimezone: true,
  maskBattery: true,
  maskHardware: true,
  maskScreen: true
});
const FINGERPRINT_PROFILES = Object.freeze({
  windows: Object.freeze({
    platform: "Win32",
    clientHintPlatform: "Windows",
    platformVersion: "15.0.0",
    uaPlatform: "Windows NT 10.0; Win64; x64",
    architecture: "x86",
    screen: Object.freeze({ width: 1440, height: 900, availableHeight: 860, pixelRatio: 1 }),
    cores: 8,
    memory: 8,
    batteryLevel: 0.75
  }),
  mac: Object.freeze({
    platform: "MacIntel",
    clientHintPlatform: "macOS",
    platformVersion: "14.0.0",
    uaPlatform: "Macintosh; Intel Mac OS X 10_15_7",
    architecture: "x86",
    screen: Object.freeze({ width: 1440, height: 900, availableHeight: 860, pixelRatio: 2 }),
    cores: 8,
    memory: 8,
    batteryLevel: 0.75
  }),
  linux: Object.freeze({
    platform: "Linux x86_64",
    clientHintPlatform: "Linux",
    platformVersion: "",
    uaPlatform: "X11; Linux x86_64",
    architecture: "x86",
    screen: Object.freeze({ width: 1366, height: 768, availableHeight: 728, pixelRatio: 1 }),
    cores: 8,
    memory: 8,
    batteryLevel: 0.75
  })
});
const RECENT_CLICK_WINDOW_MS = 5000;
const PRODUCTIVITY_RULE_ID_BASE = 1000;
const MAX_BLOCKED_SITES = 100;
let writes = Promise.resolve();

function recentClickKey(tabId) {
  return `recent-navigation-click:${tabId}`;
}

function approvedNavigationKey(tabId) {
  return `approved-navigation:${tabId}`;
}

function pendingNavigationKey(tabId) {
  return `pending-navigation:${tabId}`;
}

function movixTargetKey(tabId) {
  return `movix-origin:${tabId}`;
}

function rickrollApprovalKey(tabId) {
  return `rickroll-approved-once:${tabId}`;
}

function normalizeFingerprintSettings(value) {
  const settings = value && typeof value === "object" ? value : {};
  return {
    enabled: settings.enabled === true,
    platform: Object.hasOwn(FINGERPRINT_PROFILES, settings.platform) ? settings.platform : DEFAULT_FINGERPRINT_SETTINGS.platform,
    maskUserAgent: settings.maskUserAgent !== false,
    maskTimezone: settings.maskTimezone !== false,
    maskBattery: settings.maskBattery !== false,
    maskHardware: settings.maskHardware !== false,
    maskScreen: settings.maskScreen !== false
  };
}

function getFingerprintUserAgent(platform) {
  const majorVersion = navigator.userAgent.match(/(?:Chrome|Chromium)\/(\d+)/)?.[1] ?? "131";
  const profile = FINGERPRINT_PROFILES[platform];
  return `Mozilla/5.0 (${profile.uaPlatform}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${majorVersion}.0.0.0 Safari/537.36`;
}

async function updateFingerprintUserAgentRule(settings, enabled, googlebotTabId) {
  const existing = await chrome.declarativeNetRequest.getSessionRules();
  const removeRuleIds = existing.filter((rule) => rule.id === FINGERPRINT_RULE_ID).map((rule) => rule.id);
  const addRules = enabled && settings.enabled && settings.maskUserAgent
    ? [{
      id: FINGERPRINT_RULE_ID,
      priority: 1,
      action: {
        type: "modifyHeaders",
        requestHeaders: [
          {
            header: "user-agent",
            operation: "set",
            value: getFingerprintUserAgent(settings.platform)
          }
        ]
      },
      condition: {
        ...(Number.isInteger(googlebotTabId) ? { excludeTabIds: [googlebotTabId] } : {}),
        resourceTypes: ["main_frame", "sub_frame", "stylesheet", "script", "image", "font", "object", "xmlhttprequest", "ping", "csp_report", "media", "websocket", "other"]
      }
    }]
    : [];
  await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds, addRules });
}

function applyPageFingerprint(settings, profile, enabled) {
  const key = Symbol.for("discordProtect.fingerprintState");
  const previous = window[key];
  if (previous?.restore) previous.restore();
  if (!enabled) {
    delete window[key];
    return;
  }

  const changes = [];
  const patch = (target, property, descriptor) => {
    const original = Object.getOwnPropertyDescriptor(target, property);
    try {
      Object.defineProperty(target, property, { ...descriptor, configurable: true });
      changes.push(() => {
        const current = Object.getOwnPropertyDescriptor(target, property);
        if (!current || current.get !== descriptor.get && current.value !== descriptor.value) return;
        if (original) Object.defineProperty(target, property, original);
        else delete target[property];
      });
    } catch {
      return;
    }
  };

  const brandMajor = navigator.userAgent.match(/(?:Chrome|Chromium)\/(\d+)/)?.[1] ?? "131";
  const brands = [
    { brand: "Not(A:Brand", version: "8" },
    { brand: "Chromium", version: brandMajor },
    { brand: "Google Chrome", version: brandMajor }
  ];
  if (settings.maskUserAgent) {
    const userAgent = `Mozilla/5.0 (${profile.uaPlatform}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${brandMajor}.0.0.0 Safari/537.36`;
    patch(Navigator.prototype, "userAgent", { get: () => userAgent });
    patch(Navigator.prototype, "platform", { get: () => profile.platform });
    const userAgentData = {
      brands,
      mobile: false,
      platform: profile.clientHintPlatform,
      getHighEntropyValues: async (hints = []) => {
        const highEntropy = {
          architecture: profile.architecture,
          bitness: "64",
          brands,
          fullVersionList: brands.map((brand) => ({ ...brand, version: brand.brand === "Not(A:Brand" ? "8.0.0.0" : `${brandMajor}.0.0.0` })),
          mobile: false,
          model: "",
          platform: profile.clientHintPlatform,
          platformVersion: profile.platformVersion,
          uaFullVersion: `${brandMajor}.0.0.0`,
          wow64: false
        };
        return Object.fromEntries(["brands", "mobile", "platform", ...hints].filter((hint) => hint in highEntropy).map((hint) => [hint, highEntropy[hint]]));
      },
      toJSON: () => ({ brands, mobile: false, platform: profile.clientHintPlatform })
    };
    patch(Navigator.prototype, "userAgentData", { get: () => userAgentData });
  }
  if (settings.maskTimezone) {
    const OriginalDateTimeFormat = Intl.DateTimeFormat;
    const WrappedDateTimeFormat = function (locales, options = {}) {
      const formatterOptions = options && typeof options === "object" ? options : {};
      return new OriginalDateTimeFormat(locales, { ...formatterOptions, timeZone: formatterOptions.timeZone ?? "UTC" });
    };
    Object.setPrototypeOf(WrappedDateTimeFormat, OriginalDateTimeFormat);
    WrappedDateTimeFormat.prototype = OriginalDateTimeFormat.prototype;
    patch(Intl, "DateTimeFormat", { value: WrappedDateTimeFormat, writable: true });
    const localToUtcMethods = {
      getDate: "getUTCDate",
      getDay: "getUTCDay",
      getFullYear: "getUTCFullYear",
      getHours: "getUTCHours",
      getMilliseconds: "getUTCMilliseconds",
      getMinutes: "getUTCMinutes",
      getMonth: "getUTCMonth",
      getSeconds: "getUTCSeconds",
      getTimezoneOffset: null
    };
    const localSettersToUtc = {
      setDate: "setUTCDate",
      setFullYear: "setUTCFullYear",
      setHours: "setUTCHours",
      setMilliseconds: "setUTCMilliseconds",
      setMinutes: "setUTCMinutes",
      setMonth: "setUTCMonth",
      setSeconds: "setUTCSeconds"
    };
    for (const [method, utcMethod] of Object.entries(localToUtcMethods)) {
      const replacement = method === "getTimezoneOffset" ? () => 0 : function (...args) {
        return Date.prototype[utcMethod].apply(this, args);
      };
      patch(Date.prototype, method, { value: replacement, writable: true });
    }
    for (const [method, utcMethod] of Object.entries(localSettersToUtc)) {
      patch(Date.prototype, method, {
        value: function (...args) {
          return Date.prototype[utcMethod].apply(this, args);
        },
        writable: true
      });
    }
    patch(Date.prototype, "setYear", {
      value: function (year) {
        const adjustedYear = year >= 0 && year <= 99 ? year + 1900 : year;
        return Date.prototype.setUTCFullYear.call(this, adjustedYear);
      },
      writable: true
    });
    const formatUtc = (date, locales, options) => {
      const formatterOptions = options && typeof options === "object" ? options : {};
      return new Intl.DateTimeFormat(locales, { ...formatterOptions, timeZone: formatterOptions.timeZone ?? "UTC" }).format(date);
    };
    patch(Date.prototype, "toLocaleString", {
      value: function (locales, options) { return formatUtc(this, locales, options); },
      writable: true
    });
    patch(Date.prototype, "toLocaleDateString", {
      value: function (locales, options) { return formatUtc(this, locales, options); },
      writable: true
    });
    patch(Date.prototype, "toLocaleTimeString", {
      value: function (locales, options) { return formatUtc(this, locales, options); },
      writable: true
    });
    patch(Date.prototype, "toDateString", {
      value: function () {
        const weekdays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
        const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        return `${weekdays[this.getUTCDay()]} ${months[this.getUTCMonth()]} ${String(this.getUTCDate()).padStart(2, "0")} ${this.getUTCFullYear()}`;
      },
      writable: true
    });
    patch(Date.prototype, "toTimeString", {
      value: function () {
        const pad = (value) => String(value).padStart(2, "0");
        return `${pad(this.getUTCHours())}:${pad(this.getUTCMinutes())}:${pad(this.getUTCSeconds())} GMT+0000 (Coordinated Universal Time)`;
      },
      writable: true
    });
    patch(Date.prototype, "toString", {
      value: function () {
        return `${this.toDateString()} ${this.toTimeString()}`;
      },
      writable: true
    });
  }
  if (settings.maskBattery) {
    const fakeBattery = new EventTarget();
    Object.defineProperties(fakeBattery, {
      charging: { value: false, enumerable: true },
      chargingTime: { value: Infinity, enumerable: true },
      dischargingTime: { value: 7200, enumerable: true },
      level: { value: profile.batteryLevel, enumerable: true }
    });
    patch(Navigator.prototype, "getBattery", { value: () => Promise.resolve(fakeBattery), writable: true });
  }
  if (settings.maskHardware) {
    patch(Navigator.prototype, "hardwareConcurrency", { get: () => profile.cores });
    patch(Navigator.prototype, "deviceMemory", { get: () => profile.memory });
  }
  if (settings.maskScreen) {
    patch(window.screen, "width", { get: () => profile.screen.width });
    patch(window.screen, "height", { get: () => profile.screen.height });
    patch(window.screen, "availWidth", { get: () => profile.screen.width });
    patch(window.screen, "availHeight", { get: () => profile.screen.availableHeight });
    patch(window.screen, "colorDepth", { get: () => 24 });
    patch(window.screen, "pixelDepth", { get: () => 24 });
    patch(window, "devicePixelRatio", { get: () => profile.screen.pixelRatio });
  }

  window[key] = {
    restore() {
      for (const restore of changes.reverse()) restore();
    }
  };
}

async function refreshFingerprintProtection(tabIds, updateHeaderRule = true) {
  const state = await chrome.storage.local.get(["protectionEnabled", "antiTrackingEnabled", "fingerprintSettings", "googlebotTabId"]);
  const settings = normalizeFingerprintSettings(state.fingerprintSettings);
  const enabled = state.protectionEnabled !== false && state.antiTrackingEnabled !== false && settings.enabled;
  if (updateHeaderRule) {
    await updateFingerprintUserAgentRule(settings, state.protectionEnabled !== false && state.antiTrackingEnabled !== false, state.googlebotTabId);
  }
  const profile = FINGERPRINT_PROFILES[settings.platform];
  const tabList = tabIds ?? (await chrome.tabs.query({})).map((tab) => tab.id).filter(Number.isInteger);
  const targets = await Promise.all(tabList.map(async (entry) => {
    if (typeof entry === "object") return entry;
    try {
      const frames = await chrome.webNavigation.getAllFrames({ tabId: entry });
      if (frames?.length) return frames.map((frame) => ({ tabId: entry, frameIds: [frame.frameId] }));
    } catch {
      // Restricted browser pages may not expose frame information.
    }
    return [{ tabId: entry, frameIds: [0] }];
  }));
  const flattenedTargets = targets.flat();
  const results = await Promise.allSettled(flattenedTargets.map((target) => {
    const tabEnabled = enabled && state.googlebotTabId !== target.tabId;
    return chrome.scripting.executeScript({
      target,
      world: "MAIN",
      injectImmediately: true,
      func: applyPageFingerprint,
      args: [settings, profile, tabEnabled]
    });
  }));
  return {
    active: enabled,
    applied: results.filter((result) => result.status === "fulfilled").length,
    unavailable: results.filter((result) => result.status === "rejected").length
  };
}

function normalizeTrustedHostname(hostname) {
  return String(hostname ?? "").toLowerCase().replace(/\.$/, "");
}

function normalizeBlockedSite(value) {
  const input = String(value ?? "").trim();
  if (!input || (input.includes("://") && !/^https?:\/\//i.test(input))) return null;

  let parsed;
  try {
    parsed = new URL(/^https?:\/\//i.test(input) ? input : `https://${input}`);
  } catch {
    return null;
  }
  if ((parsed.protocol !== "http:" && parsed.protocol !== "https:") || parsed.username || parsed.password) return null;

  let hostname = normalizeTrustedHostname(parsed.hostname);
  if (hostname.startsWith("www.")) hostname = hostname.slice(4);
  return hostname || null;
}

function normalizeBlockedSites(values) {
  if (!Array.isArray(values)) return [];
  return [...new Set(values.map(normalizeBlockedSite).filter(Boolean))].slice(0, MAX_BLOCKED_SITES);
}

async function updateProductivityRules(enabled, blockedSites) {
  const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
  const removeRuleIds = existingRules
    .filter((rule) => rule.id >= PRODUCTIVITY_RULE_ID_BASE && rule.id < PRODUCTIVITY_RULE_ID_BASE + MAX_BLOCKED_SITES)
    .map((rule) => rule.id);
  const addRules = enabled
    ? blockedSites.slice(0, MAX_BLOCKED_SITES).map((domain, index) => ({
      id: PRODUCTIVITY_RULE_ID_BASE + index,
      priority: 1,
      action: { type: "block" },
      condition: { requestDomains: [domain], resourceTypes: ["main_frame"] }
    }))
    : [];

  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules });
}

function isTrustedRedirectHost(hostname, trustedDomains) {
  const candidate = normalizeTrustedHostname(hostname);
  return trustedDomains.some((domain) => {
    const trusted = normalizeTrustedHostname(domain);
    return candidate === trusted || candidate.endsWith(`.${trusted}`);
  });
}

function isRickrollDestination(value) {
  let target;
  try {
    target = new URL(value);
  } catch {
    return false;
  }
  const normalized = `${target.href} ${target.pathname} ${target.search}`.toLowerCase();
  return normalized.includes("dqw4w9wgxcq")
    || /rick\s*roll|rick\s*astley|never[+\s_-]+gonna[+\s_-]+give[+\s_-]+you[+\s_-]+up/i.test(normalized);
}

function currentDateKey() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

async function applyRules(enabled) {
  await chrome.declarativeNetRequest.updateEnabledRulesets({
    enableRulesetIds: enabled ? [RULESET_ID] : [],
    disableRulesetIds: enabled ? [] : [RULESET_ID]
  });
}

async function applyAntiTrackingRules(enabled) {
  await chrome.declarativeNetRequest.updateEnabledRulesets({
    enableRulesetIds: enabled ? [ANTI_TRACKING_RULESET_ID] : [],
    disableRulesetIds: enabled ? [] : [ANTI_TRACKING_RULESET_ID]
  });
}

async function applyNotificationBlocking(enabled) {
  if (enabled) {
    await chrome.contentSettings.notifications.set({
      primaryPattern: "<all_urls>",
      setting: "block",
      scope: "regular"
    });
    return;
  }
  await chrome.contentSettings.notifications.clear({ scope: "regular" });
}

async function applyProtectionState(state) {
  const enabled = state.protectionEnabled === true;
  await applyRules(enabled);
  await applyAntiTrackingRules(enabled && state.antiTrackingEnabled !== false);
  await updateFingerprintUserAgentRule(
    normalizeFingerprintSettings(state.fingerprintSettings),
    enabled && state.antiTrackingEnabled !== false,
    state.googlebotTabId
  );
  await applyNotificationBlocking(enabled);
  await updateProductivityRules(enabled && state.productivityModeEnabled === true, state.blockedSites);
  if (!enabled) {
    await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [GOOGLEBOT_RULE_ID] });
    if (state.googlebotTabId !== null && state.googlebotTabId !== undefined) {
      await chrome.storage.local.set({ googlebotTabId: null });
    }
  }
}

function registerDiscordContextMenu() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "discord-protect-avatar-url",
      title: "Discord Protect : changer l’avatar local…",
      contexts: ["all"],
      documentUrlPatterns: ["https://discord.com/*"]
    });
    chrome.contextMenus.create({
      id: "discord-protect-avatar-decoration",
      title: "Discord Protect : décorer cet avatar…",
      contexts: ["all"],
      documentUrlPatterns: ["https://discord.com/*"]
    });
    chrome.contextMenus.create({
      id: "discord-protect-avatar-reset",
      title: "Discord Protect : retirer la personnalisation locale",
      contexts: ["all"],
      documentUrlPatterns: ["https://discord.com/*"]
    });
  });
}

async function initialize(resetSessionFeatures = false) {
  if (resetSessionFeatures) {
    await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [GOOGLEBOT_RULE_ID] });
    await chrome.storage.local.set({ googlebotTabId: null });
  }
  const state = await chrome.storage.local.get([
    "protectionEnabled",
    "cookiePopupEnabled",
    "cookieRejectEnabled",
    "antiTrackingEnabled",
    "discordToolsEnabled",
    "antiRickrollEnabled",
    "productivityModeEnabled",
    "blockedSites",
    "googlebotTabId",
    "fingerprintSettings",
    "youtubeShortsBlocked",
    "blockedToday",
    "statsDate"
  ]);
  const statsDate = currentDateKey();
  const nextState = {
    protectionEnabled: state.protectionEnabled ?? DEFAULT_ENABLED,
    cookiePopupEnabled: state.cookiePopupEnabled ?? state.cookieRejectEnabled ?? DEFAULT_COOKIE_POPUP_ENABLED,
    antiTrackingEnabled: state.antiTrackingEnabled ?? DEFAULT_ANTI_TRACKING_ENABLED,
    discordToolsEnabled: state.discordToolsEnabled ?? DEFAULT_DISCORD_TOOLS_ENABLED,
    antiRickrollEnabled: state.antiRickrollEnabled ?? DEFAULT_ANTI_RICKROLL_ENABLED,
    fingerprintSettings: normalizeFingerprintSettings(state.fingerprintSettings),
    productivityModeEnabled: state.productivityModeEnabled ?? DEFAULT_PRODUCTIVITY_MODE_ENABLED,
    blockedSites: normalizeBlockedSites(state.blockedSites),
    youtubeShortsBlocked: state.youtubeShortsBlocked ?? false,
    blockedToday: state.statsDate === statsDate ? (state.blockedToday ?? 0) : 0,
    statsDate
  };
  await chrome.storage.local.set(nextState);
  if (state.cookieRejectEnabled !== undefined) await chrome.storage.local.remove("cookieRejectEnabled");
  await applyProtectionState({ ...nextState, googlebotTabId: state.googlebotTabId });
  await refreshFingerprintProtection();
}

chrome.runtime.onInstalled.addListener(() => {
  void initialize(true);
  registerDiscordContextMenu();
});
chrome.runtime.onStartup.addListener(() => void initialize(true));
void initialize();

chrome.contextMenus.onClicked.addListener((info, tab) => {
  const actions = {
    "discord-protect-avatar-url": "open-avatar-url-tool",
    "discord-protect-avatar-decoration": "open-avatar-decoration-tool",
    "discord-protect-avatar-reset": "reset-avatar-customization"
  };
  const type = actions[info.menuItemId];
  if (!type || !tab?.id) return;
  chrome.tabs.sendMessage(tab.id, { type }).catch(() => undefined);
});

chrome.webNavigation.onBeforeNavigate.addListener(async (details) => {
  if (details.frameId !== 0 || !/^https?:\/\//i.test(details.url)) return;
  const protectionState = await chrome.storage.local.get("protectionEnabled");
  if (protectionState.protectionEnabled === false) return;

  const key = pendingNavigationKey(details.tabId);
  const stored = await chrome.storage.session.get(key);
  const previous = stored[key];
  const tabMovixTarget = await chrome.storage.session.get(movixTargetKey(details.tabId));
  let movixSourceUrl = tabMovixTarget[movixTargetKey(details.tabId)]?.sourceUrl ?? previous?.movixSourceUrl ?? "";
  if (!movixSourceUrl && !new URL(details.url).hostname.toLowerCase().includes("movix")) {
    try {
      const tab = await chrome.tabs.get(details.tabId);
      const currentUrl = new URL(tab.url);
      if (currentUrl.hostname.toLowerCase().includes("movix")) movixSourceUrl = currentUrl.href;
    } catch {
      // The tab may have closed before its navigation event was handled.
    }
  }
  const isContinuation = previous
    && previous.url !== details.url
    && details.timeStamp - previous.timeStamp < 15000;

  await chrome.storage.session.set({
    [key]: {
      url: details.url,
      timeStamp: details.timeStamp,
      redirectChain: Boolean(previous?.redirectChain || isContinuation),
      movixSourceUrl
    }
  });
});

chrome.webNavigation.onCommitted.addListener(async (details) => {
  if (!/^https?:\/\//i.test(details.url)) return;
  if (details.frameId !== 0) {
    try {
      const result = await refreshFingerprintProtection([{ tabId: details.tabId, frameIds: [details.frameId] }], false);
      if (result.unavailable > 0) console.warn(`Privacy profile could not be applied in frame ${details.frameId}.`);
    } catch (error) {
      console.error("Could not apply the privacy profile to a committed frame.", error);
    }
    return;
  }

  const approvedKey = approvedNavigationKey(details.tabId);
  const clickKey = recentClickKey(details.tabId);
  const pendingKey = pendingNavigationKey(details.tabId);
  const protectionState = await chrome.storage.local.get("protectionEnabled");
  if (protectionState.protectionEnabled === false) {
    await chrome.storage.session.remove([approvedKey, clickKey, pendingKey, movixTargetKey(details.tabId)]);
    return;
  }
  try {
    const fingerprintResult = await refreshFingerprintProtection([details.tabId], false);
    if (fingerprintResult.unavailable > 0) {
      console.warn(`Privacy profile could not be applied in tab ${details.tabId}.`);
    }
  } catch (error) {
    console.error("Could not apply the privacy profile to the committed tab.", error);
  }
  const stored = await chrome.storage.session.get([approvedKey, clickKey, pendingKey]);
  const approvedUrl = stored[approvedKey];
  const pendingNavigation = stored[pendingKey];
  const movixTargetStorageKey = movixTargetKey(details.tabId);
  const movixTargetState = await chrome.storage.session.get(movixTargetStorageKey);
  const movixTarget = movixTargetState[movixTargetStorageKey];
  if (!new URL(details.url).hostname.toLowerCase().includes("movix")) {
    if (movixTarget?.sourceUrl || pendingNavigation?.movixSourceUrl) {
      await chrome.storage.session.remove([clickKey, pendingKey, movixTargetStorageKey]);
      if (movixTarget?.closeOnRedirect) {
        await chrome.tabs.remove(details.tabId);
      } else {
        const returnUrl = movixTarget?.sourceUrl ?? pendingNavigation.movixSourceUrl;
        await chrome.tabs.update(details.tabId, { url: returnUrl });
      }
      return;
    }
  }
  if (approvedUrl === details.url) {
    await chrome.storage.session.remove([approvedKey, clickKey, pendingKey]);
    return;
  }

  const recentClickAt = stored[clickKey] ?? 0;
  const hasRecentClick = Date.now() - recentClickAt <= RECENT_CLICK_WINDOW_MS;
  const hasRedirectQualifier = details.transitionQualifiers.includes("client_redirect")
    || details.transitionQualifiers.includes("server_redirect");
  const wasRedirected = hasRedirectQualifier || Boolean(pendingNavigation?.redirectChain);
  const isInsecureHttp = details.url.startsWith("http://");
  const trustedState = isInsecureHttp
    ? { trustedRedirectDomains: [] }
    : await chrome.storage.local.get("trustedRedirectDomains");
  const trustedRedirectDomains = Array.isArray(trustedState.trustedRedirectDomains)
    ? trustedState.trustedRedirectDomains
    : [];
  const destinationIsTrusted = !isInsecureHttp
    && isTrustedRedirectHost(new URL(details.url).hostname, trustedRedirectDomains);
  const isRickrollNavigation = isRickrollDestination(details.url);
  const needsWarning = isRickrollNavigation
    || (wasRedirected && !hasRecentClick)
    || (isInsecureHttp && (!hasRecentClick || hasRedirectQualifier || Boolean(pendingNavigation?.redirectChain)));
  await chrome.storage.session.remove([clickKey, pendingKey]);
  if (!needsWarning || (wasRedirected && destinationIsTrusted && !isInsecureHttp && !isRickrollNavigation)) return;

  const warningPage = isInsecureHttp ? "http-warning.html" : "redirect-warning.html";
  const warningUrl = new URL(chrome.runtime.getURL(warningPage));
  warningUrl.searchParams.set("target", details.url);
  if (isRickrollNavigation) warningUrl.searchParams.set("reason", "rickroll");
  void chrome.tabs.update(details.tabId, { url: warningUrl.href });
});

chrome.webNavigation.onCreatedNavigationTarget.addListener(async (details) => {
  const protectionState = await chrome.storage.local.get("protectionEnabled");
  if (protectionState.protectionEnabled === false) return;
  try {
    const sourceTab = await chrome.tabs.get(details.sourceTabId);
    const sourceUrl = new URL(sourceTab.url);
    if (sourceUrl.hostname.toLowerCase().includes("movix")) {
      await chrome.storage.session.set({
        [movixTargetKey(details.tabId)]: {
          sourceUrl: sourceUrl.href,
          closeOnRedirect: true
        }
      });
    }
  } catch {
    // The source tab may have closed before the new target was inspected.
  }
  const sourceKey = recentClickKey(details.sourceTabId);
  const source = await chrome.storage.session.get(sourceKey);
  const clickedAt = source[sourceKey] ?? 0;
  if (Date.now() - clickedAt <= RECENT_CLICK_WINDOW_MS) {
    await chrome.storage.session.set({ [recentClickKey(details.tabId)]: clickedAt });
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  void chrome.storage.session.remove([recentClickKey(tabId), approvedNavigationKey(tabId), pendingNavigationKey(tabId), movixTargetKey(tabId), rickrollApprovalKey(tabId)]);
  chrome.storage.local.get("googlebotTabId").then((state) => {
    if (state.googlebotTabId !== tabId) return;
    chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [GOOGLEBOT_RULE_ID] })
      .then(() => chrome.storage.local.set({ googlebotTabId: null }))
      .catch(() => undefined);
  });
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "navigation-intent") {
    const tabId = _sender.tab?.id;
    if (Number.isInteger(tabId)) {
      chrome.storage.session.set({ [recentClickKey(tabId)]: Date.now() })
        .then(() => sendResponse({ ok: true }))
        .catch(() => sendResponse({ ok: false }));
      return true;
    }
    sendResponse({ ok: false });
    return;
  }

  if (message?.type === "confirmed-http-navigation") {
    const sourceTabId = _sender.tab?.id;
    const target = message.url;
    let parsedTarget;
    try {
      parsedTarget = new URL(target);
    } catch {
      sendResponse({ ok: false });
      return;
    }
    if (!Number.isInteger(sourceTabId) || parsedTarget.protocol !== "http:") {
      sendResponse({ ok: false });
      return;
    }

    if (message.newTab) {
      chrome.tabs.create({ url: "about:blank", active: true }).then((tab) => {
        const tabId = tab.id;
        return chrome.storage.session.set({
          [approvedNavigationKey(tabId)]: parsedTarget.href,
          [recentClickKey(tabId)]: Date.now()
        }).then(() => chrome.tabs.update(tabId, { url: parsedTarget.href }));
      }).then(() => sendResponse({ ok: true })).catch(() => sendResponse({ ok: false }));
    } else {
      chrome.storage.session.set({
        [approvedNavigationKey(sourceTabId)]: parsedTarget.href,
        [recentClickKey(sourceTabId)]: Date.now()
      }).then(() => chrome.tabs.update(sourceTabId, { url: parsedTarget.href }))
        .then(() => sendResponse({ ok: true }))
        .catch(() => sendResponse({ ok: false }));
    }
    return true;
  }

  if (message?.type === "rickroll-warning-navigation") {
    const sourceTabId = _sender.tab?.id;
    let target;
    try {
      target = new URL(message.target);
    } catch {
      sendResponse({ ok: false });
      return;
    }
    if (!Number.isInteger(sourceTabId) || (target.protocol !== "http:" && target.protocol !== "https:")) {
      sendResponse({ ok: false });
      return;
    }

    const warningUrl = new URL(chrome.runtime.getURL("redirect-warning.html"));
    warningUrl.searchParams.set("target", target.href);
    warningUrl.searchParams.set("reason", "rickroll");
    const opening = message.newTab
      ? chrome.tabs.create({ url: warningUrl.href, active: true })
      : chrome.tabs.update(sourceTabId, { url: warningUrl.href });
    opening.then(() => sendResponse({ ok: true })).catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "consume-rickroll-approval") {
    const tabId = _sender.tab?.id;
    let target;
    try {
      target = new URL(message.url);
    } catch {
      sendResponse({ approved: false });
      return;
    }
    if (!Number.isInteger(tabId) || (target.protocol !== "http:" && target.protocol !== "https:")) {
      sendResponse({ approved: false });
      return;
    }

    const key = rickrollApprovalKey(tabId);
    chrome.storage.session.get(key).then((state) => {
      const approved = state[key] === target.href;
      return chrome.storage.session.remove(key).then(() => sendResponse({ approved }));
    }).catch(() => sendResponse({ approved: false }));
    return true;
  }

  if (message?.type === "get-state") {
    chrome.storage.local.get(["protectionEnabled", "cookiePopupEnabled", "cookieRejectEnabled", "antiTrackingEnabled", "discordToolsEnabled", "antiRickrollEnabled", "productivityModeEnabled", "blockedSites", "youtubeShortsBlocked", "googlebotTabId", "fingerprintSettings", "blockedToday", "statsDate"]).then(async (state) => {
      const today = currentDateKey();
      if (state.statsDate !== today) {
        await chrome.storage.local.set({ blockedToday: 0, statsDate: today });
        state.blockedToday = 0;
      }
      sendResponse({
        protectionEnabled: state.protectionEnabled ?? DEFAULT_ENABLED,
        cookiePopupEnabled: state.cookiePopupEnabled ?? state.cookieRejectEnabled ?? DEFAULT_COOKIE_POPUP_ENABLED,
        antiTrackingEnabled: state.antiTrackingEnabled ?? DEFAULT_ANTI_TRACKING_ENABLED,
        fingerprintSettings: normalizeFingerprintSettings(state.fingerprintSettings),
        discordToolsEnabled: state.discordToolsEnabled ?? DEFAULT_DISCORD_TOOLS_ENABLED,
        antiRickrollEnabled: state.antiRickrollEnabled ?? DEFAULT_ANTI_RICKROLL_ENABLED,
        productivityModeEnabled: state.productivityModeEnabled ?? DEFAULT_PRODUCTIVITY_MODE_ENABLED,
        blockedSites: normalizeBlockedSites(state.blockedSites),
        youtubeShortsBlocked: state.youtubeShortsBlocked === true,
        googlebotMode: state.protectionEnabled !== false && Number.isInteger(message.tabId) && state.googlebotTabId === message.tabId,
        blockedToday: state.blockedToday ?? 0
      });
    });
    return true;
  }

  if (message?.type === "set-protection-state") {
    const enabled = Boolean(message.enabled);
    chrome.storage.local.get(["antiTrackingEnabled", "productivityModeEnabled", "blockedSites", "googlebotTabId", "fingerprintSettings"])
      .then((state) => {
        const nextState = { ...state, protectionEnabled: enabled, blockedSites: normalizeBlockedSites(state.blockedSites) };
        return chrome.storage.local.set({ protectionEnabled: enabled }).then(() => applyProtectionState(nextState));
      })
      .then(() => refreshFingerprintProtection())
      .then(() => sendResponse({ ok: true, protectionEnabled: enabled }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "set-cookie-popup-state") {
    const enabled = Boolean(message.enabled);
    chrome.storage.local.set({ cookiePopupEnabled: enabled })
      .then(() => sendResponse({ ok: true, cookiePopupEnabled: enabled }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "set-anti-tracking-state") {
    const enabled = Boolean(message.enabled);
    chrome.storage.local.set({ antiTrackingEnabled: enabled })
      .then(() => chrome.storage.local.get("protectionEnabled"))
      .then((state) => applyAntiTrackingRules(state.protectionEnabled !== false && enabled))
      .then(() => refreshFingerprintProtection())
      .then(() => sendResponse({ ok: true, antiTrackingEnabled: enabled }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "set-fingerprint-settings") {
    const settings = normalizeFingerprintSettings(message.settings);
    chrome.storage.local.set({ fingerprintSettings: settings })
      .then(() => refreshFingerprintProtection())
      .then((result) => sendResponse({ ok: true, fingerprintSettings: settings, ...result }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "set-discord-tools-state") {
    const enabled = Boolean(message.enabled);
    chrome.storage.local.set({ discordToolsEnabled: enabled })
      .then(() => sendResponse({ ok: true, discordToolsEnabled: enabled }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "set-anti-rickroll-state") {
    const enabled = Boolean(message.enabled);
    chrome.storage.local.set({ antiRickrollEnabled: enabled })
      .then(() => sendResponse({ ok: true, antiRickrollEnabled: enabled }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "set-productivity-mode") {
    const enabled = Boolean(message.enabled);
    chrome.storage.local.get(["blockedSites", "protectionEnabled"]).then(async (state) => {
      const blockedSites = normalizeBlockedSites(state.blockedSites);
      await updateProductivityRules(state.protectionEnabled !== false && enabled, blockedSites);
      await chrome.storage.local.set({ productivityModeEnabled: enabled, blockedSites });
      sendResponse({ ok: true, productivityModeEnabled: enabled, blockedSites });
    }).catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "add-blocked-site") {
    const domain = normalizeBlockedSite(message.domain);
    if (!domain) {
      sendResponse({ ok: false, reason: "invalid-domain" });
      return;
    }
    chrome.storage.local.get(["blockedSites", "productivityModeEnabled", "protectionEnabled"]).then(async (state) => {
      const blockedSites = normalizeBlockedSites(state.blockedSites);
      if (blockedSites.includes(domain)) {
        sendResponse({ ok: true, blockedSites, duplicate: true });
        return;
      }
      if (blockedSites.length >= MAX_BLOCKED_SITES) {
        sendResponse({ ok: false, reason: "limit-reached" });
        return;
      }
      const nextBlockedSites = [...blockedSites, domain];
      await updateProductivityRules(state.protectionEnabled !== false && state.productivityModeEnabled === true, nextBlockedSites);
      await chrome.storage.local.set({ blockedSites: nextBlockedSites });
      sendResponse({ ok: true, blockedSites: nextBlockedSites });
    }).catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "remove-blocked-site") {
    const domain = normalizeBlockedSite(message.domain);
    if (!domain) {
      sendResponse({ ok: false, reason: "invalid-domain" });
      return;
    }
    chrome.storage.local.get(["blockedSites", "productivityModeEnabled", "protectionEnabled"]).then(async (state) => {
      const blockedSites = normalizeBlockedSites(state.blockedSites).filter((site) => site !== domain);
      await updateProductivityRules(state.protectionEnabled !== false && state.productivityModeEnabled === true, blockedSites);
      await chrome.storage.local.set({ blockedSites });
      sendResponse({ ok: true, blockedSites });
    }).catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "set-youtube-shorts-blocked") {
    const enabled = Boolean(message.enabled);
    chrome.storage.local.set({ youtubeShortsBlocked: enabled })
      .then(() => sendResponse({ ok: true, youtubeShortsBlocked: enabled }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "set-googlebot-mode") {
    const tabId = message.tabId;
    const enabled = Boolean(message.enabled);
    if (!Number.isInteger(tabId) || tabId < 0) {
      sendResponse({ ok: false });
      return;
    }
    if (enabled) {
      chrome.storage.local.get("protectionEnabled").then((state) => {
        if (state.protectionEnabled === false) {
          sendResponse({ ok: false, reason: "Protection is disabled" });
          return;
        }
        applyGooglebotMode(tabId, true, sendResponse);
      }).catch(() => sendResponse({ ok: false }));
      return true;
    }

    applyGooglebotMode(tabId, false, sendResponse);
    return true;
  }

  if (message?.type === "confirm-redirect") {
    const target = message.target;
    const tabId = message.tabId;
    let parsedTarget;
    try {
      parsedTarget = new URL(target);
    } catch {
      sendResponse({ ok: false });
      return;
    }
    if (!Number.isInteger(tabId) || (parsedTarget.protocol !== "http:" && parsedTarget.protocol !== "https:")) {
      sendResponse({ ok: false });
      return;
    }

    const rememberDomain = Boolean(message.trustDomain) && parsedTarget.protocol === "https:";
    const saveApproval = rememberDomain
      ? chrome.storage.local.get("trustedRedirectDomains").then((state) => {
        const existingDomains = Array.isArray(state.trustedRedirectDomains) ? state.trustedRedirectDomains : [];
        const hostname = normalizeTrustedHostname(parsedTarget.hostname);
        const trustedRedirectDomains = [...new Set([...existingDomains.map(normalizeTrustedHostname), hostname])];
        return chrome.storage.local.set({ trustedRedirectDomains });
      })
      : Promise.resolve();

    const navigationApprovals = {
      [approvedNavigationKey(tabId)]: parsedTarget.href,
      [recentClickKey(tabId)]: Date.now()
    };
    if (message.skipRickrollOnce === true) navigationApprovals[rickrollApprovalKey(tabId)] = parsedTarget.href;
    saveApproval.then(() => chrome.storage.session.set(navigationApprovals))
      .then(() => chrome.tabs.update(tabId, { url: parsedTarget.href }))
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "go-back") {
    if (!Number.isInteger(message.tabId)) {
      sendResponse({ ok: false });
      return;
    }
    chrome.tabs.goBack(message.tabId)
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === "factory-reset") {
    const resetOperation = writes.then(async () => {
      await chrome.storage.local.clear();
      await applyProtectionState({
        protectionEnabled: DEFAULT_ENABLED,
        antiTrackingEnabled: DEFAULT_ANTI_TRACKING_ENABLED,
        fingerprintSettings: { ...DEFAULT_FINGERPRINT_SETTINGS },
        productivityModeEnabled: DEFAULT_PRODUCTIVITY_MODE_ENABLED,
        blockedSites: [],
        googlebotTabId: null
      });
      await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [GOOGLEBOT_RULE_ID, FINGERPRINT_RULE_ID] });
      await chrome.storage.local.set({
        protectionEnabled: DEFAULT_ENABLED,
        cookiePopupEnabled: DEFAULT_COOKIE_POPUP_ENABLED,
        antiTrackingEnabled: DEFAULT_ANTI_TRACKING_ENABLED,
        discordToolsEnabled: DEFAULT_DISCORD_TOOLS_ENABLED,
        antiRickrollEnabled: DEFAULT_ANTI_RICKROLL_ENABLED,
        fingerprintSettings: { ...DEFAULT_FINGERPRINT_SETTINGS },
        productivityModeEnabled: DEFAULT_PRODUCTIVITY_MODE_ENABLED,
        blockedSites: [],
        youtubeShortsBlocked: false,
        googlebotTabId: null,
        blockedToday: 0,
        statsDate: currentDateKey()
      });
      await refreshFingerprintProtection();
    });
    writes = resetOperation.catch(() => undefined);
    resetOperation.then(
      () => sendResponse({ ok: true }),
      () => sendResponse({ ok: false })
    );
    return true;
  }

  if (message?.type === "threat-blocked" && Number.isInteger(message.count) && message.count > 0) {
    writes = writes.then(async () => {
      const today = currentDateKey();
      const state = await chrome.storage.local.get(["blockedToday", "statsDate"]);
      const blockedToday = (state.statsDate === today ? (state.blockedToday ?? 0) : 0) + message.count;
      await chrome.storage.local.set({ blockedToday, statsDate: today });
    }).catch(() => undefined);
  }
});

function applyGooglebotMode(tabId, enabled, sendResponse) {
  const addRules = enabled ? [{
    id: GOOGLEBOT_RULE_ID,
    priority: 2,
    action: {
      type: "modifyHeaders",
      requestHeaders: [{ header: "user-agent", operation: "set", value: GOOGLEBOT_USER_AGENT }]
    },
    condition: {
      tabIds: [tabId],
      resourceTypes: ["main_frame", "sub_frame", "stylesheet", "script", "image", "font", "object", "xmlhttprequest", "ping", "csp_report", "media", "websocket", "other"]
    }
  }] : [];

  chrome.declarativeNetRequest.updateSessionRules({
    removeRuleIds: [GOOGLEBOT_RULE_ID],
    addRules
  }).then(() => chrome.storage.local.set({ googlebotTabId: enabled ? tabId : null }))
    .then(() => refreshFingerprintProtection([tabId]))
    .then(() => sendResponse({ ok: true, googlebotMode: enabled }))
    .catch(() => sendResponse({ ok: false }));
}
