// SPDX-FileCopyrightText: 2026 Discord Protect project
// SPDX-License-Identifier: CC-BY-NC-SA-4.0
// https://creativecommons.org/licenses/by-nc-sa/4.0/
const SITE_URL = "https://bot471912-dot.github.io/discordProtect/";
const BOT_URL = "https://discord.com/oauth2/authorize?client_id=1511044136340553849&permissions=8&scope=bot%20applications.commands";

const toggleButton = document.querySelector("#protection-toggle");
const statusText = document.querySelector("#status-text");
const statusDot = document.querySelector("#status-dot");
const statusDetail = document.querySelector("#status-detail");
const blockedCount = document.querySelector("#blocked-count");
const cookieToggle = document.querySelector("#cookie-toggle");
const cookieStatusText = document.querySelector("#cookie-status-text");
const cookieStatusDot = document.querySelector("#cookie-status-dot");
const cookieStatusDetail = document.querySelector("#cookie-status-detail");
const trackerToggle = document.querySelector("#tracker-toggle");
const trackerStatusText = document.querySelector("#tracker-status-text");
const trackerStatusDot = document.querySelector("#tracker-status-dot");
const trackerStatusDetail = document.querySelector("#tracker-status-detail");
const trackerSettingsButton = document.querySelector("#tracker-settings");
const discordToolsToggle = document.querySelector("#discord-tools-toggle");
const discordToolsStatusText = document.querySelector("#discord-tools-status-text");
const discordToolsStatusDot = document.querySelector("#discord-tools-status-dot");
const discordToolsStatusDetail = document.querySelector("#discord-tools-status-detail");
const shortsToggle = document.querySelector("#shorts-toggle");
const shortsStatusText = document.querySelector("#shorts-status-text");
const shortsStatusDot = document.querySelector("#shorts-status-dot");
const shortsStatusDetail = document.querySelector("#shorts-status-detail");
const rickrollToggle = document.querySelector("#rickroll-toggle");
const rickrollStatusText = document.querySelector("#rickroll-status-text");
const rickrollStatusDot = document.querySelector("#rickroll-status-dot");
const rickrollStatusDetail = document.querySelector("#rickroll-status-detail");
const productivityToggle = document.querySelector("#productivity-toggle");
const productivityStatusText = document.querySelector("#productivity-status-text");
const productivityStatusDot = document.querySelector("#productivity-status-dot");
const productivityStatusDetail = document.querySelector("#productivity-status-detail");
const blockedSiteForm = document.querySelector("#blocked-site-form");
const blockedSiteInput = document.querySelector("#blocked-site-input");
const blockedSitesList = document.querySelector("#blocked-sites-list");
const productivityNote = document.querySelector("#productivity-note");
const googlebotToggle = document.querySelector("#googlebot-toggle");
const googlebotStatusText = document.querySelector("#googlebot-status-text");
const googlebotStatusDot = document.querySelector("#googlebot-status-dot");
const googlebotStatusDetail = document.querySelector("#googlebot-status-detail");
const resetButton = document.querySelector("#factory-reset");
const resetStatus = document.querySelector("#reset-status");
const pickElementButton = document.querySelector("#pick-element");
const pickerStatus = document.querySelector("#picker-status");
let activeTabId;

async function getCurrentState() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  activeTabId = tab?.id;
  return chrome.runtime.sendMessage({ type: "get-state", tabId: activeTabId });
}

function renderState(state) {
  const enabled = Boolean(state.protectionEnabled);
  toggleButton.setAttribute("aria-checked", String(enabled));
  statusText.textContent = enabled ? "Active" : "Désactivée";
  statusText.classList.toggle("off", !enabled);
  statusDot.classList.toggle("off", !enabled);
  statusDetail.textContent = enabled
    ? "Publicités, traceurs et notifications web bloqués"
    : "Toutes les protections sont en pause; tes préférences sont conservées";
  blockedCount.textContent = String(state.blockedToday ?? 0);

  const cookiePopupEnabled = enabled && Boolean(state.cookiePopupEnabled);
  cookieToggle.disabled = !enabled;
  cookieToggle.setAttribute("aria-checked", String(cookiePopupEnabled));
  cookieStatusText.textContent = cookiePopupEnabled ? "Actif" : "Désactivé";
  cookieStatusText.classList.toggle("off", !cookiePopupEnabled);
  cookieStatusDot.classList.toggle("off", !cookiePopupEnabled);
  cookieStatusDetail.textContent = !enabled
    ? "Protection générale désactivée (préférence conservée)"
    : cookiePopupEnabled ? "Supprime popup et backdrop compatibles" : "Le masquage est en pause";

  const antiTrackingEnabled = enabled && Boolean(state.antiTrackingEnabled);
  trackerToggle.disabled = !enabled;
  trackerToggle.setAttribute("aria-checked", String(antiTrackingEnabled));
  trackerStatusText.textContent = antiTrackingEnabled ? "Actif" : "Désactivé";
  trackerStatusText.classList.toggle("off", !antiTrackingEnabled);
  trackerStatusDot.classList.toggle("off", !antiTrackingEnabled);
  const fingerprintSettings = state.fingerprintSettings;
  trackerStatusDetail.textContent = !enabled
    ? "Protection générale désactivée (préférence conservée)"
    : antiTrackingEnabled
      ? fingerprintSettings?.enabled
        ? "Nettoie les liens et applique le profil fictif choisi ⚙"
        : "Nettoie les liens et masque le site précédent aux domaines tiers ⚙"
      : "Le nettoyage des liens et des référents est en pause ⚙";

  const discordToolsEnabled = enabled && Boolean(state.discordToolsEnabled);
  discordToolsToggle.disabled = !enabled;
  discordToolsToggle.setAttribute("aria-checked", String(discordToolsEnabled));
  discordToolsStatusText.textContent = discordToolsEnabled ? "Actif" : "Désactivé";
  discordToolsStatusText.classList.toggle("off", !discordToolsEnabled);
  discordToolsStatusDot.classList.toggle("off", !discordToolsEnabled);
  discordToolsStatusDetail.textContent = !enabled
    ? "Protection générale désactivée (préférence conservée)"
    : discordToolsEnabled ? "Personnalisation et infos visibles de profil" : "Outils Discord en pause";

  const shortsBlocked = enabled && Boolean(state.youtubeShortsBlocked);
  shortsToggle.disabled = !enabled;
  shortsToggle.setAttribute("aria-checked", String(shortsBlocked));
  shortsStatusText.textContent = shortsBlocked ? "Actif" : "Inactif";
  shortsStatusText.classList.toggle("off", !shortsBlocked);
  shortsStatusDot.classList.toggle("off", !shortsBlocked);
  shortsStatusDetail.textContent = !enabled
    ? "Protection générale désactivée"
    : shortsBlocked ? "Les Shorts s’ouvrent en vidéo classique" : "Alerte après 10 défilements vers le bas";

  const antiRickrollEnabled = enabled && Boolean(state.antiRickrollEnabled);
  rickrollToggle.disabled = !enabled;
  rickrollToggle.setAttribute("aria-checked", String(antiRickrollEnabled));
  rickrollStatusText.textContent = antiRickrollEnabled ? "Actif" : "Désactivé";
  rickrollStatusText.classList.toggle("off", !antiRickrollEnabled);
  rickrollStatusDot.classList.toggle("off", !antiRickrollEnabled);
  rickrollStatusDetail.textContent = !enabled
    ? "Protection générale désactivée (préférence conservée)"
    : antiRickrollEnabled ? "Bloque les vidéos et GIF reconnus" : "Détection anti-Rickroll en pause";

  const googlebotMode = enabled && Boolean(state.googlebotMode);
  googlebotToggle.disabled = !enabled;
  googlebotToggle.setAttribute("aria-pressed", String(googlebotMode));
  googlebotToggle.textContent = googlebotMode ? "Désactiver" : "Activer";
  googlebotStatusText.textContent = googlebotMode ? "Actif" : "Inactif";
  googlebotStatusText.classList.toggle("off", !googlebotMode);
  googlebotStatusDot.classList.toggle("off", !googlebotMode);
  googlebotStatusDetail.textContent = !enabled
    ? "Protection générale désactivée"
    : googlebotMode ? "User-Agent émulé dans cet onglet" : "Émulation limitée à cet onglet";

  renderProductivityState(state);
  pickElementButton.disabled = !enabled;
  if (!enabled) pickerStatus.textContent = "Protection générale désactivée";
}

function renderProductivityState(state) {
  const protectionEnabled = Boolean(state.protectionEnabled);
  const enabled = protectionEnabled && Boolean(state.productivityModeEnabled);
  const sites = Array.isArray(state.blockedSites) ? state.blockedSites : [];
  productivityToggle.disabled = !protectionEnabled;
  productivityToggle.setAttribute("aria-checked", String(enabled));
  productivityStatusText.textContent = enabled ? "Actif" : "Désactivé";
  productivityStatusText.classList.toggle("off", !enabled);
  productivityStatusDot.classList.toggle("off", !enabled);
  productivityStatusDetail.textContent = !protectionEnabled
    ? `${sites.length} site${sites.length === 1 ? "" : "s"} enregistré${sites.length === 1 ? "" : "s"}, protection générale désactivée`
    : enabled
    ? `${sites.length} site${sites.length === 1 ? "" : "s"} bloqué${sites.length === 1 ? "" : "s"}`
    : sites.length
      ? `${sites.length} site${sites.length === 1 ? "" : "s"} enregistré${sites.length === 1 ? "" : "s"}, blocage en pause`
      : "Aucun site bloqué";

  blockedSitesList.replaceChildren();
  for (const domain of sites) {
    const row = document.createElement("li");
    row.className = "blocked-site-row";
    const label = document.createElement("span");
    label.className = "blocked-site-domain";
    label.textContent = domain;
    const removeButton = document.createElement("button");
    removeButton.className = "remove-site-button";
    removeButton.type = "button";
    removeButton.dataset.domain = domain;
    removeButton.textContent = "Débloquer";
    removeButton.setAttribute("aria-label", `Débloquer ${domain}`);
    row.append(label, removeButton);
    blockedSitesList.append(row);
  }
}

getCurrentState().then(renderState).catch(() => {
  statusText.textContent = "Indisponible";
  statusDetail.textContent = "Rechargez l’extension pour réessayer";
});

toggleButton.addEventListener("click", async () => {
  toggleButton.disabled = true;
  try {
    const current = await getCurrentState();
    const result = await chrome.runtime.sendMessage({
      type: "set-protection-state",
      enabled: !current.protectionEnabled
    });
    if (result?.ok) renderState({ ...current, protectionEnabled: result.protectionEnabled });
  } catch {
    statusDetail.textContent = "Impossible de modifier la protection";
  } finally {
    toggleButton.disabled = false;
  }
});

cookieToggle.addEventListener("click", async () => {
  cookieToggle.disabled = true;
  try {
    const current = await getCurrentState();
    const result = await chrome.runtime.sendMessage({
      type: "set-cookie-popup-state",
      enabled: !current.cookiePopupEnabled
    });
    if (result?.ok) renderState({ ...current, cookiePopupEnabled: result.cookiePopupEnabled });
  } catch {
    cookieStatusDetail.textContent = "Impossible de modifier le masquage";
  } finally {
    cookieToggle.disabled = false;
  }
});

googlebotToggle.addEventListener("click", async () => {
  googlebotToggle.disabled = true;
  try {
    const current = await getCurrentState();
    if (!Number.isInteger(activeTabId)) throw new Error("No active tab");
    const result = await chrome.runtime.sendMessage({
      type: "set-googlebot-mode",
      enabled: !current.googlebotMode,
      tabId: activeTabId
    });
    if (!result?.ok) throw new Error("User-Agent override rejected");
    renderState({ ...current, googlebotMode: result.googlebotMode });
  } catch {
    googlebotStatusDetail.textContent = "Chrome n’a pas accepté le changement de User-Agent";
  } finally {
    googlebotToggle.disabled = false;
  }
});

trackerToggle.addEventListener("click", async () => {
  trackerToggle.disabled = true;
  try {
    const current = await getCurrentState();
    const result = await chrome.runtime.sendMessage({
      type: "set-anti-tracking-state",
      enabled: !current.antiTrackingEnabled
    });
    if (result?.ok) renderState({ ...current, antiTrackingEnabled: result.antiTrackingEnabled });
  } catch {
    trackerStatusDetail.textContent = "Impossible de modifier l’anti-traceurs";
  } finally {
    trackerToggle.disabled = false;
  }
});

trackerSettingsButton.addEventListener("click", () => {
  chrome.runtime.openOptionsPage().catch(() => {
    trackerStatusDetail.textContent = "Impossible d’ouvrir les réglages de confidentialité";
  });
});

discordToolsToggle.addEventListener("click", async () => {
  discordToolsToggle.disabled = true;
  try {
    const current = await getCurrentState();
    const result = await chrome.runtime.sendMessage({
      type: "set-discord-tools-state",
      enabled: !current.discordToolsEnabled
    });
    if (result?.ok) renderState({ ...current, discordToolsEnabled: result.discordToolsEnabled });
  } catch {
    discordToolsStatusDetail.textContent = "Impossible de modifier les outils Discord";
  } finally {
    discordToolsToggle.disabled = false;
  }
});

shortsToggle.addEventListener("click", async () => {
  shortsToggle.disabled = true;
  try {
    const current = await getCurrentState();
    const result = await chrome.runtime.sendMessage({
      type: "set-youtube-shorts-blocked",
      enabled: !current.youtubeShortsBlocked
    });
    if (result?.ok) renderState({ ...current, youtubeShortsBlocked: result.youtubeShortsBlocked });
  } catch {
    shortsStatusDetail.textContent = "Impossible de modifier ce réglage";
  } finally {
    shortsToggle.disabled = false;
  }
});

rickrollToggle.addEventListener("click", async () => {
  rickrollToggle.disabled = true;
  try {
    const current = await getCurrentState();
    const result = await chrome.runtime.sendMessage({
      type: "set-anti-rickroll-state",
      enabled: !current.antiRickrollEnabled
    });
    if (result?.ok) renderState({ ...current, antiRickrollEnabled: result.antiRickrollEnabled });
  } catch {
    rickrollStatusDetail.textContent = "Impossible de modifier l’anti-Rick Roll";
  } finally {
    rickrollToggle.disabled = false;
  }
});

productivityToggle.addEventListener("click", async () => {
  productivityToggle.disabled = true;
  try {
    const current = await getCurrentState();
    const result = await chrome.runtime.sendMessage({
      type: "set-productivity-mode",
      enabled: !current.productivityModeEnabled
    });
    if (!result?.ok) throw new Error("Productivity mode update failed");
    renderState({ ...current, ...result });
    productivityNote.textContent = result.productivityModeEnabled ? "Blocage activé." : "Blocage mis en pause; la liste est conservée.";
  } catch {
    productivityNote.textContent = "Impossible de modifier le mode Productivité.";
  } finally {
    productivityToggle.disabled = false;
  }
});

blockedSiteForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const submitButton = blockedSiteForm.querySelector("button[type='submit']");
  submitButton.disabled = true;
  try {
    const result = await chrome.runtime.sendMessage({
      type: "add-blocked-site",
      domain: blockedSiteInput.value
    });
    if (!result?.ok) {
      productivityNote.textContent = result?.reason === "limit-reached"
        ? "La liste peut contenir au maximum 100 sites."
        : "Entre un nom de domaine valide, par exemple exemple.com.";
      return;
    }
    renderProductivityState({
      productivityModeEnabled: productivityToggle.getAttribute("aria-checked") === "true",
      blockedSites: result.blockedSites
    });
    productivityNote.textContent = result.duplicate ? "Ce site est déjà dans la liste." : `${result.blockedSites.at(-1)} ajouté à la liste.`;
    blockedSiteInput.value = "";
  } catch {
    productivityNote.textContent = "Impossible d’enregistrer ce site.";
  } finally {
    submitButton.disabled = false;
  }
});

blockedSitesList.addEventListener("click", async (event) => {
  const removeButton = event.target.closest(".remove-site-button");
  if (!removeButton) return;
  removeButton.disabled = true;
  const domain = removeButton.dataset.domain;
  try {
    const result = await chrome.runtime.sendMessage({ type: "remove-blocked-site", domain });
    if (!result?.ok) throw new Error("Could not remove blocked site");
    renderProductivityState({
      productivityModeEnabled: productivityToggle.getAttribute("aria-checked") === "true",
      blockedSites: result.blockedSites
    });
    productivityNote.textContent = `${domain} retiré de la liste.`;
  } catch {
    productivityNote.textContent = `Impossible de débloquer ${domain}.`;
    removeButton.disabled = false;
  }
});

pickElementButton.addEventListener("click", async () => {
  pickElementButton.disabled = true;
  pickerStatus.textContent = "Cliquez sur un élément à retirer; Échap annule.";
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) throw new Error("No active tab");
    let response;
    try {
      response = await chrome.tabs.sendMessage(tab.id, { type: "start-element-picker" });
    } catch {
      response = null;
    }
    if (!response?.ok) {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
      response = await chrome.tabs.sendMessage(tab.id, { type: "start-element-picker" });
    }
    if (!response?.ok) throw new Error("Picker unavailable");
    window.close();
  } catch (error) {
    const message = String(error?.message ?? "");
    pickerStatus.textContent = /Cannot access|cannot be scripted|extensions|host permission/i.test(message)
      ? "Chrome interdit la sélection sur cette page (page système ou Chrome Web Store)."
      : "Sélection indisponible. Rechargez la page et réessayez.";
    pickElementButton.disabled = false;
  }
});

resetButton.addEventListener("click", async () => {
  const confirmed = window.confirm("Réinitialiser Discord Protect ? Les réglages et le compteur local de l’extension seront effacés.");
  if (!confirmed) return;

  resetButton.disabled = true;
  resetStatus.textContent = "Réinitialisation…";
  try {
    const result = await chrome.runtime.sendMessage({ type: "factory-reset" });
    if (!result?.ok) throw new Error("Factory reset failed");
    const state = await getCurrentState();
    renderState(state);
    resetStatus.textContent = "Paramètres réinitialisés. Compteur remis à zéro.";
  } catch {
    resetStatus.textContent = "Échec de la réinitialisation. Réessayez.";
  } finally {
    resetButton.disabled = false;
  }
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === "local" && (changes.blockedToday || changes.protectionEnabled || changes.cookiePopupEnabled || changes.antiTrackingEnabled || changes.discordToolsEnabled || changes.antiRickrollEnabled || changes.productivityModeEnabled || changes.blockedSites || changes.youtubeShortsBlocked || changes.googlebotTabId)) {
    getCurrentState().then(renderState).catch(() => undefined);
  }
});

document.querySelector("#website-link").href = SITE_URL;
document.querySelector("#bot-link").href = BOT_URL;
