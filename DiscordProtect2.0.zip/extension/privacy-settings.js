// SPDX-FileCopyrightText: 2026 Discord Protect project
// SPDX-License-Identifier: CC-BY-NC-SA-4.0
// https://creativecommons.org/licenses/by-nc-sa/4.0/
const form = document.querySelector("#privacy-form");
const enabledInput = document.querySelector("#fingerprint-enabled");
const platformInput = document.querySelector("#profile-platform");
const timezoneInput = document.querySelector("#profile-timezone");
const customUserAgentInput = document.querySelector("#custom-user-agent");
const profileSummary = document.querySelector("#profile-summary");
const saveButton = document.querySelector("#save-settings");
const saveStatus = document.querySelector("#save-status");
let pendingApplyRequestId = null;
let completedApplyRequestId = null;

function showApplicationResult(message) {
  completedApplyRequestId = message.requestId;
  if (message.ok === false) {
    saveStatus.textContent = "Profil enregistré, mais l’application aux onglets a échoué. Recharge les pages et réessaie.";
    return;
  }

  const statusParts = [message.active
    ? `Profil appliqué à ${message.applied} cadre(s) de page.`
    : "Profil enregistré, mais inactif. Active le profil, Protection et Anti-traceurs pour l’appliquer."];
  if (message.unavailable > 0) {
    statusParts.push(`${message.unavailable} cadre(s) n’étaient pas accessibles à Chrome.`);
  }
  if (message.failedProperties?.length > 0) {
    statusParts.push(`Propriétés indisponibles : ${message.failedProperties.join(", ")}.`);
  }
  if (readForm().enabled) statusParts.push("Recharge les pages pour appliquer le User-Agent aux prochaines requêtes.");
  else statusParts.push("Le profil fictif est désactivé.");
  saveStatus.textContent = statusParts.join(" ");
}
const platformProfiles = {
  windows: {
    label: "Chrome · Windows",
    platform: "Windows 10/11",
    screen: "1440 × 900 px",
    scale: "×1",
    cpu: "8 cœurs",
    memory: "8 Go"
  },
  mac: {
    label: "Chrome · macOS",
    platform: "macOS",
    screen: "1440 × 900 px",
    scale: "×2 (Retina)",
    cpu: "8 cœurs",
    memory: "8 Go"
  },
  linux: {
    label: "Chrome · Linux",
    platform: "Linux",
    screen: "1366 × 768 px",
    scale: "×1",
    cpu: "8 cœurs",
    memory: "8 Go"
  }
};

function normalizeSettings(value) {
  const settings = value && typeof value === "object" ? value : {};
  return {
    enabled: settings.enabled === true,
    platform: Object.hasOwn(platformProfiles, settings.platform) ? settings.platform : "windows",
    customUserAgent: typeof settings.customUserAgent === "string" ? settings.customUserAgent : "",
    timezone: [...timezoneInput.options].some((option) => option.value === settings.timezone) ? settings.timezone : "UTC",
    maskUserAgent: settings.maskUserAgent !== false,
    maskTimezone: settings.maskTimezone !== false,
    maskBattery: settings.maskBattery !== false,
    maskHardware: settings.maskHardware !== false,
    maskScreen: settings.maskScreen !== false
  };
}

function readForm() {
  return {
    enabled: enabledInput.checked,
    platform: platformInput.value,
    customUserAgent: customUserAgentInput.value.trim(),
    timezone: timezoneInput.value,
    maskUserAgent: form.elements.namedItem("maskUserAgent").checked,
    maskTimezone: form.elements.namedItem("maskTimezone").checked,
    maskBattery: form.elements.namedItem("maskBattery").checked,
    maskHardware: form.elements.namedItem("maskHardware").checked,
    maskScreen: form.elements.namedItem("maskScreen").checked
  };
}

function renderSummary() {
  const profile = platformProfiles[platformInput.value];
  const masked = readForm();
  if (!masked.enabled) {
    profileSummary.textContent = "Profil fictif désactivé : les pages reçoivent les valeurs fournies par le navigateur et le système.";
    return;
  }
  const userAgentPlatforms = {
    windows: "Windows NT 10.0; Win64; x64",
    mac: "Macintosh; Intel Mac OS X 10_15_7",
    linux: "X11; Linux x86_64"
  };
  const chromeMajor = navigator.userAgent.match(/(?:Chrome|Chromium)\/(\d+)/)?.[1] ?? "131";
  const rows = [
    masked.maskUserAgent
      ? `User-Agent HTTP : ${masked.customUserAgent || `Mozilla/5.0 (${userAgentPlatforms[platformInput.value]}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${chromeMajor}.0.0.0 Safari/537.36`}`
      : "User-Agent réel du navigateur",
    masked.maskTimezone ? `Fuseau JavaScript : ${masked.timezone}` : "Fuseau horaire réel",
    masked.maskBattery ? "Batterie fictive : 75 %, hors charge" : "État de batterie réel/indisponible",
    masked.maskHardware ? `${profile.cpu} · ${profile.memory}` : "Matériel déclaré réel",
    masked.maskScreen ? `${profile.screen} · ${profile.scale}` : "Dimensions d’écran réelles"
  ];
  profileSummary.textContent = `Valeurs présentées aux pages :\n${rows.join("\n")}\nLe numéro majeur de Chrome reste celui du navigateur.`;
}

function renderSettings(settings) {
  enabledInput.checked = settings.enabled;
  platformInput.value = settings.platform;
  timezoneInput.value = settings.timezone;
  customUserAgentInput.value = settings.customUserAgent;
  for (const key of ["maskUserAgent", "maskTimezone", "maskBattery", "maskHardware", "maskScreen"]) {
    form.elements.namedItem(key).checked = settings[key];
  }
  renderSummary();
}

async function loadSettings() {
  const state = await chrome.runtime.sendMessage({ type: "get-state" });
  renderSettings(normalizeSettings(state?.fingerprintSettings));
  if (state?.protectionEnabled === false || state?.antiTrackingEnabled === false) {
    saveStatus.textContent = "Le profil est enregistré, mais il reste inactif tant que Protection et Anti-traceurs ne sont pas tous deux activés.";
  }
}

platformInput.addEventListener("change", renderSummary);
timezoneInput.addEventListener("change", renderSummary);
customUserAgentInput.addEventListener("input", renderSummary);
customUserAgentInput.addEventListener("input", () => customUserAgentInput.setCustomValidity(""));
form.addEventListener("change", renderSummary);

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (customUserAgentInput.value.length > 256 || /[^\x20-\x7E]/.test(customUserAgentInput.value)) {
    customUserAgentInput.setCustomValidity("Utilise uniquement des caractères ASCII imprimables (256 caractères maximum).");
    customUserAgentInput.reportValidity();
    return;
  }
  saveButton.disabled = true;
  saveStatus.textContent = "Application du profil…";
  const requestId = crypto.randomUUID();
  pendingApplyRequestId = requestId;
  completedApplyRequestId = null;
  try {
    const result = await chrome.runtime.sendMessage({
      type: "set-fingerprint-settings",
      requestId,
      settings: readForm()
    });
    if (!result?.ok) throw new Error("Privacy profile update failed");
    if (result.applying && completedApplyRequestId !== requestId) {
      saveStatus.textContent = "Profil enregistré. Application aux onglets ouverts en arrière-plan…";
    }
  } catch (error) {
    console.error("Could not save or apply privacy profile settings.", error);
    saveStatus.textContent = "Échec de l’enregistrement ou de l’application du profil. Réessaie.";
  } finally {
    saveButton.disabled = false;
  }
});

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type !== "fingerprint-application-complete"
    || message.requestId !== pendingApplyRequestId) return;
  pendingApplyRequestId = null;
  showApplicationResult(message);
});

loadSettings().catch(() => {
  saveStatus.textContent = "Impossible de charger les réglages de confidentialité.";
});
